# BE-D04-01 — Baseline dự án/runtime hiện tại

**Ngày ghi nhận:** 01/11/2026, Asia/Ho_Chi_Minh
**Phạm vi:** repository branch `be-d04` và runtime Docker local hiện tại. Snapshot này không mô tả staging/production.

## Source và working tree

- HEAD: `135efcc8ec5c4c73cff8d58cabc62a17772234bf` (`K04.8 — Review, sửa lỗi và cập nhật issue`).
- Working tree trước khi tạo hai report D04-01: [API Route Catalog](<../../../../Architecture & Technical Design/API Route Catalog.md>) đang modified; contract, plan và evidence BE-D04 đang untracked. Catalog có cập nhật baseline BE-D04 và nhãn Overview thành Dự kiến; thay đổi tài liệu này được giữ nguyên. Không có code backend được sửa trong D04-01.
- Dependency ancestry đã xác minh bằng `git merge-base --is-ancestor <hash> HEAD`:

| Phụ thuộc | Commit có trong HEAD |
|---|---|
| BE-D03 | `c67eae1ff0c141be051f1d44073fd41f54b46628` |
| BE-D03 regression | `9c9d7468853aadbc2c32928fa55598e945d04d4c` |
| BE-H03 | `2026c996400137da31d21b1e7064cb4d4823b51e` |
| Merge BE-H03 PR #77 | `70125345155cb3c85bd949676701e74967848dac` |
| BE-K02 writer | `a54336c0bba3246c5ba4c73e648ee6e908f25227` |
| BE-K02 handover | `7834e5f42fe9410f2e576c08de0325b6d8b6d8a3` |

Ancestry xác nhận commit dependency có trong branch; không phải kết quả CI hay kiểm thử BE-D04.

## Route và OpenAPI

Đã đọc `docker compose exec -T backend php artisan route:list --path=api/v1 --json`; lưu nguyên output ở [routes JSON](routes-2026-11-01.json). Runtime có 89 route entries, tương ứng 120 method atoms sau khi tách các method gộp như `GET|HEAD`. OpenAPI tại `docs/api/openapi.json` có 89 operations. Không có route hoặc OpenAPI path trong 16 method/path BE-D04.

Các con số là baseline count; chưa thực hiện route parity đầy đủ cho toàn bộ API và chưa triển khai route D04. Khi triển khai phải so tập method/path, không dựa riêng tổng số.

## Migration status ứng dụng local

Đã đọc `docker compose exec -T backend php artisan migrate:status`; lưu output ở [migration status](migration-status-2026-11-01.txt).

- **32 migration:** 25 `Ran`, 7 `Pending` tại lúc ghi nhận.
- Các migration D04 chưa có trong danh sách runtime vì chưa được tạo/áp dụng.
- Pending gồm H02 approval support, messaging contract/message sending, file scan evidence, realtime sessions và hai migration BE-K04.
- Đây là trạng thái runtime Docker local duy nhất đã đọc. Không chạy migration trong D04-01; không suy ra trạng thái database khác.

Trước rollout, D04-21 phải phân loại pending theo môi trường đích và runbook. Không chạy pending migration ngoài scope một cách tự động.

## Kết quả

D04-01 actual baseline **đạt ở mức source, dependencies, route/OpenAPI và migration status runtime local**. Không chạy migration, test, seed, reset hay mutation nghiệp vụ. Hai report môi trường được lưu riêng; test database chưa khởi động và không được gán kết quả từ runtime local.
