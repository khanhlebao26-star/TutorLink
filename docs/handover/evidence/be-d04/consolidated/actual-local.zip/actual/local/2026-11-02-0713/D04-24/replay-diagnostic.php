<?php

declare(strict_types=1);

use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

require '/var/www/html/vendor/autoload.php';
$app = require '/var/www/html/bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();

function demand(bool $condition, string $message): void
{
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

function canonical(mixed $value): mixed
{
    if (! is_array($value)) return $value;
    if (! array_is_list($value)) ksort($value);
    foreach ($value as $key => $child) $value[$key] = canonical($child);
    return $value;
}

function diffPaths(mixed $left, mixed $right, string $path = '$'): array
{
    if (! is_array($left) || ! is_array($right)) return $left === $right ? [] : [$path];
    $paths = [];
    foreach (array_unique([...array_keys($left), ...array_keys($right)]) as $key) {
        $childPath = $path.'.'.$key;
        if (! array_key_exists($key, $left) || ! array_key_exists($key, $right)) {
            $paths[] = $childPath;
            continue;
        }
        $paths = [...$paths, ...diffPaths($left[$key], $right[$key], $childPath)];
    }
    return $paths;
}

function session(Client $client, array $actor): array
{
    $cookies = new CookieJar();
    $headers = ['Accept'=>'application/json','Origin'=>'http://localhost:3000','Referer'=>'http://localhost:3000/','X-Requested-With'=>'XMLHttpRequest'];
    $client->get('/sanctum/csrf-cookie', ['cookies'=>$cookies,'headers'=>$headers,'http_errors'=>false]);
    $xsrf = null;
    foreach ($cookies->toArray() as $cookie) if ($cookie['Name'] === 'XSRF-TOKEN') $xsrf = rawurldecode($cookie['Value']);
    demand($xsrf !== null, 'Missing CSRF cookie.');
    $login = $client->post('/api/v1/auth/login', ['cookies'=>$cookies,'headers'=>$headers+['X-XSRF-TOKEN'=>$xsrf],'http_errors'=>false,'json'=>['email'=>$actor['email'],'password'=>$actor['password']]]);
    demand($login->getStatusCode() === 200, 'Owner login failed.');
    return [$cookies,$headers];
}

function request(Client $client, array $session, array $entry): array
{
    [$cookies,$headers] = $session;
    $xsrf = null;
    foreach ($cookies->toArray() as $cookie) if ($cookie['Name'] === 'XSRF-TOKEN') $xsrf = rawurldecode($cookie['Value']);
    demand($xsrf !== null, 'Missing current CSRF cookie.');
    $headers['Idempotency-Key'] = $entry['idempotency_key'];
    $headers['X-XSRF-TOKEN'] = $xsrf;
    $response = $client->request($entry['method'], $entry['path'], ['cookies'=>$cookies,'headers'=>$headers,'http_errors'=>false,'json'=>$entry['request_json']]);
    $raw = (string) $response->getBody();
    return ['status'=>$response->getStatusCode(),'json'=>json_decode($raw,true),'raw'=>$raw];
}

demand(config('app.env') === 'local' && DB::connection()->getDatabaseName() === 'tutorlink', 'Refusing outside local/tutorlink.');
$auth = json_decode(file_get_contents('/tmp/d04-23-auth.json'), true, flags: JSON_THROW_ON_ERROR);
$lines = file('/tmp/d04-23/http-transcript-continuation.jsonl', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$entries = [];
foreach ($lines as $line) { $entry = json_decode($line, true, flags: JSON_THROW_ON_ERROR); $entries[$entry['case']] = $entry; }
$client = new Client(['base_uri'=>'http://localhost:8000','timeout'=>40]);
$owner = session($client, $auth['actors']['owner']);
$out = [];
foreach (['announcement-publish','fee-create','fee-mark-paid'] as $case) {
    $entry = $entries[$case];
    $actual = request($client, $owner, $entry);
    $expected = $entry['response_json'];
    $out[$case] = [
        'status'=>$actual['status'],
        'expected_status'=>$entry['status'],
        'body_matches'=>canonical($actual['json']) === canonical($expected),
        'diff_paths'=>diffPaths(canonical($actual['json']), canonical($expected)),
        'actual_top_level_keys'=>is_array($actual['json']) ? array_keys($actual['json']) : [],
        'expected_top_level_keys'=>is_array($expected) ? array_keys($expected) : [],
        'actual_body_sha256'=>hash('sha256',$actual['raw']),
        'expected_body_sha256'=>hash('sha256',json_encode($expected,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)),
    ];
}
echo json_encode(['observed_at_utc'=>now('UTC')->toIso8601String(),'replays'=>$out,'secrets_recorded'=>false],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)."\n";
