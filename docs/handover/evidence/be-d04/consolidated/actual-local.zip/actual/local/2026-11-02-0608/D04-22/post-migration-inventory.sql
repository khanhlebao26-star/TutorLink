BEGIN TRANSACTION READ ONLY;

SELECT table_name, row_count FROM (
    SELECT 'users' AS table_name, count(*)::bigint AS row_count FROM users
    UNION ALL SELECT 'programs', count(*) FROM programs
    UNION ALL SELECT 'program_sessions', count(*) FROM program_sessions
    UNION ALL SELECT 'progress_records', count(*) FROM progress_records
    UNION ALL SELECT 'announcements', count(*) FROM announcements
    UNION ALL SELECT 'fee_records', count(*) FROM fee_records
    UNION ALL SELECT 'files', count(*) FROM files
    UNION ALL SELECT 'file_links', count(*) FROM file_links
    UNION ALL SELECT 'audit_logs', count(*) FROM audit_logs
    UNION ALL SELECT 'notification_outbox', count(*) FROM notification_outbox
    UNION ALL SELECT 'notifications', count(*) FROM notifications
    UNION ALL SELECT 'idempotency_receipts', count(*) FROM idempotency_receipts
    UNION ALL SELECT 'conversations', count(*) FROM conversations
    UNION ALL SELECT 'messages', count(*) FROM messages
    UNION ALL SELECT 'migrations', count(*) FROM migrations
) counts ORDER BY table_name;

SELECT 'fee_status' AS group_name, status AS label, count(*)::bigint AS rows
FROM fee_records GROUP BY status ORDER BY status;

SELECT 'fee_payment_mark' AS group_name, tutor_payment_mark AS label, count(*)::bigint AS rows
FROM fee_records GROUP BY tutor_payment_mark ORDER BY tutor_payment_mark;

SELECT 'file_scan_status' AS group_name, scan_status AS label, count(*)::bigint AS rows
FROM files GROUP BY scan_status ORDER BY scan_status;

SELECT 'legacy_suspension_mapping' AS group_name,
       coalesce(status_before_suspension, '<null>') AS label,
       count(*)::bigint AS rows
FROM tutor_profiles GROUP BY status_before_suspension ORDER BY status_before_suspension NULLS FIRST;

SELECT 'fee_records_d04' AS table_name, conname AS constraint_name, pg_get_constraintdef(oid) AS definition
FROM pg_constraint WHERE conrelid = 'fee_records'::regclass AND conname LIKE 'fee_records_d04_%'
UNION ALL
SELECT 'progress_records', conname, pg_get_constraintdef(oid)
FROM pg_constraint WHERE conrelid = 'progress_records'::regclass AND conname LIKE 'progress_records_d04_%'
UNION ALL
SELECT 'announcements', conname, pg_get_constraintdef(oid)
FROM pg_constraint WHERE conrelid = 'announcements'::regclass AND conname LIKE 'announcements_d04_%'
ORDER BY table_name, constraint_name;

SELECT table_name, column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND (table_name, column_name) IN (
      ('fee_records', 'tutor_payment_mark'), ('fee_records', 'voided_at'),
      ('fee_records', 'voided_by'), ('fee_records', 'payment_marked_at'),
      ('fee_records', 'payment_marked_by'), ('fee_records', 'last_change_reason'),
      ('fee_records', 'version'), ('progress_records', 'version'),
      ('announcements', 'version'), ('program_sessions', 'version'),
      ('program_sessions', 'terminal_replay'), ('files', 'scanned_at'),
      ('files', 'scan_engine')
  ) ORDER BY table_name, column_name;

COMMIT;
