# D04-22 — Test report

**Result: PASS.** The release candidate was tested against the isolated test environment before applying it to the local project database.

## Test gates

- Backend regression outside D04: **627 tests, 4,545 assertions passed**.
- D04 feature regression: **77 tests, 1,077 assertions passed**.
- PostgreSQL race test: **1 test, 893 assertions passed**.
- Migration preflight: **7 tests, 27 assertions passed**.
- HTTP API matrix: **96/96 cases passed**, covering all 16 D04 operations; publish and Fee replay snapshots matched.
- Exact migration rehearsal: **9 Pending migrations became Ran** on an isolated clone restored from the D04-21 backup.
- Post-migration schema inventory: expected metadata and 13 D04 constraints present; no D04 business rows created.
- Final `tutorlink_test` restore: **PASS**, byte-identical to the D04-18 checkpoint; 29 migrations, 4 Programs, 59 Fees, 55 Progress records, 4 Announcements, 1 Announcement file link.

The Overview boundary regression was found and fixed before release: a session exactly at the current-time cutoff is excluded while the earlier future session is returned. The focused post-fix check passed **4 tests / 62 assertions**.

## Runtime candidate

- Image: `sha256:8f1589bfc233765bedce705b2c802fb319f9d10a821ed1a46b57577c2e605411`.
- PHP 8.3.36; Laravel 13.35.0; `pcntl`, `pdo_pgsql`, and `zip` available.
- The tested source hash and build context are recorded in [release-manifest.json](release-manifest.json).

## Evidence

- [Backend regression after fix](full-backend-regression-after-fix.txt)
- [D04 regression and race results](candidate-d04-regression-after-fix.txt)
- [Migration preflight](candidate-migration-preflight.txt)
- [Exact migration rehearsal](candidate-migration-rehearsal-after-fix.txt), [status after](candidate-migration-status-after.txt), and [post-migration inventory](post-migration-inventory-after-fix.txt)
- [HTTP API matrix summary](http-run-after-fix.txt), [request/response transcript](http-transcript.jsonl), and [fixture adjustment record](http-fixture-adjustment.json)
- [Test database restore comparison](test-db-restore-check.txt) and [restored snapshot inventory](test-db-restored-snapshot.txt)

Actual D04 business API mutations are tracked separately under D04-23.
