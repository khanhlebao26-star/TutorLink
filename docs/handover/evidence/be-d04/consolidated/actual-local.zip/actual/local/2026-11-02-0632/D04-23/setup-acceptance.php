<?php

declare(strict_types=1);

use App\Models\User;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Support\Facades\DB;

require '/var/www/html/vendor/autoload.php';
$app = require '/var/www/html/bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();

$database = DB::connection()->getDatabaseName();
$environment = (string) config('app.env');
if ($database !== 'tutorlink' || $environment !== 'local') {
    throw new RuntimeException("Refusing acceptance fixture setup on {$environment}/{$database}.");
}

$prefix = 'be-d04-23-';
if (DB::table('users')->where('email', 'like', $prefix.'%@tutorlink.test')->exists()) {
    throw new RuntimeException('D04-23 synthetic actors already exist; refusing duplicate setup.');
}

foreach (['programs', 'progress_records', 'announcements', 'fee_records', 'file_links', 'idempotency_receipts'] as $table) {
    if (DB::table($table)->exists()) {
        throw new RuntimeException("Expected an empty D04 acceptance table before setup: {$table}.");
    }
}

$password = bin2hex(random_bytes(24));
$now = now('UTC');

$fixture = DB::transaction(function () use ($now, $password): array {
    $makeUser = static function (string $handle, string $role) use ($now, $password): User {
        $user = User::factory()->create([
            'full_name' => 'D04-23 Acceptance '.ucfirst($handle),
            'email' => "be-d04-23-{$handle}@tutorlink.test",
            'email_verified_at' => $now,
            'password_hash' => $password,
            'role' => $role,
            'status' => 'active',
            'permissions' => [],
            'date_of_birth' => '1990-01-01',
            'terms_version' => 'd04-23-acceptance-v1',
        ]);

        if ($role === 'tutor') {
            $user->tutorProfile()->create([
                'headline' => 'D04-23 Acceptance Tutor',
                'bio' => 'Synthetic local acceptance actor.',
                'status' => 'approved',
                'approval_status' => 'active',
                'submitted_at' => $now,
                'reviewed_at' => $now,
            ]);
        } else {
            $user->customerProfile()->create([
                'city' => 'Ha Noi',
                'district' => 'Ba Dinh',
                'bio' => 'Synthetic local acceptance actor.',
            ]);
        }

        return $user->fresh('tutorProfile', 'customerProfile');
    };

    $owner = $makeUser('owner', 'tutor');
    $member = $makeUser('member', 'customer');
    $outsider = $makeUser('outsider', 'customer');

    $makeProgram = static function (string $label, string $title, User $owner, User $member, $now): int {
        $programId = DB::table('programs')->insertGetId([
            'owner_tutor_profile_id' => $owner->tutorProfile->id,
            'source_listing_id' => null,
            'customer_id' => $member->id,
            'version' => 1,
            'title' => $title,
            'goal' => "Synthetic D04-23 {$label} acceptance Program.",
            'level' => 'Intermediate',
            'delivery_mode' => 'online',
            'agreed_fee_minor' => 300000,
            'currency' => 'VND',
            'fee_unit' => 'session',
            'location_text' => null,
            'meeting_url' => null,
            'schedule_note' => 'D04-23 acceptance only.',
            'timezone' => 'Asia/Ho_Chi_Minh',
            'planned_session_count' => 4,
            'status' => 'active',
            'offer_snapshot' => null,
            'snapshot_locked_at' => null,
            'activated_at' => $now,
            'ends_at' => null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        DB::table('program_members')->insert([
            'program_id' => $programId,
            'user_id' => $member->id,
            'member_role' => 'customer',
            'status' => 'active',
            'joined_at' => $now,
            'left_at' => null,
            'created_at' => $now,
            'updated_at' => $now,
        ]);

        return $programId;
    };

    return [
        'owner_id' => (int) $owner->id,
        'owner_email' => $owner->email,
        'member_id' => (int) $member->id,
        'member_email' => $member->email,
        'outsider_id' => (int) $outsider->id,
        'outsider_email' => $outsider->email,
        'active_program_id' => $makeProgram('workspace', 'D04-23 ACCEPTANCE Workspace — retain synthetic evidence', $owner, $member, $now),
        'terminal_program_id' => $makeProgram('terminal', 'D04-23 ACCEPTANCE Terminal — retain synthetic evidence', $owner, $member, $now),
    ];
});

$authPath = '/tmp/d04-23-auth.json';
file_put_contents($authPath, json_encode([
    'password' => $password,
    'actors' => [
        'owner' => ['email' => $fixture['owner_email'], 'password' => $password],
        'member' => ['email' => $fixture['member_email'], 'password' => $password],
        'outsider' => ['email' => $fixture['outsider_email'], 'password' => $password],
    ],
], JSON_THROW_ON_ERROR));
chmod($authPath, 0600);

unset($fixture['owner_email'], $fixture['member_email'], $fixture['outsider_email']);
$fixture['database'] = $database;
$fixture['environment'] = $environment;
$fixture['created_at_utc'] = $now->toIso8601String();
$fixture['auth_secret_path'] = $authPath;

echo json_encode($fixture, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)."\n";
