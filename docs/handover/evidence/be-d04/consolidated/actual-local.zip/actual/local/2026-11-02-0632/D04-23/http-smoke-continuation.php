<?php

declare(strict_types=1);

use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;

require '/var/www/html/vendor/autoload.php';

final class D04ContinuationSession
{
    public function __construct(public readonly string $label, public readonly CookieJar $cookies) {}

    public function xsrf(): string
    {
        foreach ($this->cookies->toArray() as $cookie) {
            if ($cookie['Name'] === 'XSRF-TOKEN') {
                return rawurldecode($cookie['Value']);
            }
        }
        throw new RuntimeException('Missing XSRF cookie.');
    }
}

final class D04Continuation
{
    private Client $client;
    private array $fixture;
    private array $auth;
    private array $records = [];
    private array $covered = [];
    private string $directory = '/tmp/d04-23';
    private string $transcript = '/tmp/d04-23/http-transcript-continuation.jsonl';

    private const REQUIRED = [
        'GET /api/v1/programs/{program}/overview',
        'GET /api/v1/programs/{program}/progress-records',
        'POST /api/v1/programs/{program}/progress-records',
        'PATCH /api/v1/progress-records/{progressRecord}',
        'GET /api/v1/programs/{program}/announcements',
        'POST /api/v1/programs/{program}/announcements',
        'GET /api/v1/announcements/{announcement}',
        'PATCH /api/v1/announcements/{announcement}',
        'POST /api/v1/announcements/{announcement}/publish',
        'GET /api/v1/programs/{program}/fee-records',
        'POST /api/v1/programs/{program}/fee-records',
        'GET /api/v1/fee-records/{feeRecord}',
        'PATCH /api/v1/fee-records/{feeRecord}',
        'POST /api/v1/fee-records/{feeRecord}/mark-paid',
        'POST /api/v1/fee-records/{feeRecord}/mark-unpaid',
        'POST /api/v1/fee-records/{feeRecord}/void',
    ];

    public function __construct()
    {
        $this->fixture = json_decode(file_get_contents($this->directory.'/fixture-ids.json'), true, flags: JSON_THROW_ON_ERROR);
        $this->auth = json_decode(file_get_contents('/tmp/d04-23-auth.json'), true, flags: JSON_THROW_ON_ERROR);
        $this->client = new Client(['base_uri' => 'http://localhost:8000', 'timeout' => 60]);
        if (is_file($this->transcript)) {
            throw new RuntimeException('Continuation transcript exists; refusing to overwrite it.');
        }
    }

    private function assert(bool $condition, string $message): void
    {
        if (! $condition) {
            throw new RuntimeException($message);
        }
    }

    private function canonical(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (! array_is_list($value)) {
            ksort($value);
        }
        foreach ($value as $key => $child) {
            $value[$key] = $this->canonical($child);
        }
        return $value;
    }

    private function key(): string
    {
        $b = random_bytes(16);
        $b[6] = chr((ord($b[6]) & 0x0f) | 0x40);
        $b[8] = chr((ord($b[8]) & 0x3f) | 0x80);
        $h = bin2hex($b);
        return substr($h, 0, 8).'-'.substr($h, 8, 4).'-'.substr($h, 12, 4).'-'.substr($h, 16, 4).'-'.substr($h, 20);
    }

    private function login(string $label): D04ContinuationSession
    {
        $session = new D04ContinuationSession($label, new CookieJar());
        $common = ['Accept' => 'application/json', 'Origin' => 'http://localhost:3000', 'Referer' => 'http://localhost:3000/', 'X-Requested-With' => 'XMLHttpRequest'];
        $csrf = $this->client->get('/sanctum/csrf-cookie', ['cookies' => $session->cookies, 'headers' => $common, 'http_errors' => false]);
        $this->assert($csrf->getStatusCode() === 204, "{$label} CSRF bootstrap failed.");
        $this->recordMeta($label, 'GET', '/sanctum/csrf-cookie', 'continuation-csrf-'.$label, 204, $csrf->getStatusCode());
        $login = $this->request($session, 'POST', '/api/v1/auth/login', 'continuation-login-'.$label, 200, [
            'email' => $this->auth['actors'][$label]['email'],
            'password' => $this->auth['actors'][$label]['password'],
        ]);
        return $session;
    }

    private function recordMeta(string $actor, string $method, string $path, string $case, int $expected, int $status): void
    {
        $entry = ['case' => $case, 'method' => $method, 'path' => $path, 'expected_status' => $expected, 'status' => $status, 'actor' => $actor, 'session_cookie_sent' => false, 'csrf_header_sent' => false];
        file_put_contents($this->transcript, json_encode($entry, JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)."\n", FILE_APPEND);
        $this->records[] = $entry;
    }

    private function request(
        ?D04ContinuationSession $session,
        string $method,
        string $path,
        string $case,
        int $expected,
        ?array $json = null,
        array $headers = [],
        ?array $multipart = null,
        bool $download = false,
        ?string $operation = null,
    ): array {
        $requestHeaders = ['Accept' => 'application/json', 'Origin' => 'http://localhost:3000', 'Referer' => 'http://localhost:3000/', 'X-Requested-With' => 'XMLHttpRequest'] + $headers;
        if ($session !== null && ! in_array(strtoupper($method), ['GET', 'HEAD', 'OPTIONS'], true)) {
            $requestHeaders['X-XSRF-TOKEN'] = $session->xsrf();
        }
        $options = ['headers' => $requestHeaders, 'http_errors' => false];
        if ($session !== null) {
            $options['cookies'] = $session->cookies;
        }
        if ($json !== null) {
            $options['json'] = $json;
        }
        if ($multipart !== null) {
            $options['multipart'] = $multipart;
        }
        $response = $this->client->request($method, $path, $options);
        $status = $response->getStatusCode();
        $raw = (string) $response->getBody();
        $contentType = $response->getHeaderLine('Content-Type');
        $decoded = str_contains($contentType, 'json') && $raw !== '' ? json_decode($raw, true) : null;
        $entry = [
            'case' => $case,
            'operation' => $operation,
            'method' => strtoupper($method),
            'path' => $path,
            'expected_status' => $expected,
            'status' => $status,
            'actor' => $session?->label ?? 'anonymous',
            'session_cookie_sent' => $session !== null,
            'csrf_header_sent' => isset($requestHeaders['X-XSRF-TOKEN']),
            'idempotency_key' => $requestHeaders['Idempotency-Key'] ?? null,
            'response_headers' => array_filter(['x-request-id' => $response->getHeaderLine('X-Request-ID') ?: null, 'content-type' => $contentType ?: null, 'content-disposition' => $response->getHeaderLine('Content-Disposition') ?: null]),
        ];
        if ($json !== null) {
            $safe = $json;
            if (str_contains($case, 'login')) {
                $safe['password'] = '[REDACTED]';
            }
            $entry['request_json'] = $safe;
        }
        if ($multipart !== null) {
            $entry['request_multipart'] = array_map(static fn (array $part): array => isset($part['filename'])
                ? ['name' => $part['name'], 'filename' => $part['filename'], 'bytes' => strlen((string) $part['contents']), 'sha256' => hash('sha256', (string) $part['contents'])]
                : ['name' => $part['name'], 'value' => $part['contents']], $multipart);
        }
        if ($download) {
            $target = $this->directory.'/download-'.$case.'.pdf';
            file_put_contents($target, $raw);
            $entry['response_download'] = ['bytes' => strlen($raw), 'sha256' => hash('sha256', $raw), 'evidence_file' => basename($target)];
        } elseif ($decoded !== null) {
            $entry['response_json'] = $decoded;
        } elseif ($raw !== '') {
            $entry['response_text_sha256'] = hash('sha256', $raw);
            $entry['response_text_bytes'] = strlen($raw);
        }
        file_put_contents($this->transcript, json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)."\n", FILE_APPEND);
        $this->records[] = $entry;
        if ($operation !== null) {
            $this->covered[$operation] = true;
        }
        $this->assert($status === $expected, "{$case}: expected HTTP {$expected}, got {$status}; continuation transcript is preserved.");
        return ['status' => $status, 'body' => $decoded, 'entry' => $entry];
    }

    private function data(array $r): array
    {
        return $r['body']['data'] ?? throw new RuntimeException('Expected JSON data envelope.');
    }

    private function previous(): array
    {
        $all = [];
        foreach (file('/tmp/d04-23/http-transcript.jsonl', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $entry = json_decode($line, true, flags: JSON_THROW_ON_ERROR);
            $all[$entry['case']] = $entry;
            if (! empty($entry['operation'])) {
                $this->covered[$entry['operation']] = true;
            }
        }
        $this->assert(($all['progress-create']['response_json']['data']['id'] ?? null) === 1, 'Preliminary Progress evidence is incomplete.');
        $this->assert(($all['announcement-draft-create']['response_json']['data']['id'] ?? null) === 1, 'Preliminary Draft evidence is incomplete.');
        $this->assert(($all['announcement-file-upload']['response_json']['data']['id'] ?? null) === 25, 'Preliminary upload evidence is incomplete.');
        $this->assert(($all['announcement-file-member-before-publish-hidden']['status'] ?? null) === 403, 'Expected the recorded unlinked private File denial.');
        return [
            'progress_id' => (int) $all['progress-create']['response_json']['data']['id'],
            'announcement_id' => (int) $all['announcement-draft-create']['response_json']['data']['id'],
            'file_id' => (int) $all['announcement-file-upload']['response_json']['data']['id'],
        ];
    }

    public function run(): void
    {
        $ids = $this->previous();
        $program = (int) $this->fixture['active_program_id'];
        $terminalProgram = (int) $this->fixture['terminal_program_id'];
        $owner = $this->login('owner');
        $member = $this->login('member');
        $pdf = "%PDF-1.4\n% D04-23 synthetic attachment.\n1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n2 0 obj << /Type /Pages /Kids [] /Count 0 >> endobj\ntrailer << /Root 1 0 R >>\n%%EOF\n";

        $draft = $this->data($this->request($owner, 'PATCH', "/api/v1/announcements/{$ids['announcement_id']}", 'announcement-file-attach', 200, [
            'expected_version' => 2, 'file_ids' => [$ids['file_id']],
        ], operation: 'PATCH /api/v1/announcements/{announcement}'));
        $this->assert(($draft['version'] ?? null) === 3 && count($draft['files'] ?? []) === 1, 'Attachment was not linked to the Draft.');
        $this->request($member, 'GET', "/api/v1/files/{$ids['file_id']}/download", 'announcement-file-member-attached-draft-hidden', 404);

        $publishKey = $this->key();
        $publishBody = ['expected_version' => 3];
        $publishedResult = $this->request($owner, 'POST', "/api/v1/announcements/{$ids['announcement_id']}/publish", 'announcement-publish', 200, $publishBody, ['Idempotency-Key' => $publishKey], operation: 'POST /api/v1/announcements/{announcement}/publish');
        $published = $this->data($publishedResult);
        $publishReplay = $this->request($owner, 'POST', "/api/v1/announcements/{$ids['announcement_id']}/publish", 'announcement-publish-replay', 200, $publishBody, ['Idempotency-Key' => $publishKey], operation: 'POST /api/v1/announcements/{announcement}/publish');
        $this->assert($this->canonical($publishedResult['body']) === $this->canonical($publishReplay['body']), 'Announcement publish replay changed its response snapshot.');
        $this->assert(($published['state'] ?? null) === 'published' && ($published['version'] ?? null) === 4, 'Announcement did not publish at expected version.');
        $this->request($owner, 'PATCH', "/api/v1/announcements/{$ids['announcement_id']}", 'announcement-published-immutable', 409, ['expected_version' => 4, 'title' => 'Must remain immutable.'], operation: 'PATCH /api/v1/announcements/{announcement}');
        $this->request($member, 'GET', "/api/v1/programs/{$program}/announcements", 'announcement-member-published-list', 200, operation: 'GET /api/v1/programs/{program}/announcements');
        $this->request($member, 'GET', "/api/v1/announcements/{$ids['announcement_id']}", 'announcement-member-published-detail', 200, operation: 'GET /api/v1/announcements/{announcement}');
        $this->request($member, 'GET', "/api/v1/files/{$ids['file_id']}", 'announcement-file-member-published-metadata', 200);
        $download = $this->request($member, 'GET', "/api/v1/files/{$ids['file_id']}/download", 'announcement-file-member-published-download', 200, download: true);
        $this->assert(($download['entry']['response_download']['sha256'] ?? null) === hash('sha256', $pdf), 'Published attachment bytes checksum mismatch.');

        $feeList = "/api/v1/programs/{$program}/fee-records";
        $this->request($owner, 'GET', $feeList.'?period=2026-11&status=declared&tutor_payment_mark=unmarked', 'fee-owner-list', 200, operation: 'GET /api/v1/programs/{program}/fee-records');
        $feeBody = ['period' => '2026-11', 'amount_minor' => 500000, 'currency' => 'VND'];
        $createKey = $this->key();
        $feeResult = $this->request($owner, 'POST', $feeList, 'fee-create', 201, $feeBody, ['Idempotency-Key' => $createKey], operation: 'POST /api/v1/programs/{program}/fee-records');
        $fee = $this->data($feeResult);
        $feeId = (int) $fee['id'];
        $feeReplay = $this->request($owner, 'POST', $feeList, 'fee-create-replay', 201, $feeBody, ['Idempotency-Key' => $createKey], operation: 'POST /api/v1/programs/{program}/fee-records');
        $this->assert($this->canonical($feeResult['body']) === $this->canonical($feeReplay['body']), 'Fee create replay changed its response snapshot.');
        $this->request($owner, 'POST', $feeList, 'fee-duplicate-month-conflict', 409, $feeBody, ['Idempotency-Key' => $this->key()], operation: 'POST /api/v1/programs/{program}/fee-records');
        $this->request($owner, 'GET', "/api/v1/fee-records/{$feeId}", 'fee-owner-detail', 200, operation: 'GET /api/v1/fee-records/{feeRecord}');
        $this->request($member, 'GET', $feeList.'?period=2026-11', 'fee-member-list', 200, operation: 'GET /api/v1/programs/{program}/fee-records');
        $this->request($member, 'GET', "/api/v1/fee-records/{$feeId}", 'fee-member-detail', 200, operation: 'GET /api/v1/fee-records/{feeRecord}');

        $noop = $this->data($this->request($owner, 'PATCH', "/api/v1/fee-records/{$feeId}", 'fee-same-value-noop', 200, ['expected_version' => 1, 'amount_minor' => 500000, 'reason' => 'D04-23 no-op.'], ['Idempotency-Key' => $this->key()], operation: 'PATCH /api/v1/fee-records/{feeRecord}'));
        $this->assert(($noop['version'] ?? null) === 1, 'Fee same-value no-op changed version.');
        $updated = $this->data($this->request($owner, 'PATCH', "/api/v1/fee-records/{$feeId}", 'fee-update', 200, ['expected_version' => 1, 'amount_minor' => 600000, 'reason' => 'D04-23 synthetic amount adjustment.'], ['Idempotency-Key' => $this->key()], operation: 'PATCH /api/v1/fee-records/{feeRecord}'));
        $this->assert(($updated['version'] ?? null) === 2 && ($updated['amount_minor'] ?? null) === 600000, 'Fee update failed.');
        $this->request($owner, 'PATCH', "/api/v1/fee-records/{$feeId}", 'fee-stale-409', 409, ['expected_version' => 1, 'amount_minor' => 610000, 'reason' => 'Stale acceptance update.'], ['Idempotency-Key' => $this->key()], operation: 'PATCH /api/v1/fee-records/{feeRecord}');

        $paidKey = $this->key();
        $paidBody = ['expected_version' => 2];
        $paidResult = $this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/mark-paid", 'fee-mark-paid', 200, $paidBody, ['Idempotency-Key' => $paidKey], operation: 'POST /api/v1/fee-records/{feeRecord}/mark-paid');
        $paidReplay = $this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/mark-paid", 'fee-mark-paid-replay', 200, $paidBody, ['Idempotency-Key' => $paidKey], operation: 'POST /api/v1/fee-records/{feeRecord}/mark-paid');
        $this->assert($this->canonical($paidResult['body']) === $this->canonical($paidReplay['body']), 'Fee paid replay changed its response snapshot.');
        $paid = $this->data($paidResult);
        $this->assert(($paid['version'] ?? null) === 3 && ($paid['tutor_payment_mark'] ?? null) === 'marked_paid', 'Fee paid transition failed.');
        $paidNoop = $this->data($this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/mark-paid", 'fee-mark-paid-noop', 200, ['expected_version' => 3], ['Idempotency-Key' => $this->key()], operation: 'POST /api/v1/fee-records/{feeRecord}/mark-paid'));
        $this->assert(($paidNoop['version'] ?? null) === 3, 'Fee mark-paid no-op changed version.');
        $unpaid = $this->data($this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/mark-unpaid", 'fee-mark-unpaid', 200, ['expected_version' => 3, 'reason' => 'D04-23 synthetic correction.'], ['Idempotency-Key' => $this->key()], operation: 'POST /api/v1/fee-records/{feeRecord}/mark-unpaid'));
        $this->assert(($unpaid['version'] ?? null) === 4 && ($unpaid['tutor_payment_mark'] ?? null) === 'marked_unpaid', 'Fee unpaid transition failed.');
        $voided = $this->data($this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/void", 'fee-void', 200, ['expected_version' => 4, 'reason' => 'D04-23 synthetic Fee completed.'], ['Idempotency-Key' => $this->key()], operation: 'POST /api/v1/fee-records/{feeRecord}/void'));
        $this->assert(($voided['status'] ?? null) === 'voided' && ($voided['version'] ?? null) === 5 && ($voided['tutor_payment_mark'] ?? null) === 'marked_unpaid', 'Fee void fields/version mismatch.');
        $this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/mark-paid", 'fee-voided-mark-conflict', 409, ['expected_version' => 5], ['Idempotency-Key' => $this->key()], operation: 'POST /api/v1/fee-records/{feeRecord}/mark-paid');
        $this->request($owner, 'GET', "/api/v1/fee-records/{$feeId}", 'fee-owner-detail-voided', 200, operation: 'GET /api/v1/fee-records/{feeRecord}');
        $this->request($member, 'GET', "/api/v1/fee-records/{$feeId}", 'fee-member-detail-voided', 200, operation: 'GET /api/v1/fee-records/{feeRecord}');
        $this->request($owner, 'GET', "/api/v1/programs/{$program}/overview", 'overview-owner-after', 200, operation: 'GET /api/v1/programs/{program}/overview');
        $this->request($member, 'GET', "/api/v1/programs/{$program}/overview", 'overview-member-after', 200, operation: 'GET /api/v1/programs/{program}/overview');

        $cancel = $this->data($this->request($owner, 'POST', "/api/v1/programs/{$terminalProgram}/cancel", 'terminal-program-cancel', 200, []));
        $this->assert(($cancel['status'] ?? null) === 'cancelled', 'Synthetic terminal Program did not cancel.');
        $this->request($owner, 'POST', "/api/v1/programs/{$terminalProgram}/progress-records", 'terminal-program-progress-conflict', 409, ['metric_name' => 'progress_percent', 'value' => 1]);

        $missing = array_values(array_diff(self::REQUIRED, array_keys($this->covered)));
        $this->assert($missing === [], 'Missing D04 operations: '.implode(', ', $missing));
        $summary = [
            'result' => 'PASS',
            'target_url' => 'http://localhost:8000',
            'database' => 'tutorlink',
            'program_ids' => ['workspace' => $program, 'terminal_cancelled' => $terminalProgram],
            'progress_id' => $ids['progress_id'],
            'announcement_id' => $ids['announcement_id'],
            'file_id' => $ids['file_id'],
            'fee_id' => $feeId,
            'd04_operations_covered' => count($this->covered),
            'd04_operations' => array_keys($this->covered),
            'continuation_requests' => count($this->records),
            'publish_replay_equal' => true,
            'fee_create_replay_equal' => true,
            'fee_mark_paid_replay_equal' => true,
            'fee_final' => ['status' => $voided['status'], 'version' => $voided['version'], 'tutor_payment_mark' => $voided['tutor_payment_mark']],
            'published_file_download_sha256' => hash('sha256', $pdf),
            'synthetic_records_retained' => true,
            'cookies_and_csrf_tokens_written_to_evidence' => false,
            'preliminary_unlinked_file_attempt' => 'HTTP 403 before attachment; preserved separately, expected owner-only private file behavior',
        ];
        file_put_contents($this->directory.'/http-summary-final.json', json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
        file_put_contents($this->directory.'/run-status-final.json', json_encode(['result' => 'PASS', 'finished_at_utc' => gmdate(DATE_ATOM), 'continuation_requests' => count($this->records)], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
        echo json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)."\n";
    }
}

try {
    (new D04Continuation())->run();
} catch (Throwable $error) {
    file_put_contents('/tmp/d04-23/run-status-continuation.json', json_encode([
        'result' => 'FAIL', 'error_class' => get_class($error), 'error_message' => $error->getMessage(),
        'request_count' => is_file('/tmp/d04-23/http-transcript-continuation.jsonl') ? count(file('/tmp/d04-23/http-transcript-continuation.jsonl')) : 0,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
    fwrite(STDERR, $error->getMessage()."\n");
    exit(1);
}
