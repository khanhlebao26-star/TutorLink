<?php

declare(strict_types=1);

use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;

require '/var/www/html/vendor/autoload.php';

$auth = json_decode(file_get_contents('/tmp/d04-23-auth.json'), true, flags: JSON_THROW_ON_ERROR);
$fixtures = json_decode(file_get_contents('/tmp/d04-23/fixture-ids.json'), true, flags: JSON_THROW_ON_ERROR);
$client = new Client([
    'base_uri' => 'http://localhost:8000',
    'timeout' => 20,
    'headers' => [
        'Origin' => 'http://localhost:3000',
        'Referer' => 'http://localhost:3000/',
        'X-Requested-With' => 'XMLHttpRequest',
    ],
]);
$result = ['target' => 'local backend; database tutorlink', 'sessions' => [], 'checks' => []];
$sessions = [];

foreach (['owner', 'member', 'outsider'] as $label) {
    $cookies = new CookieJar();
    $csrf = $client->get('/sanctum/csrf-cookie', ['cookies' => $cookies, 'headers' => ['Accept' => 'application/json']]);
    $xsrf = null;
    foreach ($cookies->toArray() as $cookie) {
        if ($cookie['Name'] === 'XSRF-TOKEN') {
            $xsrf = rawurldecode($cookie['Value']);
        }
    }
    if ($csrf->getStatusCode() !== 204 || $xsrf === null) {
        throw new RuntimeException("{$label} CSRF preflight failed.");
    }
    $login = $client->post('/api/v1/auth/login', [
        'cookies' => $cookies,
        'http_errors' => false,
        'headers' => ['Accept' => 'application/json', 'X-XSRF-TOKEN' => $xsrf, 'X-Requested-With' => 'XMLHttpRequest'],
        'json' => $auth['actors'][$label],
    ]);
    if ($login->getStatusCode() !== 200) {
        throw new RuntimeException("{$label} login returned HTTP {$login->getStatusCode()}.");
    }
    $sessions[$label] = $cookies;
    $result['sessions'][$label] = ['csrf' => 204, 'login' => 200, 'cookies_recorded' => false];
}

$program = (int) $fixtures['active_program_id'];
foreach ([['owner', 200], ['member', 200], ['outsider', 404]] as [$label, $expected]) {
    $response = $client->get("/api/v1/programs/{$program}/overview", [
        'cookies' => $sessions[$label],
        'http_errors' => false,
        'headers' => ['Accept' => 'application/json', 'X-Requested-With' => 'XMLHttpRequest'],
    ]);
    if ($response->getStatusCode() !== $expected) {
        throw new RuntimeException("{$label} overview scope expected HTTP {$expected}, got {$response->getStatusCode()}.");
    }
    $result['checks'][] = ['case' => $label.'-overview', 'status' => $expected];
}

echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)."\n";
