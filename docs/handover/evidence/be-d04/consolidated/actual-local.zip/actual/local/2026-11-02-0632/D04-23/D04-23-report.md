# D04-23 — Actual API smoke report

**Result: PASS on the local TutorLink Docker Compose environment.** The target was `http://localhost:8000`, backed by PostgreSQL database `tutorlink`. The smoke used three dedicated synthetic actors (IDs 52–54) and two clearly named synthetic Programs (IDs 1–2); it did not mutate any existing user's records.

## API results

- **16/16 D04 operations** were exercised in 63 HTTP requests across the preserved preliminary and continuation transcripts.
- Auth/CSRF/scope checks returned the expected results: anonymous 401, missing CSRF 419, outsider 404, owner/member Overview 200, and member draft-list restriction 403.
- Progress create/update reached version 2; a same-value PATCH left the version unchanged and a stale update returned 409.
- Announcement ID 1 was created, edited, attached to File ID 25, and published at version 4. Publish replay returned the same response snapshot. The published edit returned 409. The active synthetic member could read the published Announcement and download its attachment; the downloaded SHA-256 matched the uploaded bytes: `8f364131e47acdd40a15c9ac228fad522e610f6642862d37719c2b79f1f561fa`.
- Fee ID 1 was created for 2026-11, edited, marked paid, marked unpaid, and voided. The final state is `voided`, `marked_unpaid`, version 5. Create and mark-paid replay snapshots matched; no-op preserved version; stale, duplicate-month, and mark-after-void cases returned 409.
- Synthetic Program ID 2 was cancelled through the Program API; a subsequent Progress write was rejected with 409.

## File ordering diagnostic

The preserved preliminary trace contains one extra request made too early: it tried to download the private File before attaching it to the Draft and received 403. The final contractual sequence was then exercised: after attachment, member download of the Draft file returned 404; after publish, the member read and download returned 200. This was a harness ordering correction; no application source change was needed.

## Data, audit, and notifications

Only the synthetic acceptance records were added. Existing accounts were not modified. The acceptance Fee, Published Announcement, file, idempotency receipts, and history were retained for D04-24 and the configured purge policy; no Fee or Published Announcement was hard-deleted.

The runtime worker processed **7/7** scoped outbox events once each (`attempt_count=1`), with 0 pending, 0 failed, and 0 duplicate event keys. Seven matching notification records were present, with no duplicate event keys. The scoped audit snapshots include before/after values, version, state, actor, reason, file link and request ID presence. Same-value Progress/Fee requests added no duplicate state audit or notification. The database holds eight idempotency receipts. Jobs remained at 0. The 10-minute observation window is D04-24.

## Evidence

- [Evidence index](evidence-index.md)
- [Final HTTP summary](http-summary-final.json), [case/status summary](http-case-summary.json), [preflight identity and counts](preflight.json), and [session/scope preflight](preflight-http.json)
- [Preliminary HTTP transcript](http-preliminary-transcript.jsonl) and [continuation transcript](http-transcript-continuation.jsonl); cookies and CSRF values are not recorded
- [Database before/after counts](database-before-after.json), [scoped final state and receipt inventory](database-scope-final.json), [audit before/after fields](audit-field-evidence.json), and [worker/outbox events](notification-worker-verification.json)
- [Owner draft-file download](download-announcement-file-owner-draft.pdf) and [member published-file download](download-announcement-file-member-published.pdf)
- [Runtime log scan](runtime-log-summary.txt) and [candidate/runtime identity from D04-22](../../2026-11-02-0608/D04-22/release-manifest.json)

This is evidence for the local Docker Compose target only; it does not claim a remote staging or production smoke.
