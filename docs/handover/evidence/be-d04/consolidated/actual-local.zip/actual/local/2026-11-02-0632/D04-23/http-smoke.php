<?php

declare(strict_types=1);

use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;

require '/var/www/html/vendor/autoload.php';

final class D04ActualSession
{
    public function __construct(
        public readonly string $label,
        public readonly CookieJar $cookies,
    ) {}

    public function xsrf(): string
    {
        foreach ($this->cookies->toArray() as $cookie) {
            if ($cookie['Name'] === 'XSRF-TOKEN') {
                return rawurldecode($cookie['Value']);
            }
        }

        throw new RuntimeException("{$this->label}: XSRF cookie not found.");
    }
}

final class D04ActualSmoke
{
    private Client $client;
    private array $fixtures;
    private array $auth;
    private array $covered = [];
    private array $records = [];
    private string $directory = '/tmp/d04-23';
    private string $transcript = '/tmp/d04-23/http-transcript.jsonl';

    private const REQUIRED_OPERATIONS = [
        'GET /api/v1/programs/{program}/overview',
        'GET /api/v1/programs/{program}/progress-records',
        'POST /api/v1/programs/{program}/progress-records',
        'PATCH /api/v1/progress-records/{progressRecord}',
        'GET /api/v1/programs/{program}/announcements',
        'POST /api/v1/programs/{program}/announcements',
        'GET /api/v1/announcements/{announcement}',
        'PATCH /api/v1/announcements/{announcement}',
        'POST /api/v1/announcements/{announcement}/publish',
        'GET /api/v1/programs/{program}/fee-records',
        'POST /api/v1/programs/{program}/fee-records',
        'GET /api/v1/fee-records/{feeRecord}',
        'PATCH /api/v1/fee-records/{feeRecord}',
        'POST /api/v1/fee-records/{feeRecord}/mark-paid',
        'POST /api/v1/fee-records/{feeRecord}/mark-unpaid',
        'POST /api/v1/fee-records/{feeRecord}/void',
    ];

    public function __construct()
    {
        if (is_file($this->transcript)) {
            throw new RuntimeException('D04-23 transcript already exists; refusing to overwrite evidence.');
        }

        $this->fixtures = json_decode(file_get_contents($this->directory.'/fixture-ids.json'), true, flags: JSON_THROW_ON_ERROR);
        $this->auth = json_decode(file_get_contents('/tmp/d04-23-auth.json'), true, flags: JSON_THROW_ON_ERROR);
        $this->client = new Client(['base_uri' => 'http://localhost:8000', 'timeout' => 60]);
    }

    private function ensure(bool $condition, string $message): void
    {
        if (! $condition) {
            throw new RuntimeException($message);
        }
    }

    private function canonical(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (! array_is_list($value)) {
            ksort($value);
        }
        foreach ($value as $key => $child) {
            $value[$key] = $this->canonical($child);
        }

        return $value;
    }

    private function csrfSession(string $label): D04ActualSession
    {
        $session = new D04ActualSession($label, new CookieJar());
        $this->request($session, 'GET', '/sanctum/csrf-cookie', 'csrf-'.$label, 204);

        return $session;
    }

    private function login(string $label): D04ActualSession
    {
        $session = $this->csrfSession($label);
        $actor = $this->auth['actors'][$label];
        $this->request($session, 'POST', '/api/v1/auth/login', 'login-'.$label, 200, [
            'email' => $actor['email'],
            'password' => $actor['password'],
        ]);

        return $session;
    }

    private function request(
        ?D04ActualSession $session,
        string $method,
        string $path,
        string $case,
        int $expected,
        ?array $json = null,
        array $headers = [],
        ?array $multipart = null,
        bool $csrf = true,
        bool $download = false,
        ?string $operation = null,
    ): array {
        $requestHeaders = [
            'Accept' => 'application/json',
            'Origin' => 'http://localhost:3000',
            'Referer' => 'http://localhost:3000/',
            'X-Requested-With' => 'XMLHttpRequest',
        ] + $headers;
        if ($session !== null && $csrf && ! in_array(strtoupper($method), ['GET', 'HEAD', 'OPTIONS'], true)) {
            $requestHeaders['X-XSRF-TOKEN'] = $session->xsrf();
        }

        $options = ['headers' => $requestHeaders, 'http_errors' => false];
        if ($session !== null) {
            $options['cookies'] = $session->cookies;
        }
        if ($json !== null) {
            $options['json'] = $json;
        }
        if ($multipart !== null) {
            $options['multipart'] = $multipart;
        }

        $response = $this->client->request($method, $path, $options);
        $status = $response->getStatusCode();
        $body = (string) $response->getBody();
        $contentType = $response->getHeaderLine('Content-Type');
        $decoded = str_contains($contentType, 'json') && $body !== '' ? json_decode($body, true) : null;
        $entry = [
            'case' => $case,
            'operation' => $operation,
            'method' => strtoupper($method),
            'path' => $path,
            'expected_status' => $expected,
            'status' => $status,
            'actor' => $session?->label ?? 'anonymous',
            'session_cookie_sent' => $session !== null,
            'csrf_header_sent' => isset($requestHeaders['X-XSRF-TOKEN']),
            'idempotency_key' => $requestHeaders['Idempotency-Key'] ?? null,
            'response_headers' => array_filter([
                'x-request-id' => $response->getHeaderLine('X-Request-ID') ?: null,
                'content-type' => $contentType ?: null,
                'content-disposition' => $response->getHeaderLine('Content-Disposition') ?: null,
            ]),
        ];
        if ($json !== null) {
            $safeJson = $json;
            if (str_starts_with($case, 'login-')) {
                $safeJson['password'] = '[REDACTED]';
            }
            $entry['request_json'] = $safeJson;
        }
        if ($multipart !== null) {
            $entry['request_multipart'] = array_map(static function (array $part): array {
                $content = (string) ($part['contents'] ?? '');

                return isset($part['filename'])
                    ? ['name' => $part['name'] ?? null, 'filename' => $part['filename'], 'bytes' => strlen($content), 'sha256' => hash('sha256', $content)]
                    : ['name' => $part['name'] ?? null, 'value' => $content];
            }, $multipart);
        }
        if ($download) {
            $target = $this->directory.'/download-'.$case.'.pdf';
            file_put_contents($target, $body);
            $entry['response_download'] = ['bytes' => strlen($body), 'sha256' => hash('sha256', $body), 'evidence_file' => basename($target)];
        } elseif ($decoded !== null) {
            $entry['response_json'] = $decoded;
        } elseif ($body !== '') {
            $entry['response_text_sha256'] = hash('sha256', $body);
            $entry['response_text_bytes'] = strlen($body);
        }

        file_put_contents($this->transcript, json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)."\n", FILE_APPEND);
        $this->records[] = $entry;
        if ($operation !== null) {
            $this->covered[$operation] = true;
        }
        $this->ensure($status === $expected, "{$case}: expected HTTP {$expected}, got {$status}; transcript is preserved.");

        return ['status' => $status, 'body' => $decoded, 'raw' => $body, 'entry' => $entry];
    }

    private function data(array $response): array
    {
        return $response['body']['data'] ?? throw new RuntimeException('Expected JSON data envelope.');
    }

    private function key(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        $hex = bin2hex($bytes);

        return substr($hex, 0, 8).'-'.substr($hex, 8, 4).'-'.substr($hex, 12, 4).'-'.substr($hex, 16, 4).'-'.substr($hex, 20);
    }

    public function run(): void
    {
        $owner = $this->login('owner');
        $member = $this->login('member');
        $outsider = $this->login('outsider');
        $program = (int) $this->fixtures['active_program_id'];
        $terminalProgram = (int) $this->fixtures['terminal_program_id'];

        $this->request(null, 'GET', "/api/v1/programs/{$program}/overview", 'auth-anonymous-overview', 401);
        $this->request($owner, 'POST', "/api/v1/programs/{$program}/progress-records", 'auth-csrf-required', 419, ['metric_name' => 'progress_percent', 'value' => 1], csrf: false);
        $this->request($outsider, 'GET', "/api/v1/programs/{$program}/overview", 'auth-outsider-scope', 404);

        $overview = $this->request($owner, 'GET', "/api/v1/programs/{$program}/overview", 'overview-owner', 200, operation: 'GET /api/v1/programs/{program}/overview');
        $this->ensure(isset($overview['body']['data']), 'Overview response envelope missing.');
        $this->request($member, 'GET', "/api/v1/programs/{$program}/overview", 'overview-current-member', 200, operation: 'GET /api/v1/programs/{program}/overview');

        $progressPath = "/api/v1/programs/{$program}/progress-records";
        $this->request($owner, 'GET', $progressPath, 'progress-list', 200, operation: 'GET /api/v1/programs/{program}/progress-records');
        $progress = $this->data($this->request($owner, 'POST', $progressPath, 'progress-create', 201, [
            'metric_name' => 'progress_percent', 'value' => 42, 'note' => 'D04-23 synthetic acceptance evidence.',
        ], operation: 'POST /api/v1/programs/{program}/progress-records'));
        $progressId = (int) $progress['id'];
        $this->ensure(($progress['version'] ?? null) === 1 && ($progress['value'] ?? null) === 42, 'Progress create response values/version mismatch.');
        $progressNoop = $this->data($this->request($owner, 'PATCH', "/api/v1/progress-records/{$progressId}", 'progress-same-value-noop', 200, [
            'expected_version' => 1, 'value' => 42,
        ], operation: 'PATCH /api/v1/progress-records/{progressRecord}'));
        $this->ensure(($progressNoop['version'] ?? null) === 1, 'Progress no-op changed version.');
        $progress = $this->data($this->request($owner, 'PATCH', "/api/v1/progress-records/{$progressId}", 'progress-update', 200, [
            'expected_version' => 1, 'value' => 55,
        ], operation: 'PATCH /api/v1/progress-records/{progressRecord}'));
        $this->ensure(($progress['version'] ?? null) === 2 && ($progress['value'] ?? null) === 55, 'Progress update response mismatch.');
        $this->request($owner, 'PATCH', "/api/v1/progress-records/{$progressId}", 'progress-stale-409', 409, [
            'expected_version' => 1, 'value' => 56,
        ], operation: 'PATCH /api/v1/progress-records/{progressRecord}');

        $announcementList = "/api/v1/programs/{$program}/announcements";
        $this->request($owner, 'GET', $announcementList.'?state=draft', 'announcement-owner-draft-list', 200, operation: 'GET /api/v1/programs/{program}/announcements');
        $this->request($member, 'GET', $announcementList.'?state=draft', 'announcement-member-draft-list-forbidden', 403, operation: 'GET /api/v1/programs/{program}/announcements');
        $draft = $this->data($this->request($owner, 'POST', $announcementList, 'announcement-draft-create', 201, [
            'title' => 'D04-23 ACCEPTANCE Published Announcement',
            'body' => 'Synthetic API acceptance message; visible only to the acceptance Program member after publish.',
        ], operation: 'POST /api/v1/programs/{program}/announcements'));
        $announcementId = (int) $draft['id'];
        $this->ensure(($draft['state'] ?? null) === 'draft' && ($draft['version'] ?? null) === 1, 'Announcement draft response mismatch.');
        $this->request($owner, 'GET', "/api/v1/announcements/{$announcementId}", 'announcement-owner-draft-detail', 200, operation: 'GET /api/v1/announcements/{announcement}');
        $this->request($member, 'GET', "/api/v1/announcements/{$announcementId}", 'announcement-member-draft-hidden', 404, operation: 'GET /api/v1/announcements/{announcement}');
        $draft = $this->data($this->request($owner, 'PATCH', "/api/v1/announcements/{$announcementId}", 'announcement-draft-edit', 200, [
            'expected_version' => 1, 'body' => 'Updated synthetic D04-23 message.',
        ], operation: 'PATCH /api/v1/announcements/{announcement}'));
        $this->ensure(($draft['version'] ?? null) === 2, 'Announcement draft update did not increment version.');
        $this->request($owner, 'PATCH', "/api/v1/announcements/{$announcementId}", 'announcement-stale-409', 409, [
            'expected_version' => 1, 'title' => 'Stale synthetic update.',
        ], operation: 'PATCH /api/v1/announcements/{announcement}');

        $pdf = "%PDF-1.4\n% D04-23 synthetic attachment.\n1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n2 0 obj << /Type /Pages /Kids [] /Count 0 >> endobj\ntrailer << /Root 1 0 R >>\n%%EOF\n";
        $upload = $this->request($owner, 'POST', '/api/v1/files', 'announcement-file-upload', 201, multipart: [
            ['name' => 'file', 'contents' => $pdf, 'filename' => 'D04-23-acceptance.pdf', 'headers' => ['Content-Type' => 'application/pdf']],
            ['name' => 'purpose', 'contents' => 'announcement_attachment'],
        ]);
        $fileId = (int) ($upload['body']['data']['id'] ?? throw new RuntimeException('Uploaded File ID missing.'));
        $completedFile = $this->data($this->request($owner, 'POST', "/api/v1/files/{$fileId}/complete", 'announcement-file-complete', 200, []));
        $this->ensure(($completedFile['complete'] ?? null) === true, 'File complete response did not confirm completion.');
        $this->request($owner, 'GET', "/api/v1/files/{$fileId}", 'announcement-file-owner-metadata', 200);
        $this->request($owner, 'GET', "/api/v1/files/{$fileId}/download", 'announcement-file-owner-draft-download', 200, download: true);
        $this->request($member, 'GET', "/api/v1/files/{$fileId}/download", 'announcement-file-member-before-publish-hidden', 404);
        $draft = $this->data($this->request($owner, 'PATCH', "/api/v1/announcements/{$announcementId}", 'announcement-file-attach', 200, [
            'expected_version' => 2, 'file_ids' => [$fileId],
        ], operation: 'PATCH /api/v1/announcements/{announcement}'));
        $this->ensure(($draft['version'] ?? null) === 3 && count($draft['files'] ?? []) === 1, 'Announcement file was not linked atomically to the draft.');

        $publishKey = $this->key();
        $publishBody = ['expected_version' => 3];
        $publishedResult = $this->request($owner, 'POST', "/api/v1/announcements/{$announcementId}/publish", 'announcement-publish', 200, $publishBody, ['Idempotency-Key' => $publishKey], operation: 'POST /api/v1/announcements/{announcement}/publish');
        $published = $this->data($publishedResult);
        $replayedPublishResult = $this->request($owner, 'POST', "/api/v1/announcements/{$announcementId}/publish", 'announcement-publish-replay', 200, $publishBody, ['Idempotency-Key' => $publishKey], operation: 'POST /api/v1/announcements/{announcement}/publish');
        $this->ensure($this->canonical($publishedResult['body']) === $this->canonical($replayedPublishResult['body']), 'Announcement publish replay response differs.');
        $this->ensure(($published['state'] ?? null) === 'published' && ($published['version'] ?? null) === 4, 'Announcement publish state/version mismatch.');
        $this->request($owner, 'PATCH', "/api/v1/announcements/{$announcementId}", 'announcement-published-immutable', 409, [
            'expected_version' => 4, 'title' => 'Must not overwrite publication.',
        ], operation: 'PATCH /api/v1/announcements/{announcement}');
        $this->request($member, 'GET', $announcementList, 'announcement-member-published-list', 200, operation: 'GET /api/v1/programs/{program}/announcements');
        $this->request($member, 'GET', "/api/v1/announcements/{$announcementId}", 'announcement-member-published-detail', 200, operation: 'GET /api/v1/announcements/{announcement}');
        $this->request($member, 'GET', "/api/v1/files/{$fileId}", 'announcement-file-member-published-metadata', 200);
        $memberDownload = $this->request($member, 'GET', "/api/v1/files/{$fileId}/download", 'announcement-file-member-published-download', 200, download: true);
        $this->ensure(($memberDownload['entry']['response_download']['sha256'] ?? null) === hash('sha256', $pdf), 'Published file download checksum mismatch.');

        $feeList = "/api/v1/programs/{$program}/fee-records";
        $this->request($owner, 'GET', $feeList.'?period=2026-11&status=declared&tutor_payment_mark=unmarked', 'fee-owner-list', 200, operation: 'GET /api/v1/programs/{program}/fee-records');
        $feeBody = ['period' => '2026-11', 'amount_minor' => 500000, 'currency' => 'VND'];
        $feeCreateKey = $this->key();
        $feeResult = $this->request($owner, 'POST', $feeList, 'fee-create', 201, $feeBody, ['Idempotency-Key' => $feeCreateKey], operation: 'POST /api/v1/programs/{program}/fee-records');
        $fee = $this->data($feeResult);
        $feeId = (int) $fee['id'];
        $replayFeeResult = $this->request($owner, 'POST', $feeList, 'fee-create-replay', 201, $feeBody, ['Idempotency-Key' => $feeCreateKey], operation: 'POST /api/v1/programs/{program}/fee-records');
        $this->ensure($this->canonical($feeResult['body']) === $this->canonical($replayFeeResult['body']), 'Fee create replay response differs.');
        $this->request($owner, 'POST', $feeList, 'fee-duplicate-month-conflict', 409, $feeBody, ['Idempotency-Key' => $this->key()], operation: 'POST /api/v1/programs/{program}/fee-records');
        $this->request($owner, 'GET', "/api/v1/fee-records/{$feeId}", 'fee-owner-detail', 200, operation: 'GET /api/v1/fee-records/{feeRecord}');
        $this->request($member, 'GET', $feeList.'?period=2026-11', 'fee-member-list', 200, operation: 'GET /api/v1/programs/{program}/fee-records');
        $this->request($member, 'GET', "/api/v1/fee-records/{$feeId}", 'fee-member-detail', 200, operation: 'GET /api/v1/fee-records/{feeRecord}');

        $feeNoop = $this->data($this->request($owner, 'PATCH', "/api/v1/fee-records/{$feeId}", 'fee-same-value-noop', 200, [
            'expected_version' => 1, 'amount_minor' => 500000, 'reason' => 'D04-23 same-value no-op.',
        ], ['Idempotency-Key' => $this->key()], operation: 'PATCH /api/v1/fee-records/{feeRecord}'));
        $this->ensure(($feeNoop['version'] ?? null) === 1, 'Fee same-value PATCH changed version.');
        $fee = $this->data($this->request($owner, 'PATCH', "/api/v1/fee-records/{$feeId}", 'fee-update', 200, [
            'expected_version' => 1, 'amount_minor' => 600000, 'reason' => 'D04-23 synthetic acceptance adjustment.',
        ], ['Idempotency-Key' => $this->key()], operation: 'PATCH /api/v1/fee-records/{feeRecord}'));
        $this->ensure(($fee['version'] ?? null) === 2 && ($fee['amount_minor'] ?? null) === 600000, 'Fee update response mismatch.');
        $this->request($owner, 'PATCH', "/api/v1/fee-records/{$feeId}", 'fee-stale-409', 409, [
            'expected_version' => 1, 'amount_minor' => 610000, 'reason' => 'Stale synthetic update.',
        ], ['Idempotency-Key' => $this->key()], operation: 'PATCH /api/v1/fee-records/{feeRecord}');

        $paidKey = $this->key();
        $paidBody = ['expected_version' => 2];
        $paidResult = $this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/mark-paid", 'fee-mark-paid', 200, $paidBody, ['Idempotency-Key' => $paidKey], operation: 'POST /api/v1/fee-records/{feeRecord}/mark-paid');
        $paid = $this->data($paidResult);
        $paidReplay = $this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/mark-paid", 'fee-mark-paid-replay', 200, $paidBody, ['Idempotency-Key' => $paidKey], operation: 'POST /api/v1/fee-records/{feeRecord}/mark-paid');
        $this->ensure($this->canonical($paidResult['body']) === $this->canonical($paidReplay['body']), 'Fee mark-paid replay response differs.');
        $this->ensure(($paid['version'] ?? null) === 3 && ($paid['tutor_payment_mark'] ?? null) === 'marked_paid', 'Fee paid state/version mismatch.');
        $paidNoop = $this->data($this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/mark-paid", 'fee-mark-paid-noop', 200, [
            'expected_version' => 3,
        ], ['Idempotency-Key' => $this->key()], operation: 'POST /api/v1/fee-records/{feeRecord}/mark-paid'));
        $this->ensure(($paidNoop['version'] ?? null) === 3, 'Fee mark-paid no-op changed version.');
        $unpaid = $this->data($this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/mark-unpaid", 'fee-mark-unpaid', 200, [
            'expected_version' => 3, 'reason' => 'D04-23 synthetic correction.',
        ], ['Idempotency-Key' => $this->key()], operation: 'POST /api/v1/fee-records/{feeRecord}/mark-unpaid'));
        $this->ensure(($unpaid['version'] ?? null) === 4 && ($unpaid['tutor_payment_mark'] ?? null) === 'marked_unpaid', 'Fee unpaid state/version mismatch.');
        $voided = $this->data($this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/void", 'fee-void', 200, [
            'expected_version' => 4, 'reason' => 'D04-23 synthetic acceptance completed.',
        ], ['Idempotency-Key' => $this->key()], operation: 'POST /api/v1/fee-records/{feeRecord}/void'));
        $this->ensure(($voided['status'] ?? null) === 'voided' && ($voided['version'] ?? null) === 5 && ($voided['tutor_payment_mark'] ?? null) === 'marked_unpaid', 'Fee void fields/version mismatch.');
        $this->request($owner, 'POST', "/api/v1/fee-records/{$feeId}/mark-paid", 'fee-voided-mark-conflict', 409, [
            'expected_version' => 5,
        ], ['Idempotency-Key' => $this->key()], operation: 'POST /api/v1/fee-records/{feeRecord}/mark-paid');
        $this->request($owner, 'GET', "/api/v1/fee-records/{$feeId}", 'fee-owner-detail-voided', 200, operation: 'GET /api/v1/fee-records/{feeRecord}');
        $this->request($member, 'GET', "/api/v1/fee-records/{$feeId}", 'fee-member-detail-voided', 200, operation: 'GET /api/v1/fee-records/{feeRecord}');

        $this->request($owner, 'GET', "/api/v1/programs/{$program}/overview", 'overview-owner-after-mutations', 200, operation: 'GET /api/v1/programs/{program}/overview');
        $this->request($member, 'GET', "/api/v1/programs/{$program}/overview", 'overview-member-after-mutations', 200, operation: 'GET /api/v1/programs/{program}/overview');

        $cancel = $this->data($this->request($owner, 'POST', "/api/v1/programs/{$terminalProgram}/cancel", 'terminal-acceptance-program-cancel', 200, []));
        $this->ensure(($cancel['status'] ?? null) === 'cancelled', 'Synthetic terminal Program did not reach cancelled state.');
        $this->request($owner, 'POST', "/api/v1/programs/{$terminalProgram}/progress-records", 'terminal-program-rejects-progress', 409, [
            'metric_name' => 'progress_percent', 'value' => 1,
        ]);

        $missing = array_values(array_diff(self::REQUIRED_OPERATIONS, array_keys($this->covered)));
        $this->ensure($missing === [], 'D04 operations not exercised: '.implode(', ', $missing));

        $summary = [
            'result' => 'PASS',
            'environment' => 'local Docker Compose actual database tutorlink',
            'target_url' => 'http://localhost:8000',
            'database' => 'tutorlink',
            'actor_ids' => ['owner' => (int) $this->fixtures['owner_id'], 'member' => (int) $this->fixtures['member_id'], 'outsider' => (int) $this->fixtures['outsider_id']],
            'program_ids' => ['workspace' => $program, 'terminal_cancelled' => $terminalProgram],
            'progress_id' => $progressId,
            'announcement_id' => $announcementId,
            'file_id' => $fileId,
            'fee_id' => $feeId,
            'd04_operations_covered' => count($this->covered),
            'd04_operations' => array_values(array_keys($this->covered)),
            'api_requests' => count($this->records),
            'expected_statuses_met' => true,
            'publish_replay_equal' => true,
            'fee_create_replay_equal' => true,
            'fee_mark_paid_replay_equal' => true,
            'fee_final' => ['status' => $voided['status'], 'version' => $voided['version'], 'tutor_payment_mark' => $voided['tutor_payment_mark']],
            'download_sha256' => hash('sha256', $pdf),
            'synthetic_records_retained' => true,
            'cookies_and_csrf_tokens_written_to_evidence' => false,
        ];
        file_put_contents($this->directory.'/http-summary.json', json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
        file_put_contents($this->directory.'/run-status.json', json_encode(['result' => 'PASS', 'finished_at_utc' => gmdate(DATE_ATOM), 'request_count' => count($this->records)], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
        echo json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)."\n";
    }
}

try {
    (new D04ActualSmoke())->run();
} catch (Throwable $error) {
    file_put_contents('/tmp/d04-23/run-status.json', json_encode([
        'result' => 'FAIL',
        'error_class' => get_class($error),
        'error_message' => $error->getMessage(),
        'request_count' => is_file('/tmp/d04-23/http-transcript.jsonl') ? count(file('/tmp/d04-23/http-transcript.jsonl')) : 0,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
    fwrite(STDERR, $error->getMessage()."\n");
    exit(1);
}
