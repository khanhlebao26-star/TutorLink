# Pending migration classification — local target

Target status captured in D04-21: 25 Ran, 9 Pending. This classification documents the list; it does not authorize applying any migration in D04-21.

| Pending migration | Classification for BE-D04 | D04-22 handling |
| --- | --- | --- |
| `2026_10_27_074546_add_h02_approval_support` | H02 profile approval support; outside D04. Contains a status backfill for suspended tutor profiles and creates revision support. | Keep outside the D04 change set unless a separate release scope requires it and its data effects are rehearsed. |
| `2026_10_28_034616_align_messaging_contract` | Messaging contract migration; outside D04. It aborts for non-direct/invalid conversations or any existing messages. The current inventory has 0 conversations and 0 messages. | Do not run as an incidental D04 migration. If needed by the selected application release, rehearse this migration and its preconditions separately. |
| `2026_10_28_140000_prepare_message_sending` | Messaging timestamp/index preparation; outside D04. | Keep out of the D04 set unless separately approved and rehearsed. |
| `2026_10_28_200000_add_file_scan_evidence` | File scan metadata migration; it is an additional pending migration relative to the D04-20 test checkpoint. Existing 24 files have clean status; the migration adds nullable evidence fields without fabricating scan results. File upload/complete integration must be tested with this target schema state. | Rehearse and classify as a prerequisite before using the Announcement file flow. Do not fold it into D04-22 without that rehearsal. |
| `2026_10_30_180000_create_realtime_sessions_table` | Realtime session support; outside D04's 16 APIs. | Keep out of the D04 set unless separately needed and rehearsed. |
| `2026_11_01_014629_add_version_and_terminal_replay_to_program_sessions` | Program Session version/replay migration; additional pending relative to the D04-20 test checkpoint. D04 Overview returns the next session version, while the test baseline had this migration recorded as Ran. | Rehearse on the exact target schema before deploying D04 Overview; include only after that compatibility check. |
| `2026_11_01_023131_preserve_program_session_timestamp_precision` | Program Session timestamp precision migration; also pending on the D04-20 test checkpoint and applied for its HTTP runtime. | Include only in the rehearsed migration sequence; verify precision preservation. |
| `2026_11_01_233000_add_be_d04_workspace_schema` | D04 schema and legacy validation. Expected Pending on the actual target. | Apply only after validating the exact legacy checks and upstream prerequisite sequence in D04-22. |
| `2026_11_02_000000_enforce_d04_fee_currency` | D04 Fee currency constraint. Expected Pending on the actual target. | Apply after the D04 workspace schema migration in repository order. |

The five support migrations also Pending on the D04-20 test checkpoint are H02 approval, messaging contract alignment, message sending preparation, realtime sessions, and Program Session timestamp precision. The local target has two extra Pending migrations: file scan evidence and Program Session version/terminal replay. The two extra migrations must be covered by a test rehearsal before D04-22; the current D04-20 result is not evidence that this exact nine-migration target sequence was run.
