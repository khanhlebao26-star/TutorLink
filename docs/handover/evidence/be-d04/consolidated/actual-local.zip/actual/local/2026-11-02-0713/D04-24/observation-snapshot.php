<?php

declare(strict_types=1);

use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

require '/var/www/html/vendor/autoload.php';
$app = require '/var/www/html/bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();

function demand(bool $condition, string $message): void
{
    if (! $condition) {
        throw new RuntimeException($message);
    }
}

function canonical(mixed $value): mixed
{
    if (! is_array($value)) {
        return $value;
    }
    if (! array_is_list($value)) {
        ksort($value);
    }
    foreach ($value as $key => $child) {
        $value[$key] = canonical($child);
    }
    return $value;
}

function evidenceEntries(string $path): array
{
    $entries = [];
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $entry = json_decode($line, true, flags: JSON_THROW_ON_ERROR);
        $entries[$entry['case']] = $entry;
    }
    return $entries;
}

function authenticatedSession(Client $client, array $actor, string $label): array
{
    $cookies = new CookieJar();
    $headers = [
        'Accept' => 'application/json',
        'Origin' => 'http://localhost:3000',
        'Referer' => 'http://localhost:3000/',
        'X-Requested-With' => 'XMLHttpRequest',
    ];
    $csrf = $client->get('/sanctum/csrf-cookie', ['cookies' => $cookies, 'headers' => $headers, 'http_errors' => false]);
    demand($csrf->getStatusCode() === 204, "{$label}: CSRF bootstrap did not return 204.");
    $xsrf = null;
    foreach ($cookies->toArray() as $cookie) {
        if ($cookie['Name'] === 'XSRF-TOKEN') {
            $xsrf = rawurldecode($cookie['Value']);
        }
    }
    demand($xsrf !== null, "{$label}: XSRF cookie missing.");
    $login = $client->post('/api/v1/auth/login', [
        'cookies' => $cookies,
        'headers' => $headers + ['X-XSRF-TOKEN' => $xsrf],
        'http_errors' => false,
        'json' => ['email' => $actor['email'], 'password' => $actor['password']],
    ]);
    demand($login->getStatusCode() === 200, "{$label}: login did not return 200.");

    // Login rotates the XSRF cookie; apiRequest reads the current value from the jar.
    return [$cookies, $headers];
}

function apiRequest(Client $client, array $session, string $method, string $path, ?array $json = null, array $extraHeaders = []): array
{
    [$cookies, $headers] = $session;
    $headers = $headers + $extraHeaders;
    if (! in_array(strtoupper($method), ['GET', 'HEAD', 'OPTIONS'], true)) {
        $xsrf = null;
        foreach ($cookies->toArray() as $cookie) {
            if ($cookie['Name'] === 'XSRF-TOKEN') {
                $xsrf = rawurldecode($cookie['Value']);
            }
        }
        demand($xsrf !== null, 'XSRF cookie missing before mutating request.');
        $headers['X-XSRF-TOKEN'] = $xsrf;
    }
    $options = ['cookies' => $cookies, 'headers' => $headers, 'http_errors' => false];
    if ($json !== null) {
        $options['json'] = $json;
    }
    $response = $client->request($method, $path, $options);
    $raw = (string) $response->getBody();
    $contentType = $response->getHeaderLine('Content-Type');

    return [
        'status' => $response->getStatusCode(),
        'json' => str_contains($contentType, 'json') && $raw !== '' ? json_decode($raw, true) : null,
        'raw' => $raw,
    ];
}

$phase = $argv[1] ?? 'start';
demand(in_array($phase, ['start', 'end'], true), 'phase must be start or end.');
demand(config('app.env') === 'local' && DB::connection()->getDatabaseName() === 'tutorlink', 'Refusing D04-24 snapshot outside local/tutorlink.');

$fixture = json_decode(file_get_contents('/tmp/d04-23/fixture-ids.json'), true, flags: JSON_THROW_ON_ERROR);
$auth = json_decode(file_get_contents('/tmp/d04-23-auth.json'), true, flags: JSON_THROW_ON_ERROR);
$prior = evidenceEntries('/tmp/d04-23/http-transcript-continuation.jsonl');
$client = new Client(['base_uri' => 'http://localhost:8000', 'timeout' => 40]);
$ownerSession = authenticatedSession($client, $auth['actors']['owner'], 'owner');
$memberSession = authenticatedSession($client, $auth['actors']['member'], 'member');
$outsiderSession = authenticatedSession($client, $auth['actors']['outsider'], 'outsider');

$program = DB::table('programs')->whereIn('id', [$fixture['active_program_id'], $fixture['terminal_program_id']])->orderBy('id')->get(['id', 'title', 'status', 'version'])->map(fn ($row) => (array) $row)->all();
$progress = DB::table('progress_records')->where('id', $fixture['active_program_id'])->first(['id', 'program_id', 'metric_name', 'value', 'version', 'recorded_by']);
$announcement = DB::table('announcements')->where('id', 1)->first(['id', 'program_id', 'published_at', 'version']);
$fee = DB::table('fee_records')->where('id', 1)->first(['id', 'program_id', 'period_start', 'amount_minor', 'status', 'tutor_payment_mark', 'version']);
$file = DB::table('files')->where('id', 25)->first(['id', 'owner_id', 'disk', 'object_key', 'purpose', 'visibility', 'scan_status', 'size_bytes', 'checksum_sha256']);
demand(count($program) === 2 && (int) $program[0]['id'] === (int) $fixture['active_program_id'], 'Acceptance Programs missing.');
demand($progress !== null && (int) $progress->version === 2 && (float) $progress->value === 55.0, 'Acceptance Progress changed.');
demand($announcement !== null && $announcement->published_at !== null && (int) $announcement->version === 4, 'Published synthetic Announcement changed.');
demand($fee !== null && $fee->status === 'voided' && $fee->tutor_payment_mark === 'marked_unpaid' && (int) $fee->version === 5, 'Synthetic Fee state changed.');
demand($file !== null && $file->purpose === 'announcement_attachment' && $file->visibility === 'private' && $file->scan_status === 'clean', 'Synthetic file metadata changed.');

$storedBytes = Storage::disk($file->disk)->get($file->object_key);
$storedHash = hash('sha256', $storedBytes);
demand(hash_equals((string) $file->checksum_sha256, $storedHash), 'Stored object checksum differs from the Files row.');
$fileLink = DB::table('file_links')->where('resource_type', 'announcement')->where('resource_id', $announcement->id)->where('file_id', $file->id)->first();
$orphanLinks = DB::table('file_links as l')->leftJoin('files as f', 'f.id', '=', 'l.file_id')->leftJoin('announcements as a', function ($join): void {
    $join->on('a.id', '=', 'l.resource_id')->where('l.resource_type', '=', 'announcement');
})->where('l.resource_type', 'announcement')->where(function ($query): void {
    $query->whereNull('f.id')->orWhereNull('a.id');
})->count();
demand($fileLink !== null && (int) $fileLink->file_id === (int) $file->id && $orphanLinks === 0, 'Announcement File link missing or orphaned.');

$receipts = DB::table('idempotency_receipts')->where('actor_id', $fixture['owner_id'])->where(function ($query): void {
    $query->where('canonical_path', '/api/v1/announcements/1/publish')
        ->orWhere('canonical_path', '/api/v1/programs/1/fee-records')
        ->orWhere('canonical_path', 'like', '/api/v1/fee-records/1%');
})->count();
demand($receipts === 8, "Expected 8 retained Fee/Announcement receipts, found {$receipts}.");

$scopeEvents = DB::table('notification_outbox')->where(function ($query): void {
    $query->where(function ($q): void { $q->where('resource_type', 'announcement')->where('resource_id', 1); })
        ->orWhere(function ($q): void { $q->where('resource_type', 'fee_record')->where('resource_id', 1); })
        ->orWhere(function ($q): void { $q->where('resource_type', 'program')->where('resource_id', 2); });
})->get(['event_key', 'attempt_count', 'processed_at', 'failed_at']);
$duplicateEventKeys = $scopeEvents->count() - $scopeEvents->pluck('event_key')->unique()->count();
$pending = $scopeEvents->whereNull('processed_at')->whereNull('failed_at')->count();
$failed = $scopeEvents->whereNotNull('failed_at')->count();
$wrongAttempts = $scopeEvents->where('attempt_count', '!=', 1)->count();
$notifications = DB::table('notifications')->where('user_id', $fixture['member_id'])->where(function ($query): void {
    $query->where('event_key', 'like', 'announcement:1:%')->orWhere('event_key', 'like', 'fee_record:1:%')->orWhere('event_key', 'like', 'program:2:%');
})->get(['event_key']);
$duplicateNotifications = $notifications->count() - $notifications->pluck('event_key')->unique()->count();
$jobs = DB::table('jobs')->count();
demand($scopeEvents->count() === 7 && $pending === 0 && $failed === 0 && $duplicateEventKeys === 0 && $wrongAttempts === 0, 'Outbox processing state is incorrect.');
demand($notifications->count() === 7 && $duplicateNotifications === 0 && $jobs === 0, 'Notification or queue state is incorrect.');

$health = $client->get('/up', ['http_errors' => false]);
$memberAnnouncement = apiRequest($client, $memberSession, 'GET', '/api/v1/announcements/1');
$memberFee = apiRequest($client, $memberSession, 'GET', '/api/v1/fee-records/1');
$memberDownload = apiRequest($client, $memberSession, 'GET', '/api/v1/files/25/download');
$outsiderDownload = apiRequest($client, $outsiderSession, 'GET', '/api/v1/files/25/download');
demand($health->getStatusCode() === 200, 'Health endpoint is not 200.');
demand($memberAnnouncement['status'] === 200 && ($memberAnnouncement['json']['data']['state'] ?? null) === 'published', 'Current member cannot read the published Announcement.');
demand($memberFee['status'] === 200 && ($memberFee['json']['data']['status'] ?? null) === 'voided', 'Current member cannot read the retained Fee.');
demand($memberDownload['status'] === 200 && hash_equals($storedHash, hash('sha256', $memberDownload['raw'])), 'Current member file download failed or changed bytes.');
demand($outsiderDownload['status'] === 404, 'Out-of-scope actor can access the private file.');

$replaySpecs = [
    ['announcement-publish', 'POST', '/api/v1/announcements/1/publish'],
    ['fee-create', 'POST', '/api/v1/programs/1/fee-records'],
    ['fee-mark-paid', 'POST', '/api/v1/fee-records/1/mark-paid'],
];
$replays = [];
foreach ($replaySpecs as [$case, $method, $path]) {
    $original = $prior[$case] ?? null;
    demand($original !== null && isset($original['idempotency_key'], $original['request_json'], $original['response_json']), "Original {$case} evidence missing.");
    $actual = apiRequest($client, $ownerSession, $method, $path, $original['request_json'], ['Idempotency-Key' => $original['idempotency_key']]);
    $equal = canonical($actual['json']) === canonical($original['response_json']);
    $replays[$case] = ['status' => $actual['status'], 'matches_original_snapshot' => $equal];
    demand($actual['status'] === $original['status'] && $equal, "{$case} receipt replay differs from original snapshot.");
}

$snapshot = [
    'database' => DB::connection()->getDatabaseName(),
    'programs' => $program,
    'progress' => ['id' => (int) $progress->id, 'program_id' => (int) $progress->program_id, 'value' => (float) $progress->value, 'version' => (int) $progress->version],
    'announcement' => ['id' => (int) $announcement->id, 'program_id' => (int) $announcement->program_id, 'published' => $announcement->published_at !== null, 'version' => (int) $announcement->version, 'file_id' => (int) $fileLink->file_id],
    'fee' => ['id' => (int) $fee->id, 'program_id' => (int) $fee->program_id, 'period_start' => (string) $fee->period_start, 'amount_minor' => (int) $fee->amount_minor, 'status' => $fee->status, 'payment_mark' => $fee->tutor_payment_mark, 'version' => (int) $fee->version],
    'file' => ['id' => (int) $file->id, 'owner_id' => (int) $file->owner_id, 'private' => $file->visibility === 'private', 'purpose' => $file->purpose, 'scan_status' => $file->scan_status, 'stored_object_exists' => true, 'sha256' => $storedHash],
    'announcement_file_orphans' => $orphanLinks,
    'retained_receipts' => $receipts,
    'outbox' => ['count' => $scopeEvents->count(), 'pending' => $pending, 'failed' => $failed, 'duplicates' => $duplicateEventKeys, 'attempt_count_each' => 1],
    'notifications' => ['count' => $notifications->count(), 'duplicates' => $duplicateNotifications],
    'jobs' => $jobs,
];

$result = [
    'phase' => $phase,
    'observed_at_utc' => now('UTC')->toIso8601String(),
    'environment' => config('app.env'),
    'database' => DB::connection()->getDatabaseName(),
    'api_checks' => [
        'health_http' => $health->getStatusCode(),
        'member_announcement_http' => $memberAnnouncement['status'],
        'member_fee_http' => $memberFee['status'],
        'member_published_file_download_http' => $memberDownload['status'],
        'member_download_sha256' => hash('sha256', $memberDownload['raw']),
        'outsider_file_download_http' => $outsiderDownload['status'],
        'receipt_replays' => $replays,
    ],
    'snapshot' => $snapshot,
    'snapshot_sha256' => hash('sha256', json_encode(canonical($snapshot), JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)),
    'session_cookies_or_csrf_tokens_recorded' => false,
    'replay_mutations' => false,
];

echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)."\n";
