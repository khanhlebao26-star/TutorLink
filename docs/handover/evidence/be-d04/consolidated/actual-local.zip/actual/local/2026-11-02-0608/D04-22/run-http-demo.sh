#!/bin/sh
set -eu

cd /var/www/html
php artisan db:seed --class='Database\Seeders\BeD04FixtureSeeder' --force
php /d04-evidence/prepare-http-fee-fixture.php

php artisan serve --host=127.0.0.1 --port=8084 --no-reload > /d04-evidence/http-server.log 2>&1 &
server_pid=$!
cleanup() {
    kill "$server_pid" 2>/dev/null || true
    wait "$server_pid" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

attempt=0
until php -r '$s = @fsockopen("127.0.0.1", 8084, $errno, $errstr, 0.2); if ($s) { fclose($s); exit(0); } exit(1);'; do
    attempt=$((attempt + 1))
    if [ "$attempt" -ge 40 ]; then
        cat /d04-evidence/http-server.log
        exit 1
    fi
    sleep 0.25
done

php /d04-evidence/http-demo.php
