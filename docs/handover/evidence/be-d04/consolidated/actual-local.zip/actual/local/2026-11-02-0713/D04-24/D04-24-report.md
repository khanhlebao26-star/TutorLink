# D04-24 — Kiểm trạng thái sau áp dụng và khả năng phục hồi

**Kết quả: PASS** · Local Docker Compose · `tutorlink` · 02/11/2026 07:18:50–07:29:12 ICT (622 giây). Backend, workers và scheduler giữ candidate image `sha256:8f1589bfc233765bedce705b2c802fb319f9d10a821ed1a46b57577c2e605411`; migration status cuối khớp 34 Ran, 0 Pending.

Trong toàn cửa sổ, health và member API trả 200; member tải file private được 200 với checksum khớp, outsider bị chặn 404. Announcement publish, Fee create và Fee mark-paid replay lần lượt trả 200/201/200 với JSON khớp response gốc. DB snapshot đầu/cuối và ba checkpoint có cùng SHA-256. Tám receipt vẫn còn; 7/7 outbox đã xử lý, không pending/failed/trùng, mỗi event một attempt; 7 notification không trùng; không orphan file link, queue job hoặc thay đổi dữ liệu nghiệm thu. Bộ lọc log backend/DB/worker/scheduler ghi nhận 0 dòng lỗi trong cửa sổ.

Runtime từng dừng trước cửa sổ này; đã khởi động lại bằng image/volume hiện có mà không migrate/reset DB. Lần observer đầu trả 419 do helper giữ CSRF token cũ sau login; helper đã đọc token hiện hành và retest replay đạt. Chi tiết ở [recovery-and-retest](recovery-and-retest.md).

**Evidence:** [evidence index](evidence-index.md), [window comparison](window-comparison.json), [start snapshot](start-snapshot.json), [end snapshot](end-snapshot.json), [log summary end](log-summary-end.json), [runtime start/end](runtime-start.txt) · [runtime end](runtime-end.txt), [migration status end](migration-status-end.txt).
