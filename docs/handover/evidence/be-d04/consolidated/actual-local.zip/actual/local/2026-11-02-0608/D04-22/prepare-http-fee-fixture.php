<?php

declare(strict_types=1);

require '/var/www/html/vendor/autoload.php';

$app = require '/var/www/html/bootstrap/app.php';
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();

if (config('database.connections.pgsql.database') !== 'tutorlink_test') {
    throw new RuntimeException('Refusing fixture adjustment outside tutorlink_test.');
}

$fee = Illuminate\Support\Facades\DB::table('fee_records')
    ->where('program_id', 5)
    ->whereDate('period_start', '2026-11-01')
    ->first();

if ($fee === null
    || (int) $fee->amount_minor !== 275000
    || $fee->status !== 'declared'
    || $fee->tutor_payment_mark !== 'unmarked'
    || (int) $fee->version !== 1
    || $fee->voided_at !== null
    || $fee->payment_marked_at !== null) {
    throw new RuntimeException('Expected exactly the untouched synthetic November fee fixture.');
}

$removed = Illuminate\Support\Facades\DB::table('fee_records')
    ->where('id', $fee->id)
    ->delete();

if ($removed !== 1) {
    throw new RuntimeException('Expected exactly one synthetic November fixture to be removed.');
}

$evidence = [
    'database' => 'tutorlink_test',
    'reason' => 'The current synthetic fixture already occupies November 2026; remove only that untouched fixture row so the HTTP demo can test create/replay on the accepted period.',
    'removed_fixture' => [
        'id' => (int) $fee->id,
        'program_id' => (int) $fee->program_id,
        'period_start' => $fee->period_start,
        'amount_minor' => (int) $fee->amount_minor,
        'status' => $fee->status,
        'tutor_payment_mark' => $fee->tutor_payment_mark,
        'version' => (int) $fee->version,
    ],
];

file_put_contents(
    '/d04-evidence/http-fixture-adjustment.json',
    json_encode($evidence, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR),
);
echo json_encode($evidence, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)."\n";
