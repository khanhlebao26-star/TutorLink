# D04-24 Evidence Index

Environment: local Docker Compose · database `tutorlink` · run `2026-11-02-0713` · observation window 2026-11-02 00:18:50–00:29:12 UTC.

| Evidence | Contents |
|---|---|
| [D04-24 report](D04-24-report.md) | Concise actual-runtime result and acceptance summary |
| [Window comparison](window-comparison.json) | 622-second duration, same snapshot hash, final gate results |
| [Start snapshot](start-snapshot.json) · [3m](checkpoint-3m-snapshot.json) · [5m](checkpoint-5m-snapshot.json) · [8m](checkpoint-8m-snapshot.json) · [end](end-snapshot.json) | Scoped DB state, API health/access, replay, file checksum, receipts, outbox and notifications |
| [Start log summary](log-summary-start.json) · [3m](log-summary-3m.json) · [5m](log-summary-5m.json) · [8m](log-summary-8m.json) · [end](log-summary-end.json) | Filtered counts and per-container log hashes; raw log text is not stored |
| [Runtime start](runtime-start.txt) · [3m](runtime-3m.txt) · [5m](runtime-5m.txt) · [8m](runtime-8m.txt) · [end](runtime-end.txt) | Image ID, start time and runtime state for backend, DB, workers and scheduler |
| [Migration status start](migration-status-start.txt) · [end](migration-status-end.txt) | Read-only migration status |
| [Recovery/retest note](recovery-and-retest.md) | Runtime interruption, restart steps and CSRF-helper correction |
| [Snapshot helper](observation-snapshot.php) · [Replay diagnostic helper](replay-diagnostic.php) | Redacted read-only observer and replay comparison logic |

No credentials, cookies, CSRF values or raw application logs are stored in this evidence folder.
