# D04-22 — Actual environment report

**Result: PASS for the local TutorLink Docker Compose environment.** The target was database `tutorlink` on PostgreSQL 16.15, served locally at `http://localhost:8000`; this run did not target remote staging or production.

## Migration and data

- Preflight found **9 Pending migrations**; the exact candidate applied all 9 successfully. Final status: **34 Ran, 0 Pending**.
- The post-migration inventory shows the expected D04 version/payment/void metadata and **13 D04 constraints**.
- Existing aggregates remain unchanged: 51 users, 24 clean files, and 3 audit rows. D04 Programs, Progress records, Announcements, Fees, file links, idempotency receipts, notifications, and outbox rows remain at 0. D04-22 made no business API mutations.
- The D04-21 backup remains available outside the repository; its SHA-256 is `d6e438dc07b7af935cf8f7ad212fa8b1168a3626cafd3d63f8a598458c70148b`.

## Runtime

- Backend, broadcast worker, outbox worker, Slack worker, and scheduler all run image `sha256:8f1589bfc233765bedce705b2c802fb319f9d10a821ed1a46b57577c2e605411`.
- Backend is healthy; worker and scheduler containers are running. Each reports `APP_ENV=local`, `DB_HOST=db`, `DB_DATABASE=tutorlink`.
- `GET /sanctum/csrf-cookie` returned **HTTP 204**.
- Route verification matched **105/105 OpenAPI operations**, including **16/16 D04 operations**; no documented baseline operation was missing.
- The immediate post-rollout log scan covered 85 lines and found no ERROR/FATAL/CRITICAL/unhandled-exception entries.

## Reports and evidence

- [Test report](test-report.md)
- [Release manifest](release-manifest.json)
- [Migration output and final status](actual-migration.txt) / [migration status](actual-migration-status-after.txt)
- [Post-migration schema and aggregate inventory](actual-post-migration-inventory.txt)
- [Runtime image identity](runtime-image-identity.txt), [health](runtime-health.txt), [source hash](runtime-source-hash.txt), and [configuration targets](runtime-config-targets.txt)
- [Actual route coverage](route-coverage-actual.txt) and [complete runtime route JSON](route-list-actual.json)
- [HTTP health response](runtime-health-http.txt) and [log scan summary](runtime-log-summary.txt)
- [Test database restore check](test-db-restore-check.txt)

D04-23 remains the actual-environment API smoke and evidence step; this report does not claim that those business flows have been exercised against the actual database.
