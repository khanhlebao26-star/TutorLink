# D04-21 — Local target preflight and backup

**Result: PASS for the local TutorLink environment.** This is the running local Docker Compose stack, not a remote staging or production target. D04-22 was not started; no migration, seed, deploy, API mutation, or service restart was performed.

## Target identity

- Backend: `tutorlink-backend`, healthy, image ID `sha256:cd1bce6ee4f790e1364083f9f97a79f6f50edc128c6ae79966ff2009aa08b86`, started `2026-11-01T07:56:52Z`. It serves `http://localhost:8000`; the Compose port is published on all interfaces. Frontend is `http://localhost:3000`.
- Runtime: PHP 8.3.36, Laravel 13.35.0, Node 22.23.3. Application reports `APP_ENV=local`, `APP_DEBUG=true`, queue `database`, local filesystem disk, and file-based sessions. PostgreSQL and backend health checks are healthy.
- Database: `tutorlink` on `tutorlink-db-1`, role `tutorlink`, PostgreSQL 16.15, size 10,763,287 bytes. The data volume is `tutorlink_postgres_data`; application storage is the `tutorlink_backend_storage` volume.
- The current backend image differs from D04-20's tested image. Its writable backend mount points to this repository, and all 359 paths match the D04-20 build-context checksum manifest. The running image itself is not the tested image. D04-22 must use the recorded tested image identity or produce and re-test a new release artifact.
- `broadcast-worker`, `outbox-worker`, `slack-worker`, `scheduler`, and `reverb` are not running in the current TutorLink stack. This is recorded as current local state, not changed in D04-21.

## Migration and data preflight

Laravel and direct PostgreSQL inspection agree on the target. There are **25 migrations recorded as Ran and 9 Pending**: seven upstream migrations and the two D04 migrations. The D04 migrations are pending as expected. The local database has two more upstream migrations pending than the D04-20 test checkpoint: `2026_10_28_200000_add_file_scan_evidence` and `2026_11_01_014629_add_version_and_terminal_replay_to_program_sessions`. D04-22 must rehearse this exact pending set before applying it.

The read-only inventory found 0 Programs, Program sessions, Progress records, Announcements, Fee records, file links, messages, conversations, outbox rows, notifications, and idempotency receipts; 51 users, 24 Files, and 3 audit rows. All 24 existing Files report `clean` scan status. The current schema has no D04 Fee payment/void metadata or Fee/Progress/Announcement version fields; the D04 migration will add those fields.

Every D04 legacy-data preflight count is zero: ambiguous `confirmed`/`cancelled` Fee statuses, invalid Fee rows, duplicate Fee months, legacy Fee payment audit evidence, invalid Progress scope/metric/value, invalid Announcement content or file links, and Announcements with over five files. The three existing audit rows are for tutor profile changes. No record-level values or personal file metadata were copied into this report.

## Backup and gate

A target-only PostgreSQL custom-format database dump was created outside the repository at `/tmp/tutorlink-be-d04-local-2026-11-02-0552/tutorlink-2026-11-02-0552.dump`. It is 163,947 bytes, mode `0600`, in a mode `0700` directory. SHA-256: `d6e438dc07b7af935cf8f7ad212fa8b1168a3626cafd3d63f8a598458c70148b`. `pg_restore --list` read the archive (398 TOC entries), and `pg_restore --file=/dev/null` successfully decoded the full archive without connecting to or changing a database. The file-storage volume was inventoried but not copied; this is a database backup, not a full application-data backup. The backup itself is not in the repository.

The restore rehearsal evidence is [D04-05 on test](../../../../test/2026-11-01-2330/D04-05/D04-05-report.md) and its [backup/restore manifest](../../../../test/2026-11-01-2330/D04-05/backup-restore-manifest.md). That rehearsal restored into a temporary test database and matched the recorded fingerprints; no restore was performed against this local target.

The seven upstream migrations are classified in [pending-migration-classification.md](pending-migration-classification.md). Five were also pending on the D04-20 test checkpoint; two additional pending migrations mean the target schema does not yet match the tested baseline. D04-22 must honor that difference and use the exact tested application artifact. The current environment is local development with debug enabled, so this result does not identify or approve any remote staging/production host.

## Evidence

- [Deployment manifest](deployment-manifest.json)
- [Backup manifest](backup-manifest.json), [archive listing](backup-archive-list.txt), [filesystem checksum/mode](backup-filesystem-check.txt), and [full archive decode check](backup-decode-check.txt)
- [Migration status](migration-status.txt), [direct migration rows](migration-rows-direct-db.txt), and [confirming status read](migration-status-confirmation.txt)
- [Database identity and table list](database-identity-and-tables.txt), [schema inventory](schema-inventory.txt), [constraint inventory](constraint-inventory.txt), and [read-only inventory SQL](read-only-inventory.sql) / [output](read-only-inventory.txt)
- [Backend runtime](backend-runtime.txt), [database runtime](database-runtime.txt), [runtime config](runtime-config.txt), [Laravel database identity](laravel-database-identity.txt), and [source checksum verification](source-checksum-verification.txt)
- [D04-20 tested release manifest](../../../../test/2026-11-02-0045/D04-20/release-manifest.json)
- [Graphify refresh](graph-update.txt)
