# D04-23 evidence index

| Evidence | Description |
|---|---|
| [D04-23-report.md](D04-23-report.md) | Concise actual smoke result and limits |
| [preflight.json](preflight.json), [preflight-http.json](preflight-http.json) | Target DB baseline, CSRF/login, owner/member/outsider scope |
| [preflight-http-initial-failure.txt](preflight-http-initial-failure.txt) | Read-only session preflight correction history |
| [fixture-ids.json](fixture-ids.json), [setup-acceptance.php](setup-acceptance.php) | Synthetic actor and Program IDs; guarded setup source |
| [http-summary-final.json](http-summary-final.json), [http-case-summary.json](http-case-summary.json) | Final 16-operation coverage, replay/no-op/stale/download outcomes and one preliminary ordering diagnostic |
| [http-preliminary-transcript.jsonl](http-preliminary-transcript.jsonl), [http-transcript-continuation.jsonl](http-transcript-continuation.jsonl) | Actual HTTP requests and responses; no session cookies or CSRF token values |
| [http-smoke.php](http-smoke.php), [http-smoke-continuation.php](http-smoke-continuation.php), [preflight-http.php](preflight-http.php) | Reproducible request harnesses |
| [database-before-after.json](database-before-after.json), [database-scope-final.json](database-scope-final.json), [audit-field-evidence.json](audit-field-evidence.json) | Before/after aggregates, synthetic state, audit snapshots, receipts, and file link |
| [notification-worker-verification.json](notification-worker-verification.json) | Seven scoped outbox events processed once; no duplicates/failures/pending work |
| [download-announcement-file-owner-draft.pdf](download-announcement-file-owner-draft.pdf), [download-announcement-file-member-published.pdf](download-announcement-file-member-published.pdf) | Actual downloaded bytes from owner Draft and member Published paths |
| [runtime-log-summary.txt](runtime-log-summary.txt) | Post-smoke backend/worker/scheduler log scan summary |
| [run-status-preliminary.json](run-status-preliminary.json), [run-status-final.json](run-status-final.json) | Initial ordering stop and completed continuation status |

Candidate image and migration evidence are linked from the [D04-22 release manifest](../../2026-11-02-0608/D04-22/release-manifest.json). No remote environment was exercised.
