BEGIN TRANSACTION READ ONLY;

SELECT table_name, row_count FROM (
    SELECT 'users' AS table_name, count(*)::bigint AS row_count FROM users
    UNION ALL SELECT 'programs', count(*) FROM programs
    UNION ALL SELECT 'program_sessions', count(*) FROM program_sessions
    UNION ALL SELECT 'progress_records', count(*) FROM progress_records
    UNION ALL SELECT 'announcements', count(*) FROM announcements
    UNION ALL SELECT 'fee_records', count(*) FROM fee_records
    UNION ALL SELECT 'files', count(*) FROM files
    UNION ALL SELECT 'file_links', count(*) FROM file_links
    UNION ALL SELECT 'audit_logs', count(*) FROM audit_logs
    UNION ALL SELECT 'notification_outbox', count(*) FROM notification_outbox
    UNION ALL SELECT 'notifications', count(*) FROM notifications
    UNION ALL SELECT 'idempotency_receipts', count(*) FROM idempotency_receipts
    UNION ALL SELECT 'conversations', count(*) FROM conversations
    UNION ALL SELECT 'messages', count(*) FROM messages
    UNION ALL SELECT 'migrations', count(*) FROM migrations
) counts ORDER BY table_name;

SELECT 'program_status' AS group_name, status AS label, count(*)::bigint AS rows
FROM programs GROUP BY status ORDER BY status;

SELECT 'fee_declared_status' AS group_name, declared_status AS label, count(*)::bigint AS rows
FROM fee_records GROUP BY declared_status ORDER BY declared_status;

SELECT 'fee_currency' AS group_name, currency AS label, count(*)::bigint AS rows
FROM fee_records GROUP BY currency ORDER BY currency;

SELECT 'announcement_visibility' AS group_name,
       CASE WHEN published_at IS NULL THEN 'draft' ELSE 'published' END AS label,
       count(*)::bigint AS rows
FROM announcements GROUP BY 2 ORDER BY 2;

SELECT 'file_scan_status' AS group_name, scan_status AS label, count(*)::bigint AS rows
FROM files GROUP BY scan_status ORDER BY scan_status;

SELECT 'file_purpose' AS group_name, coalesce(purpose, '<null>') AS label, count(*)::bigint AS rows
FROM files GROUP BY purpose ORDER BY purpose NULLS FIRST;

SELECT 'file_link_type_purpose' AS group_name,
       resource_type || ':' || coalesce(purpose, '<null>') AS label,
       count(*)::bigint AS rows
FROM file_links GROUP BY resource_type, purpose ORDER BY resource_type, purpose NULLS FIRST;

SELECT 'outbox_state' AS group_name,
       CASE WHEN processed_at IS NOT NULL THEN 'processed'
            WHEN resolved_at IS NOT NULL THEN 'resolved'
            WHEN failed_at IS NOT NULL THEN 'failed'
            ELSE 'pending' END AS label,
       count(*)::bigint AS rows
FROM notification_outbox GROUP BY 2 ORDER BY 2;

SELECT 'outbox_event' AS group_name, event_key AS label, count(*)::bigint AS rows
FROM notification_outbox GROUP BY event_key ORDER BY event_key;

SELECT 'receipt_retention' AS group_name,
       CASE WHEN expires_at IS NULL THEN 'no_expiry'
            WHEN expires_at <= CURRENT_TIMESTAMP THEN 'expired'
            ELSE 'not_expired' END AS label,
       count(*)::bigint AS rows
FROM idempotency_receipts GROUP BY 2 ORDER BY 2;

SELECT 'audit_resource_action' AS group_name,
       resource_type || ':' || action AS label,
       count(*)::bigint AS rows
FROM audit_logs GROUP BY resource_type, action ORDER BY resource_type, action;

SELECT check_name, row_count FROM (
    SELECT 'fee_status_confirmed_ambiguous' AS check_name, count(*)::bigint AS row_count
    FROM fee_records WHERE declared_status = 'confirmed'
    UNION ALL
    SELECT 'fee_status_cancelled_ambiguous', count(*)::bigint
    FROM fee_records WHERE declared_status = 'cancelled'
    UNION ALL
    SELECT 'invalid_progress_scope_metric_or_value', count(*)::bigint
    FROM progress_records AS r
    LEFT JOIN programs AS p ON p.id = r.program_id
    LEFT JOIN tutor_profiles AS tp ON tp.id = p.owner_tutor_profile_id
    WHERE p.id IS NULL OR tp.id IS NULL OR r.metric_name <> 'progress_percent'
       OR r.value <> trunc(r.value) OR r.value < 0 OR r.value > 100
       OR r.customer_id <> p.customer_id OR r.recorded_by <> tp.user_id
    UNION ALL
    SELECT 'invalid_announcement_content', count(*)::bigint
    FROM announcements AS a
    WHERE length(btrim(a.title)) NOT BETWEEN 1 AND 180
       OR length(a.body) NOT BETWEEN 1 AND 10000 OR btrim(a.body) = ''
    UNION ALL
    SELECT 'invalid_announcement_file_links', count(*)::bigint
    FROM file_links AS l
    LEFT JOIN announcements AS a ON a.id = l.resource_id AND l.resource_type = 'announcement'
    LEFT JOIN files AS f ON f.id = l.file_id
    LEFT JOIN programs AS p ON p.id = a.program_id
    LEFT JOIN tutor_profiles AS tp ON tp.id = p.owner_tutor_profile_id
    WHERE l.resource_type = 'announcement'
      AND (a.id IS NULL OR f.id IS NULL OR tp.id IS NULL OR a.author_id <> tp.user_id
       OR f.owner_id <> a.author_id OR l.purpose IS NULL OR l.purpose <> 'announcement_attachment'
       OR f.purpose IS NULL OR f.purpose <> 'announcement_attachment' OR f.scan_status <> 'clean')
    UNION ALL
    SELECT 'announcements_over_five_files', count(*)::bigint FROM (
        SELECT resource_id FROM file_links WHERE resource_type = 'announcement'
        GROUP BY resource_id HAVING count(DISTINCT file_id) > 5
    ) over_limit
    UNION ALL
    SELECT 'invalid_fee_rows', count(*)::bigint
    FROM fee_records AS f
    LEFT JOIN programs AS p ON p.id = f.program_id
    LEFT JOIN pg_timezone_names AS tz ON tz.name = p.timezone
    WHERE p.id IS NULL OR p.activated_at IS NULL OR tz.name IS NULL
       OR f.amount_minor < 0 OR f.amount_minor > 9007199254740991 OR f.currency <> 'VND'
       OR extract(day FROM f.period_start) <> 1
       OR f.period_end <> (f.period_start + interval '1 month - 1 day')::date
       OR f.period_start < date_trunc('month', p.activated_at AT TIME ZONE p.timezone)::date
       OR f.period_start > date_trunc('month', CURRENT_TIMESTAMP AT TIME ZONE p.timezone)::date
    UNION ALL
    SELECT 'duplicate_normalized_fee_months', count(*)::bigint FROM (
        SELECT program_id, date_trunc('month', period_start)::date AS month_start
        FROM fee_records GROUP BY program_id, date_trunc('month', period_start)::date
        HAVING count(*) > 1
    ) duplicate_months
    UNION ALL
    SELECT 'legacy_fee_payment_audit_evidence', count(*)::bigint
    FROM audit_logs
    WHERE resource_type IN ('fee', 'fee_record', 'fee_records')
      AND (action ILIKE '%mark%' OR action ILIKE '%paid%' OR action ILIKE '%confirm%'
       OR coalesce(after::text, '') ~* 'marked_paid|marked_unpaid|payment_marked')
) checks ORDER BY check_name;

COMMIT;
