# D04-24 — Sự cố runtime và retest

## Runtime

Ở lần kiểm tra đầu, stack TutorLink local đã dừng. Backend thoát mã 0 lúc `2026-11-01T23:45:09.745Z`; PostgreSQL ghi nhận fast shutdown và checkpoint hoàn tất; frontend thoát mã 137. Không thấy dấu hiệu OOM. Log hiện có không xác định được tác nhân dừng toàn stack.

Đã khởi động lại DB và Mailpit, sau đó frontend/backend bằng image và volume hiện có; chỉ khởi động worker/scheduler sau khi backend healthy. Không rebuild image, chạy migration, reset DB, thay volume hoặc sửa dữ liệu nghiệp vụ. Backend healthy lại lúc `2026-11-02T00:15:32.969Z` với image `sha256:8f1589bfc233765bedce705b2c802fb319f9d10a821ed1a46b57577c2e605411`.

## Retest replay

Lần chạy observer đầu chưa tạo được snapshot hoàn chỉnh. Chẩn đoán có kiểm soát cho thấy helper giữ XSRF token lấy trước login; login xoay cookie nên request replay bị HTTP 419 tại CSRF middleware trước khi vào xử lý nghiệp vụ. Helper đã được sửa để đọc token hiện tại từ cookie jar cho từng request ghi. Không thay đổi business data trong chẩn đoán.

Retest đầu cửa sổ cho thấy replay Announcement publish `200`, Fee create `201`, Fee mark-paid `200`; JSON sau canonicalization khớp response gốc ở cả ba trường hợp. Helper hiện tại chỉ thực hiện health/read/download, các replay cùng key đã ghi nhận và truy vấn DB.

## Artifact

- `start-snapshot.json`: API, DB, receipt, outbox, notification, private-file và access snapshot đầu cửa sổ.
- `log-summary-start.json`: số dòng log đã lọc từ sau mốc bắt đầu; không lưu raw log.
- `runtime-start.txt`, `runtime-start-captured-at.txt`, `migration-status-start.txt`: runtime/image và migration status.
- `replay-diagnostic.php`, `observation-snapshot.php`: helper không chứa credential/token; credential tổng hợp chỉ được đọc từ file runtime ngoài repo.

