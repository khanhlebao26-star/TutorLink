# BE-D04 Actual Evidence Index

Actual scope is the **local TutorLink Docker Compose environment**, database `tutorlink`. No remote staging or production environment is claimed.

| Step | Actual report/evidence |
|---|---|
| D04-01 baseline | [Actual project baseline report](D04-01-report.md) · [baseline routes](routes-2026-11-01.json) · [migration status](migration-status-2026-11-01.txt) |
| D04-09 supplemental | [Project report](../project/2026-11-02-0033/D04-09-project-report.md) |
| D04-21 preflight | [Report](local/2026-11-02-0552/D04-21/D04-21-report.md) · [deployment manifest](local/2026-11-02-0552/D04-21/deployment-manifest.json) · [backup manifest](local/2026-11-02-0552/D04-21/backup-manifest.json) · [migration classification](local/2026-11-02-0552/D04-21/pending-migration-classification.md) |
| D04-22 apply | [Actual report](local/2026-11-02-0608/D04-22/D04-22-report.md) · [actual release manifest](local/2026-11-02-0608/D04-22/release-manifest.json) · [migration output](local/2026-11-02-0608/D04-22/actual-migration.txt) · [candidate retest report](local/2026-11-02-0608/D04-22/test-report.md) |
| D04-23 actual API smoke | [Report](local/2026-11-02-0632/D04-23/D04-23-report.md) · [evidence index](local/2026-11-02-0632/D04-23/evidence-index.md) · [final HTTP summary](local/2026-11-02-0632/D04-23/http-summary-final.json) · [scoped DB state](local/2026-11-02-0632/D04-23/database-scope-final.json) |
| D04-24 runtime stability | [Report](local/2026-11-02-0713/D04-24/D04-24-report.md) · [evidence index](local/2026-11-02-0713/D04-24/evidence-index.md) · [window comparison](local/2026-11-02-0713/D04-24/window-comparison.json) · [start snapshot](local/2026-11-02-0713/D04-24/start-snapshot.json) · [end snapshot](local/2026-11-02-0713/D04-24/end-snapshot.json) |
| D04-25 current handover snapshot | [Report](local/2026-11-02-0746/D04-25/D04-25-report.md) · [runtime current](local/2026-11-02-0746/D04-25/runtime-current.txt) · [migration status](local/2026-11-02-0746/D04-25/migration-status-current.txt) · [source/build verification](local/2026-11-02-0746/D04-25/build-context-verification.json) · [plan/evidence link validation](local/2026-11-02-0746/D04-25/plan-evidence-link-validation.json) |

Primary summary: [BE-D04-handover.md](../../../BE-D04-handover.md). Detailed per-step links for D04-01..24 are in the [master plan](../../../BE-D04-plan.md).
