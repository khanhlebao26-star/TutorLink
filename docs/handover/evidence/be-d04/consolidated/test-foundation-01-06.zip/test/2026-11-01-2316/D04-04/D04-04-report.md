# D04-04 — Test report

**Kết quả: ĐẠT cho giai đoạn viết/khởi chạy case trước triển khai** · 01/11/2026 · branch `be-d04` · môi trường `tutorlink_test` (PostgreSQL 16.15).

Đã lập case matrix cho đủ 16 endpoint và nhóm case quyền, request/response, omission/null, validation, pagination/tie-break, no-op/replay, File, Fee metadata, PostgreSQL constraint, race và rollback. Thêm hai test source: probe 16 route và kiểm tra schema đích PostgreSQL.

Lượt chạy đầu trên PostgreSQL: **29 tests thất bại có chủ đích (16 route + 13 schema)** vì route BE-D04 chưa đăng ký và schema Progress/Announcement/Fee đích chưa có. Laravel test khởi động và kết nối đúng `tutorlink_test`; không có lỗi cấu hình. Đây là baseline RED trước khi triển khai.

Case race `RC-01..07` và fault/rollback `RB-01..04` đã có request/result/DB oracle trong matrix; process barrier và fault harness sẽ chạy ở D04-15/16 khi writer tương ứng tồn tại. Lượt D04-04 chưa inject lỗi hoặc chạy đồng thời.

Sau lượt chạy, DB vẫn 43 bảng/25 migrations; giữ nguyên 8 actor, 4 Program, 59 Fee, 55 Progress, 4 Announcement, 5 File fixture. Không migration/reset/truncate/seed hoặc ghi dữ liệu.

## Bằng chứng

- [Case matrix](case-matrix.md)
- [Environment manifest](environment.json)
- [PostgreSQL first-run log](postgres-first-run.txt)
- [Post-run database preservation](database-preservation.txt)
- [PostgreSQL schema snapshot before implementation](postgres-schema-before.txt)
- [PostgreSQL counts after probes](postgres-after-check.txt)
- [Route contract test source](../../../../../../../backend/tests/Feature/BeD04RouteContractTest.php)
- [PostgreSQL schema contract test source](../../../../../../../backend/tests/Feature/BeD04PostgresSchemaContractTest.php)
- [Source patch](source.patch)

Race và rollback case đã được xác định, còn bước thực thi harness nằm ở D04-15/16 theo thứ tự phụ thuộc.
