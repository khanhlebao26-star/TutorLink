# D04-04 — Ma trận case contract BE-D04

**Nguồn chuẩn:** `docs/handover/BE-D04-contract.md` §§1–6, 13–17; fixture oracle tại [D04-03](../../2026-11-01-2252/D04-03/fixtures.md). Case này khóa expected behavior trước khi viết writer. ID route khớp test `BeD04RouteContractTest`; ID API trong ma trận dùng lại cho transcript ở D04-19.

## 16 endpoint — success shape và side effect

| Case | Request / actor | Expected HTTP + body | Expected side effect |
|---|---|---|---|
| OV-01 | `GET /programs/{id}/overview`; owner/member hiện hành | 200; `{data:{next_session,task_counts,latest_progress,latest_announcement,capabilities}}`; đủ 5 task status; chỉ latest Published Announcement | Read-only, cùng DB snapshot; không audit/outbox/receipt |
| PR-01 | `GET /programs/{id}/progress-records?page=1&per_page=20`; owner/member | 200; list envelope `data[]`, `meta`; order `(recorded_at DESC,id DESC)` | Read-only; không receipt |
| PR-02 | `POST /programs/{id}/progress-records` `{"metric_name":"progress_percent","value":35,"note":null}`; owner, Program Active/Paused | 201 `{data: ProgressResource}`; version 1, server-set customer/recorder/time | Một Progress row; không idempotency receipt/audit/outbox |
| PR-03 | `PATCH /progress-records/{id}` `{"expected_version":1,"note":"new"}`; owner, Active/Paused | 200 `{data: ProgressResource}`; version +1 khi đổi; `recorded_at` giữ nguyên | Mutation thật: một `progress_record.update` audit allow-list; không outbox. No-op: không đổi version/time/audit/outbox |
| AN-01 | `GET /programs/{id}/announcements?state=published|draft|all`; owner/member | 200 list envelope; owner xem Draft theo state; Customer mặc định Published, draft/all → 403 | Read-only, scope trước count; không receipt |
| AN-02 | `GET /announcements/{id}`; owner/member hiện hành | 200 `{data: AnnouncementResource}`; Draft chỉ owner; ngoài scope/outsider Draft trả 404 | Read-only; file metadata allow-list; không receipt |
| AN-03 | `POST /programs/{id}/announcements` `{"title":"...","body":"...","file_ids":[]}`; owner | 201 `{data:...state:draft,version:1,published_at:null}` | Tạo Draft và liên kết file atomically; file omission mặc định `[]`; không receipt/outbox |
| AN-04 | `PATCH /announcements/{id}` `{"expected_version":1,"file_ids":[]}`; owner, Draft | 200 `{data:...}`; omission giữ link set, `[]` tháo hết, `null` 422 | Link diff + file audit trong transaction; no-op không đổi version/time/audit; không outbox |
| AN-05 | `POST /announcements/{id}/publish`, `{"expected_version":1}`, UUID `Idempotency-Key`; owner | 200 Published resource version +1; cùng key/hash replay snapshot/status; mismatch cùng key → 409 | Một publish audit, một receipt 30 ngày, một outbox `announcement_published` với recipient snapshot; rollback toàn bộ nếu side effect lỗi |
| FE-01 | `GET /programs/{id}/fee-records?page=1&per_page=20` + filter được contract cho phép; owner/member | 200 list envelope; period giảm dần; filter AND; customer projection allow-list | Read-only; không receipt |
| FE-02 | `POST /programs/{id}/fee-records` `{"period":"2026-11","amount_minor":1200000}` + UUID key; owner, Active | 201 Fee projection, kỳ server-tính theo timezone; version 1, declared/unmarked | Một Fee + audit + outbox + durable receipt (`expires_at=NULL`) trong một transaction |
| FE-03 | `GET /fee-records/{id}`; owner/member hiện hành | 200 `{data: FeeResource}`; Customer không thấy actor/payment private metadata | Read-only; không receipt |
| FE-04 | `PATCH /fee-records/{id}` `{"expected_version":1,"amount_minor":1000000,"reason":"Điều chỉnh"}` + UUID key; owner | 200 full Fee projection, version +1; reason mới ở `last_change_reason` | Mutation: audit/outbox theo version + receipt. No-op: giữ version/time/audit/outbox, vẫn receipt cho key mới |
| FE-05 | `POST /fee-records/{id}/mark-paid` `{"expected_version":1}` + UUID key | 200; mark `marked_paid`, timestamp/actor server-set | Mutation: payment metadata + audit/outbox/receipt; cùng trạng thái đúng version là no-op, metadata cũ giữ |
| FE-06 | `POST /fee-records/{id}/mark-unpaid` `{"expected_version":2,"reason":"..."}` + UUID key | 200; paid→unpaid cần reason; `payment_mark_reason` cập nhật | Mutation: mark metadata + audit/outbox/receipt; no-op không ghi đè reason |
| FE-07 | `POST /fee-records/{id}/void` `{"expected_version":3,"reason":"Khai báo nhầm"}` + UUID key | 200 voided; giữ kỳ và payment metadata | Void metadata + audit/outbox/receipt atomically; record/receipt không bị xóa |

Mọi success response có `X-Request-ID`; body resource nằm trong `{data:...}`. List dùng `{data:[],meta:{current_page,per_page,total,last_page}}`. Error dùng `{code,message,request_id,errors}` và header `X-Request-ID`. Các endpoint write không nhận unknown/server-managed fields.

## Case dùng chung và validation

| Case IDs | Input/actor | Expected HTTP/code + body assertion | Side-effect oracle |
|---|---|---|---|
| AU-01..04 | unauthenticated / suspended / outsider / admin không có Workspace membership | 401 / 403 `account_inactive` / 404 scope / 404 scope; admin role tự thân không mở scope | Không lộ count, version, receipt hoặc resource; không ghi DB |
| AU-05..06 | member gọi owner mutation; revoked member gọi read | 403 / 404 | Không ghi side effect; quyền hiện hành được kiểm trước receipt |
| CM-01..04 | JSON string-number, float, bool thay integer; unknown field; malformed body object; expected_version <=0 | 422 `validation_failed`, `errors` gắn field | Không insert/update/audit/outbox/receipt |
| CM-05..07 | title/reason trim; body/note whitespace giữ nguyên nếu có nội dung; CRLF/CR→LF; UTF-8 không Unicode-normalize | 201/200 normalized theo contract; title/reason trim; canonical hash cùng normalization | DB/hash/storage nhận cùng giá trị; không chép private content vào audit |
| PG-01..04 | page default; `per_page=50`; `per_page=51`, `page=0`, invalid/unknown filter | 200 20 mặc định/50 tối đa; lỗi query 422; trang vượt cuối `data:[]`, metadata giữ total/last_page | Read-only; total sau scope/filter |
| PG-05..07 | Progress timestamp tie; Announcement published tie / Draft tie; Fee period tie | 200 theo `(recorded_at DESC,id DESC)`, `(published_at DESC,id DESC)`, `(created_at DESC NULLS LAST,id DESC)`, `(period_start DESC,id DESC)` | Thứ tự xác định; Draft trước Published trong `state=all` |
| PR-VAL-01..05 | value `0`, `100`, `-1`, `101`, `null`; metric khác; note null/omitted/2,000/2,001 chars | success với 0/100/null hợp lệ; 422 ngoài range/metric/note; response allow-list đúng | Create một row; invalid không side effect |
| PR-NOOP-01..03 | PATCH thiếu field, same value/note, stale expected_version dù payload giống | 422 / 200 hiện tại / 409 `stale_version` | No-op không đổi version/updated_at/recorded_at/audit/outbox; stale không ghi |
| AN-VAL-01..05 | thiếu/blank/trim title, giới hạn 180/181; body 1/10,000/10,001; file_ids omission/[]/null/duplicate/>5 | success giới hạn; invalid 422 theo field; `file_ids:null` 422 | Atomic link diff; invalid không sửa link |
| AN-PERM-01..03 | Customer `state=draft|all`; published member list; draft outsider/direct ID | 403 / 200 Published-only / 404 | Không trả Draft count/body/file metadata |
| AN-NOOP-01..04 | PATCH no-op đúng version; PATCH stale; empty patch; PATCH/publish Published | 200 unchanged / 409 `stale_version` / 422 / 409 state conflict | No-op không version/time/audit/outbox; lỗi không side effect |
| AN-IDEM-01..05 | publish thiếu/invalid UUID; same actor/key/request; same key đổi method/path/body; key mới publish lại; mất quyền rồi replay | 422 / snapshot 200 replay / 409 `idempotency_conflict` / 409 state conflict / 404/403 | Một recipient snapshot, audit, outbox, receipt; replay không nhân side effect và kiểm quyền hiện tại |
| FE-PERIOD-01..06 | valid `YYYY-MM`; `month` alias; invalid month; trước activation; current; future; timezone boundary/leap Feb | 201 valid range; 422 format/range; 409 duplicate kể cả voided | Server tính period_start/end; 1 fee/program/month |
| FE-AMT-01..06 | 0, max safe integer, negative, over max, float/scientific/string/bool/null; currency absent/VND/other/null | valid amount integer + default VND; invalid 422; non-VND 422 | Amount 0 unmarked; no payment metadata |
| FE-STATE-01..06 | edit declared/unmarked; edit marked_paid/voided; paid→unpaid có/thiếu reason; free fee mark; void giữ payment fields | 200 valid; 409 state conflict; 422 thiếu/blank reason; free mark 409 | Mỗi mutation thật version+1/audit/outbox/receipt; no-op giữ metadata; void giữ payment metadata |
| FE-IDEM-01..06 | key thiếu/sai; replay create Fee; same-key canonical reordered JSON/default; same key changed method/path/body; new key same period | 422 / replay giữ HTTP 201 + snapshot cũ / replay / 409 `idempotency_conflict` / 409 `fee_period_exists` | Shared actor/key unique; replay không thêm row/audit/outbox/receipt; durable Fee receipt `expires_at=NULL` |

## PostgreSQL constraint, race và rollback cases

| Case IDs | DB/protocol | Expected result | Oracle / test method |
|---|---|---|---|
| DB-01..07 | PostgreSQL schema: Fee program-month unique (kể cả void), amount safe range, VND-only, month boundary, status/mark enum, metadata consistency, zero amount unmarked; Progress metric/value/version; Fee actor/program FK RESTRICT | DB từ chối SQL trực tiếp vi phạm từng CHECK/FK/UNIQUE | PostgreSQL catalog + isolated `SAVEPOINT` invalid inserts; rollback savepoint sau từng SQLSTATE. Không chạy trên SQLite |
| RC-01 | Hai Fee create cùng Program/month, key khác | Một 201; một 409 `fee_period_exists` | Hai process/connection, barrier và row-lock wait; chỉ 1 Fee/version1/audit/outbox, hai receipt phù hợp outcome policy |
| RC-02 | Cùng actor/key concurrent trên cùng endpoint và qua endpoint/resource khác | Cùng canonical command replay snapshot; khác method/path/hash 409 | User lock + unique receipt; một mutation và tối đa một receipt |
| RC-03..05 | Fee create vs pause; D04 writer vs complete/cancel; PATCH Draft vs publish | Thứ tự commit khóa xác định; lifecycle thắng → mutation 409; writer thắng → lịch sử commit trước terminal; edit/publish một bên thắng, bên kia 409 | PostgreSQL process độc lập, barrier/lock observation, state/version cuối và không deadlock |
| RC-06..07 | Same expected_version edits/marks; file replace/delete vs publish | Tối đa một mutation; loser stale/state conflict; Published file set bất biến | IDs/version/link/audit/outbox/receipt trước-sau; file bytes không mất khi unlink |
| RB-01..04 | Inject failure sau file link diff, audit insert, outbox insert, receipt insert | Error response; mọi mutation rollback | Snapshot SQL resource/version/time/link/recipient/audit/outbox/receipt trước/sau bằng nhau; retry sạch commit đúng một lần |

Race thực thi ở D04-15 và fault injection ở D04-16 sau khi writer tồn tại; case IDs/expected outcomes được khóa tại đây. DB-01..07 chạy PostgreSQL sau migration D04-05; lượt D04-04 chỉ xác nhận hiện trạng/schema gap, không chạy invalid SQL lên bảng chứa dữ liệu fixture. Không dùng `DatabaseTruncation`, `RefreshDatabase`, reset/migration hoặc test fixture teardown trên `tutorlink_test`.

## Test source và kết quả đầu tiên

- `backend/tests/Feature/BeD04RouteContractTest.php`: 16 route-registration probes, không ghi DB.
- `backend/tests/Feature/BeD04PostgresSchemaContractTest.php`: PostgreSQL-only assertions cho schema Fee/Progress/Announcement và CHECK coverage; chỉ đọc `information_schema`/`pg_constraint`.
- PostgreSQL barrier/process tests cho RC-01..07 và fault injection RB-01..04 được khóa bằng IDs, expected HTTP và DB oracle tại bảng trên; harness thực thi cùng code ở D04-15/16, khi writer/fault seam đã tồn tại. Không mô phỏng bằng SQLite.
- First run trên `tutorlink_test` fail cả 16 route probes và 13 schema assertions vì route/schema BE-D04 chưa được triển khai. Bootstrap kết nối PostgreSQL thành công; không có lỗi cấu hình.
