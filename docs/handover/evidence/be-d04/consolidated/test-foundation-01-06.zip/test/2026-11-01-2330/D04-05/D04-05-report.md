# D04-05 — Migration/backfill trên test DB

**Kết quả: Đạt trên test.** Chỉ thay đổi `tutorlink_test`; DB ứng dụng `tutorlink` không bị chạm tới.

- Đã tạo và chạy migration `2026_11_01_233000_add_be_d04_workspace_schema`. Test DB hiện có 43 bảng, 26 migration đã chạy; D04 migration xuất hiện đúng một lần. Bảy migration cũ ngoài D04 vẫn pending trên DB clone; toàn bộ chuỗi 33 migration đã chạy thành công trên DB rỗng diễn tập.
- Giữ nguyên dữ liệu hiện có: 59 Fee, 55 Progress, 4 Announcement; 29 Files và 1 file link. Fee đều ở `declared/unmarked/version=1`; mọi Progress và Announcement có version 1. Không phát sinh row sai trạng thái/version.
- Backfill giữ ID/lịch sử; các fingerprint trước/sau backup-restore khớp. Chạy migration lần hai trả `Nothing to migrate`, không lặp dữ liệu.
- Fail-fast trên legacy clone: **7 tests / 27 assertions đạt**, bao gồm Fee `confirmed/cancelled`, Progress fractional/sai metric/scope, Announcement content rỗng và Fee period không hợp lệ; migration không ghi dấu đã chạy hoặc đổi schema ở các trường hợp bị từ chối.
- PostgreSQL constraint probes: **18 tests / 33 assertions đạt**. Schema contract tests: **13 tests / 19 assertions đạt** trên DB rỗng và test DB.
- Side effects trước/sau: audit_logs 3/3, notification_outbox 0/0, idempotency_receipts 0/0, notifications 0/0. Migration không tự tạo audit/notification/receipt.
- Đã diễn tập backup, restore và fingerprint; database/file backup diễn tập đã được dọn. Test runtime chính được giữ nguyên để tiếp tục D04-06.

## Bằng chứng

Thư mục run: [D04-05 evidence](./). Manifest runtime: [environment.json](environment.json). Xem [trạng thái cuối DB](final-test-db-state.txt), [migration legacy](migration-legacy-run.txt), [chạy lại migration](migration-second-run.txt), [fail-fast tests](migration-legacy-preflight-tests.txt), [constraint tests](constraint-tests.txt), [schema tests DB rỗng](schema-empty-db-tests.txt), [backup/restore manifest](backup-restore-manifest.md), [side effects trước](side-effects-before.txt) và [sau](side-effects-after.txt).
