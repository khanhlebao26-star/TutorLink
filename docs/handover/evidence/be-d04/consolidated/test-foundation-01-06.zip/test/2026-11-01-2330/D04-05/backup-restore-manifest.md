# Backup và restore drill — D04-05

- Database đích: `tutorlink_test` (PostgreSQL 16.15, Docker test runtime).
- Backup tạm trước migration: `/tmp/tutorlink_test_d04_05_before.dump`.
- Kích thước: 172405 bytes.
- SHA-256: `05a38d69cf008cdd80fcddf5b491ce0ab076860309ecb47b8eafa177871bcd4b`.
- Restore drill: khôi phục vào database tạm `tutorlink_d04_restore_20261101`; các fingerprint trước/sau khớp chính xác cho các row set được đối chiếu: fees (59), progress (55), announcements (4), files (5), file_links (1).
- Cleanup: database restore drill và file dump tạm đã được xóa sau khi xác nhận; không thay đổi `tutorlink` hoặc xóa `tutorlink_test`.
- Đối chiếu fingerprint: [before](before-row-fingerprints.txt), [after](after-row-fingerprints.txt).
