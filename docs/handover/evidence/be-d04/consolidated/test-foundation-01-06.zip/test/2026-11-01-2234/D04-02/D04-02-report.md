# D04-02 — Cô lập môi trường test và kiểm tra database guard

**Kết quả:** Đạt · **Thời gian:** 01/11/2026 22:41 Asia/Ho_Chi_Minh  
**Source:** branch `be-d04`, commit `135efcc8ec5c4c73cff8d58cabc62a17772234bf`, có thay đổi chưa commit.  
**Runner image:** `tutorlink-h01-backend-test:local`, ID `sha256:192bbbcadc3329386a3dfaaa7933372c7a746b7809574acb96b2d9b1eecaf6c9`.

## Môi trường

Dùng compose project `tutorlink`, service `test-db` đang chứa bản sao `tutorlink_test`. Effective test network `tutorlink_testing` là internal; DB không publish cổng host. Runner chỉ chạy bằng `run --rm`, không khởi động app/worker. Compose override riêng D04 ghi evidence vào thư mục này, mount `storage/app` bằng `tmpfs`, đặt mail `array`, queue `sync`, broadcast `null`, xóa Slack credentials khỏi runner và không mở cổng API.

## Guard và kiểm chứng

Runner `php scripts/test-console.php check` trả `SAFE`: `APP_ENV=testing`, config cache đang `absent` (đường dẫn cấu hình `/tmp/tutorlink-testing-config.php`), host `test-db`, database `tutorlink_test`, user `tutorlink_test_runner`, server address riêng `172.22.0.2`. Guard từ chối host ngoài allowlist trước khi kết nối; sau bootstrap, kiểm tra database/user thực tế và địa chỉ PostgreSQL trước lệnh migrate/reset. `TestCase` cũng kiểm tra identity trước khi test trait có thể truncate dữ liệu.

Hai unit test class cho database isolation và console guard đạt **8 tests, 45 assertions**, gồm từ chối database ứng dụng, host ứng dụng và cached configuration sai trước khi kết nối. Không kết nối database ứng dụng để thử guard.

Sau kiểm tra, nguồn và test đều có 43 bảng, 154 dòng tổng, 25 migration và 51 user. Không chạy migration, seed, reset hay mutation nghiệp vụ. Test DB vẫn giữ nguyên bản sao; dữ liệu bản sao chưa anonymize.

## Bằng chứng

- [Environment manifest](environment.json)
- [Preflight database identity](environment-check.txt)
- [Guard test output](guard-tests.txt)
- [Đối chiếu dữ liệu sau preflight](database-preservation.txt)
- [Source patch và compose override](source.patch), SHA-256 `7b90aa57eae92e271db8d8952eb55378a7d79b360be86a6f320d37d816435f08`
