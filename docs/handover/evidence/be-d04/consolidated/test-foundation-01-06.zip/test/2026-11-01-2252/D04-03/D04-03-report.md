# D04-03 — Test report

**Kết quả: ĐẠT** · 01/11/2026 · môi trường `tutorlink_test` · branch `be-d04` · source commit `135efcc8ec5c4c73cff8d58cabc62a17772234bf`.

Đã tạo bộ fixture tổng hợp có expected result cho authorization, lifecycle, Fee period, Progress/Announcement ordering, pagination, file validation và Program Overview. Seeder được bảo vệ bằng DB identity guard, chỉ cho phép `tutorlink_test`, và chạy lặp an toàn.

- Dữ liệu: 8 actors, 4 Programs, 4 memberships, 59 Fees, 55 Progress, 4 Announcements, 5 Files, 3 Program Sessions, 5 Tasks, 2 Task Submissions và 1 Announcement file link.
- Biên dữ liệu: activation/current month, February 2024 (29 ngày), không có tháng tương lai, 59/55 records cho pagination, timestamp ties cho deterministic ordering, Draft, revoked/late member và file states clean/pending/rejected.
- Seeder chạy hai lần thành công; snapshot sau lần hai byte-identical với trước.
- Guard suite: 8 tests, 57 assertions, pass. DB identity check xác nhận PostgreSQL `tutorlink_test` qua host `test-db`.
- DB nguồn `tutorlink`: 43 public tables, 154 rows, 25 migrations, không đổi. Test DB: 43 tables, 313 rows, 25 migrations. Không chạy migration, reset hoặc seed trên DB nguồn.
- File objects là PDF giả 74 bytes, nằm trong storage riêng gắn vào evidence run.

Các fixture oracle chưa phải bằng chứng API behavior; chúng là cơ sở để viết và chạy case từ D04-04 trở đi.

## Evidence

- [Fixture matrix và expected results](fixtures.md)
- [Fixture snapshot](fixtures.json)
- [Environment manifest](environment.json)
- [Seed idempotency](seed-idempotency.txt)
- [Database preservation](database-preservation.txt)
- [Post-seed database guard](database-guard-after-fixtures.txt)
- [Guard unit tests](guard-tests.txt)
- [Successful seed run](seed-run-2.txt)
- [Seeder and test environment patch](source.patch)
