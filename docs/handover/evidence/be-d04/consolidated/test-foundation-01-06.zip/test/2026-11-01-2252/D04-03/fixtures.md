# D04-03 — Bộ fixture kiểm thử BE-D04

**Môi trường:** `tutorlink_test` · **Thời điểm:** 01/11/2026 22:56 Asia/Ho_Chi_Minh
**Source:** `be-d04` / `135efcc8ec5c4c73cff8d58cabc62a17772234bf`; runner image `tutorlink-h01-backend-test:local`. Tất cả actor email dùng miền giả `tutorlink.test`; fixture không dựa vào ID hoặc thông tin cá nhân của DB nguồn.

## Actor fixtures

| ID | Email | Role | Account state |
| --- | --- | --- | --- |
| 65 | be-d04-admin@tutorlink.test | admin | active |
| 66 | be-d04-inactive@tutorlink.test | customer | suspended |
| 68 | be-d04-late-member@tutorlink.test | customer | active |
| 63 | be-d04-member@tutorlink.test | customer | active |
| 62 | be-d04-other-tutor@tutorlink.test | tutor | active |
| 64 | be-d04-outsider@tutorlink.test | customer | active |
| 61 | be-d04-owner@tutorlink.test | tutor | active |
| 67 | be-d04-revoked@tutorlink.test | customer | active |

## Programs và membership

| Program ID | Trạng thái | Owner | Customer ID | Activated at UTC | Ends at UTC |
| --- | --- | --- | --- | --- | --- |
| 5 | active | be-d04-owner@tutorlink.test | 68 | 2021-12-31T17:00:00+00:00 | — |
| 8 | cancelled | be-d04-other-tutor@tutorlink.test | 63 | 2026-07-31T17:00:00+00:00 | 2026-10-15T05:00:00+00:00 |
| 7 | completed | be-d04-other-tutor@tutorlink.test | 63 | 2026-07-31T17:00:00+00:00 | 2026-10-31T16:59:59+00:00 |
| 6 | paused | be-d04-owner@tutorlink.test | 67 | 2026-09-30T17:00:00+00:00 | — |


Tất cả Program dùng timezone `Asia/Ho_Chi_Minh`. Membership rows:

| Membership ID | Program | Member | State | Joined at UTC | Left at UTC |
| --- | --- | --- | --- | --- | --- |
| 3 | D04 Fixture Active | be-d04-late-member@tutorlink.test | active | 2026-10-20T17:00:00+00:00 | — |
| 6 | D04 Fixture Cancelled | be-d04-member@tutorlink.test | active | 2026-07-31T17:00:00+00:00 | — |
| 5 | D04 Fixture Completed | be-d04-member@tutorlink.test | active | 2026-07-31T17:00:00+00:00 | — |
| 4 | D04 Fixture Paused | be-d04-revoked@tutorlink.test | cancelled | 2026-08-31T17:00:00+00:00 | 2026-10-18T17:00:00+00:00 |


Unique constraint hiện hành cho phép một Customer membership mỗi Program. Vì vậy revoked member và member gia nhập sau publish được bố trí trên hai Program riêng: Paused có revoked member; Active có late member gia nhập sau khi Announcement đã Published.

## Fixture ranges và expected results

- **Fee:** 59 tháng liên tiếp từ `2022-01` (tháng activation) tới `2026-11` (tháng hiện tại), timezone `Asia/Ho_Chi_Minh`. `2024-02` kết thúc `2024-02-29`; tháng `2021-12` trước activation và `2026-12` tương lai không có record. Có một Fee amount `0`. Thứ tự kỳ giảm dần; với 59 rows, page size mặc định 20 cho 20/20/19, page size 50 cho 50/9. Fee contract yêu cầu tháng tương lai và trước activation bị từ chối.
- **Progress:** 55 record `progress_percent`, giá trị nguyên 0–100. Hai record có cùng `recorded_at=2026-10-22T12:00:00Z`, IDs `1` và `2`; thứ tự tie-break giảm dần kỳ vọng ID `2` trước ID `1`. Pagination tạo 20/20/15 và 50/5.
- **Announcement:** 3 Published, trong đó IDs `1`/`2` cùng `published_at=2026-10-20T03:00:00Z`; list tie-break kỳ vọng ID `2` trước. Draft ID `3` chỉ Tutor owner đọc qua `state=draft|all`; Customer mặc định chỉ Published. Announcement ID `4` được publish trước khi member bị revoke khỏi Program Paused. Member gia nhập Active sau publish được quyền đọc Published theo membership hiện tại nhưng không được notification hồi tố.
- **Authorization:** owner chỉ trong Program của mình; Customer chỉ khi membership hiện hành; revoked member và outsider không đọc; Admin không có quyền Workspace theo role đơn thuần; account `suspended` trả `403 account_inactive`. Active cho phép mutation theo contract; Paused chặn tạo Session/Task/Fee nhưng vẫn cho Progress và Announcement; Completed/Cancelled chỉ đọc.
- **Overview:** Program Active có Session `scheduled` tương lai ID `1` làm `next_session`; task counts gồm đúng một mỗi trạng thái (`todo`, `in_progress`, `submitted`, `completed`, `cancelled`); latest Progress ID `2`; latest Published Announcement ID `2`. Draft không được dùng làm `latest_announcement`.
- **Files:** file hợp lệ ID `25` thuộc owner, purpose `announcement_attachment`, trạng thái `clean` và được link tới Announcement ID `1`. Các fixture sai: file `wrong_owner` ID `26`; sai purpose ID `27`; `pending` ID `28`; `rejected` ID `29`. Mỗi file có object giả 74 bytes trong storage test riêng; checksum SHA-256 xem trong manifest.

Các expected values trên là fixture oracle để viết case ở D04-04; chưa phải kết quả API vì route BE-D04 chưa triển khai.

## Kết quả chạy seed

Seeder `d04:seed` có guard DB identity và upsert theo fixture key. Chạy hai lần thành công; snapshot trước/sau byte-identical, không tạo bản sao. Không chạy migration, reset hoặc seed lên database `tutorlink`. Nguồn vẫn 43 bảng/154 rows/25 migrations; test DB có 43 bảng/313 rows/25 migrations sau khi thêm 159 fixture rows tổng hợp.

## Evidence

- [Fixture IDs/states snapshot](fixtures.json)
- [Environment manifest](environment.json)
- [Seed idempotency result](seed-idempotency.txt)
- [Database counts and source preservation](database-preservation.txt)
- [Post-seed DB guard](database-guard-after-fixtures.txt)
- [Guard unit tests](guard-tests.txt)
- [Seeder run 2](seed-run-2.txt)
- [Source patch](source.patch), SHA-256 `0e4d95917d98a547e4b64f79057c25865fd72272626dd5a838af959c4bfa33b0`
- PDF fixture objects: [valid](storage/private/be-d04/fixtures/valid.pdf), [wrong owner](storage/private/be-d04/fixtures/wrong_owner.pdf), [wrong purpose](storage/private/be-d04/fixtures/wrong_purpose.pdf), [pending](storage/private/be-d04/fixtures/pending.pdf), [rejected](storage/private/be-d04/fixtures/rejected.pdf).
