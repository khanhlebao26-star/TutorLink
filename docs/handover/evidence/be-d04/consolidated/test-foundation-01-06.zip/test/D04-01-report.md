# BE-D04-01 — Baseline môi trường test

**Ngày ghi nhận:** 01/11/2026, Asia/Ho_Chi_Minh
**Branch/HEAD của source dùng cho test:** `be-d04` / `135efcc8ec5c4c73cff8d58cabc62a17772234bf`
**Trạng thái D04:** chưa triển khai; PostgreSQL test đã khởi chạy riêng bằng compose project `be-d04-test`.

## Môi trường test đã xác minh từ cấu hình

`compose.testing.yml` khai báo PostgreSQL `postgres:16-alpine`, DB `tutorlink_test`, user `tutorlink_test_runner`, data trên `tmpfs`, `APP_ENV=testing` và network internal. Backend test chạy Pest trong container. Test DB sẽ rỗng sau khi container dừng vì dùng `tmpfs`; cần lưu log/artifact ra host trong lúc test chạy.

Compose đang mount output mặc định vào `./outputs/be-h01:/evidence`. Cấu hình này chưa dành cho BE-D04; D04-02 cần mount evidence riêng trước khi khởi chạy runner. Bài test D04 phải rebuild image sau thay đổi code vì backend-test build source vào image và không mount source code trực tiếp.

## Baseline source và route

- Tập target gồm 16 method/path: 3 Progress, 5 Announcement, 7 Fee, 1 Overview theo contract hiện tại.
- OpenAPI được commit tại baseline có 89 operations và không có path Progress/Announcement/Fee/Overview.
- Dependency commits cho D03/H03/K02 hiện diện trên HEAD; danh sách/hash ở report actual, không phụ thuộc database test.
- Test DB được xác minh healthy, kết nối thành công vào `tutorlink_test` bằng user `tutorlink_test_runner`; PostgreSQL 16.15, 0 bảng public. `php artisan migrate:status` trả `Migration table not found` (exit 1), phù hợp baseline DB mới rỗng. Không chạy migration; không suy ra trạng thái này từ runtime ứng dụng. Bằng chứng: [runtime environment](runtime-2026-11-01/environment.json), [migration status](runtime-2026-11-01/migration-status.txt).
- Chưa có test results, API response test, screenshot hoặc fixture D04. Các mục này thuộc D04-02 trở đi.

## Kết quả và bước tiếp theo

D04-01 test baseline **đạt**: cấu hình đã đọc, PostgreSQL test chạy và kết nối được, danh tính database xác nhận, migration status của DB rỗng đã ghi nhận. Chưa xác minh database guard, storage/worker isolation hoặc HTTP test endpoint; đó là tiêu chí D04-02.

**Bằng chứng:** `compose.testing.yml` tại HEAD; OpenAPI hiện hành; source manifest chung ghi tại [summary](../D04-01-summary.md); runtime DB evidence ở trên. D04-02 vẫn phải kiểm database guard trước khi chạy migration/reset.

## Sao chép database nguồn sang test (01/11/2026)

Theo yêu cầu tiếp theo, database hiện tại `tutorlink` đã được stream bằng `pg_dump`/`pg_restore` vào `tutorlink_test`. Đích trước thao tác rỗng; restore thành công. Đối chiếu sau restore xác nhận cùng 43 bảng, 410 cột, 188 constraints, 115 index, 32 sequence, 25 migration và số dòng từng bảng khớp nguồn. Chi tiết trong [database copy evidence](runtime-2026-11-01/database-copy.json).

Bản sao giữ nguyên dữ liệu nguồn, không anonymize; database đích nằm trong network test nội bộ và lưu trên `tmpfs`. Không có dump file trung gian hoặc nội dung hàng dữ liệu được ghi vào report. DB test hiện đã có dữ liệu, vì vậy D04-02 phải kiểm tra guard theo cấu hình không ghi dữ liệu trước khi chạy reset/migration.
