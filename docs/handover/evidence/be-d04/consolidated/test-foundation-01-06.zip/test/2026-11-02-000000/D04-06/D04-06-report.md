# D04-06 — Nền validation, quyền, khóa và response

**Kết quả: Đạt trên `tutorlink_test` trong phạm vi nền chung.** Không thêm route sản phẩm D04 ở bước này; focused HTTP tests đăng ký route probe tạm trong tiến trình test để kiểm middleware, request base và envelope trước khi các API được triển khai ở D04-07 trở đi.

- Middleware riêng cho route D04 đổi CRLF/CR thành LF, trim `title`/`reason`, giữ nguyên whitespace trong `body`/`note`; global trim/empty-to-null không làm mất khác biệt giữa omission, `null` và `""`.
- `BeD04ApiRequest` dùng allow-list, yêu cầu JSON object, strict integer và từ chối field/query không biết cùng chuỗi rỗng/toàn whitespace. Helper version giới hạn `1..2,147,483,647`.
- `BeD04Workspace` ẩn workspace ngoài scope bằng 404; member hiện hành chỉ đọc, mutation trả 403; account không active trả 403. Writer helper khóa Users tăng ID → TutorProfile → Program → ProgramMember rồi mới cho callback khóa resource/File/FileLink. File/link lock bắt buộc ở trong writer transaction. Program và account được đọc lại sau lock.
- Error stale version trả 409 `stale_version`, current_version chỉ nằm trong errors sau khi scope/owner authorization đã qua; errors dùng chung envelope và `X-Request-ID`.
- **Focused suite đạt 11 tests / 79 assertions** trên PostgreSQL 16.15. Transcript chứa request/response cho 401/403/404/409/422, strict integer, field/query unknown, JSON object, normalization, omission/null và stale. Lock query order được xác minh qua PostgreSQL `FOR UPDATE`.
- DB preservation khớp D04-05 baseline: 43 bảng, 26 migrations, counts Fee/Progress/Announcement/File/FileLink ổn định; audit/outbox/receipt/notification không đổi. Dùng dữ liệu fixture có sẵn, không seed/reset/truncate.

## Bằng chứng

- [Test report](D04-06-report.md)
- [HTTP transcript và test log](shared-request-tests.txt)
- [Database preservation](database-preservation.txt)
- [Environment manifest](environment.json)
- [Source patch](source.patch)

Các writer D04 sẽ gọi `BeD04Workspace::withLockedOwnerProgram` rồi recheck lifecycle/resource version trong callback; race nhiều process, receipt replay/no-op và rollback side effects được kiểm ở các bước writer tương ứng, theo plan D04-15/16.
