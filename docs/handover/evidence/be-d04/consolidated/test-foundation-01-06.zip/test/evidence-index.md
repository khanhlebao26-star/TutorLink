# BE-D04 Test Evidence Index

All D04-01..20 test plan items are checked and linked in the [master plan](../../../BE-D04-plan.md). D04-22 final-candidate verification is listed separately because it was a pre-apply test gate stored beside the actual rollout artifacts.

| Step | Test report/evidence |
|---|---|
| D04-01 | [Summary](../D04-01-summary.md) · [test report](D04-01-report.md) |
| D04-02 | [Test report](2026-11-01-2234/D04-02/D04-02-report.md) |
| D04-03 | [Test report](2026-11-01-2252/D04-03/D04-03-report.md) |
| D04-04 | [Test report](2026-11-01-2316/D04-04/D04-04-report.md) |
| D04-05 | [Migration/backfill and restore report](2026-11-01-2330/D04-05/D04-05-report.md) |
| D04-06 | [Foundation/API validation report](2026-11-02-000000/D04-06/D04-06-report.md) |
| D04-07 | [Progress API report](2026-11-02-0018/D04-07/D04-07-report.md) |
| D04-08 | [Draft Announcement report](2026-11-02-0025/D04-08/D04-08-report.md) |
| D04-09 | [Announcement file integration report](2026-11-02-0033/D04-09/D04-09-report.md) |
| D04-10 | [Publish transaction report](2026-11-02-0045/D04-10/D04-10-report.md) |
| D04-11 | [Fee API report](2026-11-02-0045/D04-11/D04-11-report.md) |
| D04-12 | [Overview report](2026-11-02-0045/D04-12/D04-12-report.md) |
| D04-13 | [Payload/list/timestamp report](2026-11-02-0045/D04-13/D04-13-report.md) |
| D04-14 | [Idempotency/no-op report](2026-11-02-0045/D04-14/D04-14-report.md) |
| D04-15 | [PostgreSQL race report](2026-11-02-0045/D04-15/D04-15-report.md) |
| D04-16 | [Rollback/fault report](2026-11-02-0045/D04-16/D04-16-report.md) |
| D04-17 | [Outbox/retention report](2026-11-02-0045/D04-17/D04-17-report.md) |
| D04-18 | [Regression/OpenAPI/docs report](2026-11-02-0045/D04-18/D04-18-report.md) |
| D04-19 | [HTTP API matrix report](2026-11-02-0045/D04-19/D04-19-report.md) · [96-case transcript](2026-11-02-0045/D04-19/http-transcript.jsonl) |
| D04-20 | [Test release summary](2026-11-02-0045/D04-20/test-summary.md) · [release manifest](2026-11-02-0045/D04-20/release-manifest.json) · [test runbook](2026-11-02-0045/D04-20/runbook.md) |
| D04-22 pre-apply final-candidate retest | [Test report](../actual/local/2026-11-02-0608/D04-22/test-report.md) · [candidate manifest](../actual/local/2026-11-02-0608/D04-22/release-manifest.json) · [test DB restore comparison](../actual/local/2026-11-02-0608/D04-22/test-db-restore-check.txt) |

For a concise acceptance summary see [BE-D04-test-report.md](../../../BE-D04-test-report.md). Actual runtime evidence is indexed separately in [actual evidence index](../actual/evidence-index.md).
