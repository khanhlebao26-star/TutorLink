# BE-D04 — Bằng chứng nền cho bổ sung contract, 01/11/2026

Phạm vi: đọc tài liệu, source, lịch sử Git, route local và issue GitHub. Không chạy migration, mutation nghiệp vụ, delivery worker hoặc bộ test backend. Đây không phải báo cáo nghiệm thu BE-D04.

## 1. Checkout và phụ thuộc

- Branch: `be-d04`; HEAD: `135efcc8ec5c4c73cff8d58cabc62a17772234bf`.
- Working tree ban đầu: Catalog đã modified; `docs/handover/BE-D04-contract.md` untracked. Lượt này giữ thay đổi có sẵn, không commit/push.
- `git merge-base --is-ancestor <hash> HEAD` trả exit 0 cho từng hash sau:

| Phụ thuộc | Hash đã kiểm | Ý nghĩa |
|---|---|---|
| BE-D03 | `c67eae1ff0c141be051f1d44073fd41f54b46628` | Implementation Task/Submission + handover |
| BE-D03 regression | `9c9d7468853aadbc2c32928fa55598e945d04d4c` | Giữ payload và UTC timestamp |
| BE-H03 | `2026c996400137da31d21b1e7064cb4d4823b51e` | Thay đổi H03 |
| BE-H03 merge | `70125345155cb3c85bd949676701e74967848dac` | Merge PR #77, `codex/2w-be-h03-fix` |
| BE-K02 writer | `a54336c0bba3246c5ba4c73e648ee6e908f25227` | Giao diện outbox |
| BE-K02 handover | `7834e5f42fe9410f2e576c08de0325b6d8b6d8a3` | K02.8 runbook/demo/handover |

Ancestry chứng minh commit có trong branch; CI và integration BE-D04 cần bằng chứng thực thi riêng.

## 2. Graphify làm bản đồ, source làm bằng chứng runtime

Graph hiện có 4.076 nodes. Đã chạy `graphify reflect --if-stale` (0 memories), query Progress/Announcement/Fee/contract, query file/receipt, `graphify explain "Idempotency receipts"`, và path Announcement → FileController. Query rộng có budget truncation; đã thu hẹp theo node/source và đọc tài liệu/source tương ứng, không coi phần bị cắt là đã đọc. Path có cảnh báo match Announcement mơ hồ và không tìm thấy directed path; không suy ra integration từ kết quả này. Không có wiki/index.md ở lần kiểm tra.

Từ vựng khớp trong graph: progress, announcement, fee, idempotency, program, file, audit, contract, lifecycle, publish, schema. Các nguồn quan trọng:

- [BR-19/20/21/22/23/25/26](<../../../Domain Documentation/Business Rules.md>) và [decision register D08/D21/D22](../../../UNRESOLVED_DECISIONS_2026-10-20.md).
- [Progress PRD](<../../../Modules Documentation/M07 — Task & Progress/M07-F04 PRD — Ghi và xem Progress.md>), [Fee PRD](<../../../Modules Documentation/M08 — Fee, Announcement & Notification/M08-F01 PRD — Quản lý Fee Record.md>), [Announcement PRD](<../../../Modules Documentation/M08 — Fee, Announcement & Notification/M08-F02 PRD — Tạo và công bố Announcement.md>).
- [Database Design](<../../../Architecture & Technical Design/Database Design — TutorLink.md>): Progress/Announcement dòng 705–751, Fee dòng 755–827, receipt dòng 1100–1121. Fee receipt giữ đến khi Fee và lịch sử liên quan được purge; không phải TTL chung 30 ngày.
- [M10-F03](<../../../Modules Documentation/M10 — Files/M10-F03 PRD — Gắn File vào resource.md>), [M09-F05 audit catalog](<../../../Modules Documentation/M09 — Review, Report & Audit/M09-F05 PRD — Ghi và tra cứu Audit.md>), [K03.1](../../BE-K03-K03.1-contract.md), [K02.1](../../BE-K02-K02.1-contract.md), [K04.1](../../BE-K04-K04.1-contract.md).

## 3. Những phát hiện trực tiếp từ source tại HEAD

| Source | Phát hiện |
|---|---|
| `backend/app/Http/Requests/FileUploadRequest.php:60` | Allow-list upload chưa nhận `announcement_attachment` |
| `backend/app/Http/Controllers/Api/V1/FileController.php:114` | Link chung chỉ thực hiện `verification_document`; Announcement trả 409 |
| `backend/app/Http/Controllers/Api/V1/FileController.php:158` | Download có owner bypass, Task/Submission và verification-document; chưa có policy Announcement |
| `backend/app/Http/Controllers/Api/V1/FileController.php:25` | Metadata show chỉ file owner; cần bổ sung member access theo Announcement |
| `backend/app/Actions/Files/CompleteFile.php:26` | Complete khóa User rồi File, kiểm kỹ thuật; `clean` không chứng nhận antivirus |
| `backend/app/Actions/Programs/TransitionProgram.php:60` | Users tăng ID → Profile → Listing nếu có → Program; state đọc lại sau khóa |
| `backend/app/Actions/Sessions/SaveSession.php:76` | Writer Session phối hợp khóa Users/Profile/Program/resource và shared receipt |
| `backend/app/Support/NotificationOutboxWriter.php:40` | Có type Announcement/Fee; ghi trong transaction, unique recipient/type/event và payload allow-list |
| `backend/app/Console/Commands/PurgeNotificationData.php:49` | Cleanup hiện hữu chỉ lặp outbox/notifications/audit, không chứng nhận Fee receipt cleanup |
| `backend/routes/console.php:14` | Có lịch invitation expiry/outbox monitor/purge; chưa có lịch receipt riêng trong file này |
| `backend/bootstrap/app.php:21` | Ngoại lệ trim dành Message/Task, chưa có BE-D04; phải đồng bộ canonicalization với middleware |

Kiểm thêm migration `2026_10_26_212524_add_invitation_acceptance_support_tables.php`: receipt actor FK ON DELETE RESTRICT, expires_at nullable và có index. Nhánh lazy-expiry ở AcceptInvitation, TaskController feedback, SaveSession và TransitionSession đều yêu cầu expires_at khác NULL mới xóa receipt. Không có runtime Fee writer để test retention trong lượt này; cần giữ bảo vệ NULL và bổ sung regression khi tích hợp.

## 4. Route/OpenAPI đọc lại

Lệnh chỉ đọc: `docker compose exec -T backend php artisan route:list --path=api/v1 --json`.

- [Output runtime](routes-baseline-2026-11-01.json): 89 entries.
- `docs/api/openapi.json`: 89 operations (đếm các HTTP methods).
- Không có path chứa `progress-records`, `announcements`, `fee-records`, `/overview` trong runtime hoặc OpenAPI; source `backend/routes/api.php` cũng thiếu các nhóm này.
- Chưa sinh lại OpenAPI; chưa chứng nhận behavior hoặc parity ngoài tập 16 endpoint BE-D04.

## 5. Issue đọc từ GitHub ngày 01/11/2026

Connected GitHub `fetch_issue` cho [#78](https://github.com/khanhlebao26-star/TutorLink/issues/78), [#74](https://github.com/khanhlebao26-star/TutorLink/issues/74), [#75](https://github.com/khanhlebao26-star/TutorLink/issues/75), [#68](https://github.com/khanhlebao26-star/TutorLink/issues/68): đều `open` tại lần đọc này. #78 có 0 comments, owner Dũng, dependencies BE-D03/BE-H03/BE-K02/D22. #74 có 1 comment, #75/#68 có 0. Trạng thái issue không tự chứng minh trạng thái merge; merge H03 được xác minh qua local Git ở trên.

## 6. Giới hạn

Không truy vấn lại row counts/schema DB ứng dụng trong lượt này. Snapshot database rỗng/25 migration ở contract cũ là thông tin lịch sử được giữ, phải kiểm lại ở môi trường triển khai. Field/query/no-op/schema được quy định trong contract đích; source tại baseline này chưa thực hiện chúng.
