# BE-D04-01 — Baseline summary

**Ngày:** 01/11/2026, Asia/Ho_Chi_Minh · **Branch:** `be-d04` · **HEAD:** `135efcc8ec5c4c73cff8d58cabc62a17772234bf`.

D04-01 hoàn tất theo phạm vi baseline chỉ đọc. Test PostgreSQL đã khởi chạy và kết nối thành công. Sau baseline rỗng ban đầu, theo yêu cầu đã sao chép DB nguồn sang test; hiện có 43 bảng và 25 migration, số dòng từng bảng khớp nguồn. Runtime ứng dụng Docker local có 89 route entries, 120 method atoms, 89 operations trong OpenAPI và chưa có route BE-D04; 25 migration `Ran`, 7 `Pending`. Hai loại môi trường được ghi riêng; runtime local không đại diện staging/production.

- [Report dành cho môi trường test](test/D04-01-report.md)
- [Test DB runtime evidence](test/runtime-2026-11-01/environment.json)
- [Test DB migration status trước khi copy](test/runtime-2026-11-01/migration-status.txt)
- [Kết quả copy DB nguồn → test](test/runtime-2026-11-01/database-copy.json)
- [Report dành cho dự án/runtime hiện tại](actual/D04-01-report.md)
- [Route JSON runtime local](actual/routes-2026-11-01.json)
- [Migration status runtime local](actual/migration-status-2026-11-01.txt)

Sáu commit BE-D03/BE-H03/BE-K02 được xác nhận là ancestor của HEAD. Thay đổi tài liệu Catalog có sẵn được ghi lại, không gộp vào code backend. Chưa chạy test, migration, seed/reset, hoặc mutation nghiệp vụ.
