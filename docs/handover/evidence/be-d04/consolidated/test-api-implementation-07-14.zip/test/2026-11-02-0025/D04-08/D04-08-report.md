# D04-08 — Draft Announcement API (test)

**Kết quả:** Hoàn tất trên `tutorlink_test`, PostgreSQL 16.15. Suite focused đạt **3 tests / 115 assertions**.

Đã triển khai GET list/detail, POST Draft và PATCH Draft. Owner xem Draft qua `state=draft|all`; Customer chỉ thấy Published, yêu cầu Draft/all trả 403, còn detail Draft trả 404. Pagination mặc định 20/tối đa 50, Published và Draft có thứ tự ổn định theo contract. POST/PATCH kiểm title/body/file IDs, Program state, version và Published immutability.

File IDs được khóa cùng thứ tự Program → Announcement → Files → FileLinks; tập mới được kiểm trước khi áp dụng diff. Omission giữ liên kết, `[]` tháo link, file giữ lại không bị tạo audit, unlink không xóa File. File diff có `file.link`/`file.unlink`; PATCH cùng nội dung/tập không tăng version/time/audit/outbox. Create/edit Draft không ghi audit nội dung hoặc outbox.

Sau rollback, DB giữ 4 Announcement, 1 Announcement file link, 29 Files; không có Announcement file audit/outbox mới; D04 migration vẫn đúng một lần. PostgreSQL sequence có thể tăng do insert đã rollback. Pint, PHP syntax và `git diff --check` đạt.

**Bằng chứng:** [API transcript](announcement-draft-tests.txt), [DB sau chạy](database-after.txt), [môi trường](environment.json). Chỉ kết nối `tutorlink_test`.
