# D04-09 — Announcement File Integration (test)

**Kết quả:** Hoàn tất trên `tutorlink_test`, PostgreSQL 16.15. Bộ D04-09 đạt **3 tests / 75 assertions**; regression chung D04-07/08/09 đạt **9 tests / 254 assertions**. Pint đạt trên 6 file PHP được sửa.

## Đã triển khai

- Thêm `announcement_attachment` vào allow-list upload và kiểm tra `CompleteFile`; giữ pipeline private hiện có, giới hạn 5.000.000 byte và allow-list PDF/JPG/PNG/DOC/DOCX. Complete trả `clean` nhưng không tự khai báo đã antivirus-scan.
- Bảo vệ metadata và download của file đã gắn Announcement bằng scope hiện tại: Draft chỉ Tutor owner; Published Tutor owner hoặc Customer có membership `active`. Kiểm tra lại account, Program, Announcement, File và link dưới thứ tự khóa dùng chung với writer. Customer outsider, Admin chung, membership đã `cancelled`, cùng uploader không còn là Program owner đều không đọc/tải được.
- Metadata file chưa gắn vẫn cho uploader xem trạng thái `pending`. Download Announcement dùng authenticated stream, `private, no-store`, không trả storage key/URL; checksum trong response test khớp nội dung file.
- Generic `/files/{id}/links` cho Announcement vẫn trả 409. DELETE file còn link Draft/Published trả 409; PATCH `file_ids: []` chỉ tháo link và giữ nguyên bytes. Không tìm thấy job cleanup file riêng trong backend; đường xóa file hiện có từ chối mọi file còn liên kết.
- Gắn middleware API cho các file routes để response có request ID và kiểm actor active/revoked nhất quán.
- Đồng bộ M10-F01/F03/F04/F05, Files PRD Index và API Route Catalog với behavior D04-09 và ghi rõ bằng chứng mới chỉ ở test branch.

## Kiểm thử và dữ liệu

- Upload đúng purpose trả 201/pending; complete trả 200/clean; sai purpose và file quá 5.000.000 byte trả 422.
- Draft: owner xem metadata/tải được; member bị ẩn; generic link và DELETE bị chặn; tháo link giữ object bytes.
- Published: owner/member active tải được với SHA-256 đúng; outsider/Admin/uploader sai resource scope/membership đã `cancelled` bị 404; Program terminal vẫn cho member hiện tại đọc; DELETE trả 409.
- Published fixture được dựng trực tiếp trong transaction test vì endpoint publish thuộc D04-10. Mọi testcase rollback dữ liệu sau khi chạy.
- Preflight cho thấy test DB ban đầu thiếu migration nền `2026_10_28_200000_add_file_scan_evidence`, khiến API complete không ghi được các cột scan. Đã chạy riêng migration cộng thêm bốn cột nullable này trên `tutorlink_test` để sử dụng pipeline CompleteFile; không backfill và không tạo scan evidence. Sáu migration khác vẫn pending, không được chạy.
- Sau regression, row count giữ nguyên: 29 Files, 4 Announcements, 1 Announcement file link, 55 Progress records, 59 Fee records; audit link/outbox vẫn 0. D04 migration vẫn chạy đúng một lần. Chỉ PostgreSQL sequence tăng do các insert trong transaction đã rollback.

## Bằng chứng

- [D04-09 API transcript và checksum](announcement-file-tests.txt)
- [D04-07/08/09 regression](D04-07-09-regression.txt)
- [DB trước migration](database-before.txt) · [DB sau chạy](database-after.txt)
- [Migration preflight](migration-preflight.txt) · [Migration status sau](migration-after.txt)
- [Môi trường](environment.json)

Runtime database của dự án thật không được kết nối hoặc thay đổi trong bước này.
