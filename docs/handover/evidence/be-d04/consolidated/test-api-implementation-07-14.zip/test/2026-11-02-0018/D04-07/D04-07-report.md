# D04-07 — Progress API (test)

**Kết quả:** Hoàn tất trên `tutorlink_test`, PostgreSQL 16.15. Suite focused đạt **3 tests / 64 assertions**.

Đã đăng ký GET list, POST create và PATCH update. Owner ghi trên Program `active`/`paused`; member hiện tại chỉ đọc. PATCH kiểm `expected_version`, phân biệt omission với `note:null`, giữ nguyên `recorded_at`/`recorded_by`, tăng version và ghi `progress_record.update` với hash/độ dài note. PATCH no-op không đổi version, timestamp, audit hoặc outbox; stale version vẫn trả 409. Danh sách dùng `recorded_at DESC, id DESC`, mặc định 20 và tối đa 50.

Transcript xác nhận response 201/200/403/404/409/422, strict integer, state conflict, no-op, stale và tie-break ID. Sau rollback, DB còn 55 Progress, 0 audit `progress_record`, 0 outbox; D04 schema migration vẫn chạy đúng một lần. Các insert đã rollback có thể làm tăng sequence của PostgreSQL, không để lại row. Pint và `git diff --check` đạt.

**Bằng chứng:** [API transcript](progress-api-tests.txt), [DB sau chạy](database-after.txt), [môi trường](environment.json). Thao tác chỉ kết nối `tutorlink_test`.
