# D04-13 — Contract boundary matrix (test)

**Kết quả: đạt.** Chạy trên PostgreSQL 16.15, database riêng `tutorlink_test`. Bộ boundary mới đạt **3 tests / 144 assertions**; regression hành vi và schema D04-07..13 đạt **66 tests / 807 assertions**.

## Tiêu chí được xác nhận

- Áp dụng phân trang BR-26: mặc định 20, tối đa 50; `per_page=51` và `page=0` trả 422; trang sau cuối trả danh sách rỗng.
- Kiểm tra owner xem Draft Announcement, lọc theo trạng thái, lọc Fee kết hợp AND, tie-break thứ tự ổn định và query bị cấm trên Overview.
- JSON integer từ chối boolean, float và chuỗi; giới hạn số nguyên an toàn được giữ đúng. Unknown field/query trả validation envelope.
- Unicode dạng NFD được giữ nguyên; CRLF/CR đổi thành LF; title/reason được trim; body/note giữ whitespace có ý nghĩa. Omission và `null` tiếp tục có hành vi riêng.
- Fee dùng kỳ tháng theo timezone Program `Asia/Ho_Chi_Minh`; thời điểm `2026-10-31T17:00:00Z` thuộc tháng 11, thời điểm trước đó thuộc tháng 10.
- Overview không nhận query pagination; các response lỗi giữ `code`, `message`, `request_id`, `errors` theo envelope hiện hành.

## Regression và trạng thái dữ liệu

Regression API/schema từ D04-07 đến D04-13 đạt 66/66 tests, 807 assertions. Lớp migration-preflight một lần không nằm trong regression sau migration; migration-status được lưu cùng evidence D04-12/D04-11. Snapshot trước và sau bước này giống nhau: 29 Files, 4 Announcements, 1 file link, 55 Progress, 59 Fee, 3 Sessions version 1, 29 migration đã chạy, không còn Review fixture tạm. Các test tạo dữ liệu trong transaction và rollback.

## Evidence

- [Ma trận expected/actual đủ 16 route](case-matrix.md)
- [Request/response boundary transcript](contract-boundary-tests.txt)
- [Focused test log](contract-boundary-tests.txt) · [Regression D04-07..13](regression-d04-07-13.txt)
- [DB trước](database-before.txt) · [DB sau](database-after.txt) · [Migration status](migration-status.txt)
- [Environment manifest](environment.json) · [Source patch](source.patch) · [Patch checksum](source.patch.sha256)

Không kết nối hoặc thay đổi runtime database thực tế.
