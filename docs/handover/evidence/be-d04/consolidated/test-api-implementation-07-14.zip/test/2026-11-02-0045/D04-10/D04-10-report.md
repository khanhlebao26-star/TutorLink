# D04-10 — Publish Announcement nguyên tử (test)

**Kết quả:** Hoàn tất trên `tutorlink_test` (PostgreSQL 16.15). Acceptance D04-10 đạt **3 tests / 75 assertions**; regression D04-07 đến D04-10 đạt **12 tests / 329 assertions**. Pint, PHP syntax và `git diff --check` đều đạt.

## Đã triển khai

- Thêm `POST /api/v1/announcements/{announcement}/publish`; body chỉ nhận `expected_version`, bắt buộc UUID `Idempotency-Key`, chuẩn hóa key lowercase và hash theo `POST + canonical path + canonical JSON`.
- Writer dùng Program → Announcement → File → FileLink lock order. Sau khi chờ khóa, kiểm tra lại owner, Program state, version, Draft state và toàn bộ file hiện gắn; chỉ Active/Paused được publish.
- Cùng transaction cập nhật `published_at`/version, ghi `announcement.publish` với hash title/body và tập file ID, snapshot member customer active trừ owner, ghi outbox key `announcement:{id}:published` với payload duy nhất `deep_link`, rồi lưu response receipt hết hạn sau 30 ngày.
- Replay cùng actor/key/path/payload trả lại status/body cũ và không tăng side effect. Payload khác cùng key trả `idempotency_conflict`; key mới không publish lại; stale version và Program terminal bị chặn. Published PATCH và xóa file còn gắn bị chặn.

## Tiêu chí đã kiểm

- Publish thành công trả 200 và version +1; response giữ nguyên file allow-list. Audit chứa state/version/timestamp, SHA-256 nội dung và file IDs đã sort.
- Member active tại thời điểm publish là recipient; khi member được kích hoạt sau một publish, member đọc Published được nhưng không nhận notification hồi tố.
- Outbox không chứa title/body/tên file/checksum. Replay trả cùng response JSON; counts audit/outbox/receipt không tăng lần hai.
- PostgreSQL trigger test làm lỗi ngay khi insert Announcement outbox sau bước update/audit. API trả 500; Draft vẫn version 1, `published_at` null, không còn audit/outbox/receipt; trigger/function được gỡ trong `finally`.
- Các testcase rollback dữ liệu trong transaction. Sau regression, test DB giữ nguyên 29 Files, 4 Announcements, 1 Announcement file link, 55 Progress, 59 Fee; 0 publish audit/outbox/receipt. Có thể tăng sequence ID do insert trong transaction rollback.

## Bằng chứng

- [API publish/replay/stale/immutability/rollback](announcement-publish-tests.txt)
- [Regression D04-07 đến D04-10](regression-d04-07-10.txt)
- [DB trước bước này](database-before.txt) · [DB sau chạy](database-after.txt)
- [Migration status](migration-status.txt) · [Môi trường](environment.json)

Migration D04 vẫn chỉ chạy một lần; 6 migration nền khác vẫn Pending. Không kết nối hoặc thay đổi runtime database của dự án thật.
