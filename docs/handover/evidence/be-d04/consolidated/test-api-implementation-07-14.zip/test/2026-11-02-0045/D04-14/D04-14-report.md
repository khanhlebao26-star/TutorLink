# D04-14 — Idempotency and no-op verification (test)

**Kết quả: đạt.** Trên `tutorlink_test` (PostgreSQL 16.15), focused acceptance đạt **4 tests / 75 assertions**; regression D04-07..14 đạt **70 tests / 882 assertions**.

## Kết quả theo tiêu chí

- Fee create cùng actor/key/method/path và payload chuẩn hóa trả lại status **201** cùng snapshot ban đầu. Payload đảo thứ tự field và thêm `currency: VND` thay cho default vẫn replay đúng; UUID viết hoa được chuẩn hóa. Receipt lưu hash SHA-256 đã kiểm chứng, `expires_at=NULL`.
- Cùng key nhưng đổi body hoặc endpoint/path trả `409 idempotency_conflict`. Dùng key publish Announcement cho Fee cũng conflict do receipt scope chung theo actor/key.
- Replay Fee create sau khi Fee đã được sửa vẫn trả snapshot create version 1; DB giữ version 2. Replay không tăng audit/outbox/receipt.
- Publish Announcement lưu snapshot/status 200. Replay trả cùng snapshot sau khi Program chuyển `completed`; key mới bị `409 program_state_conflict`. Khi chuyển ownership, owner cũ nhận `404 program_not_found`, không nhận snapshot cũ.
- Fee PATCH cùng amount với version mới nhất trả `200` nhưng giữ nguyên version/updated_at/audit/outbox; key mới tạo đúng một receipt. Retry key đó replay snapshot và không thêm receipt; đổi reason cùng key trả conflict.
- Fee update với expected_version cũ vẫn trả `409 stale_version`, dù amount gửi lên trùng giá trị DB hiện tại.
- Progress và Draft không bảo đảm idempotency theo header: Progress retry dùng cùng key trả stale-version thay vì replay; Draft POST retry cùng key tạo hai Draft khác ID. Hai đường đều không tạo receipt.
- Các regression trước đó xác nhận Progress/Draft no-op không thay đổi timestamp/version/audit/outbox, Fee mark-paid no-op giữ metadata cũ và chỉ thêm receipt cho key mới, publish key bắt buộc, Fee key bắt buộc, rollback publish không để receipt lỗi.

## Dữ liệu và runtime

Tất cả test dùng transaction rồi rollback. Snapshot sau chạy vẫn có 29 Files, 4 Announcements, 1 Announcement file link, 55 Progress, 59 Fee, 3 Sessions version 1 và 29 migration đã chạy. Fee fixture sớm nhất được tạm giải phóng trong transaction để kiểm create thật; snapshot xác nhận hàng đó đã được rollback. PostgreSQL sequence có thể tiến sau insert tạm, nhưng không còn hàng test tạm trong bảng.

## Evidence

- [Focused API transcript và assertions](idempotency-api-tests.txt)
- [Regression D04-07..14](regression-d04-07-14.txt)
- [Hash vectors](hash-vectors.md)
- [DB trước](database-before.txt) · [DB sau](database-after.txt) · [Migration status](migration-status.txt)
- [Fixture rollback note](fixture-adjustment.txt)
- [Environment manifest](environment.json) · [Source patch](source.patch) · [Patch checksum](source.patch.sha256)

Không kết nối hoặc thay đổi runtime database của dự án thật.
