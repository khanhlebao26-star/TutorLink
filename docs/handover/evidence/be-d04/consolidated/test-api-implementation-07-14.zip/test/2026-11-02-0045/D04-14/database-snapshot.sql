BEGIN;
SELECT current_database() AS database,
       (SELECT count(*) FROM files) AS files,
       (SELECT count(*) FROM announcements) AS announcements,
       (SELECT count(*) FROM file_links WHERE resource_type = 'announcement') AS announcement_file_links,
       (SELECT count(*) FROM progress_records) AS progress_records,
       (SELECT count(*) FROM fee_records) AS fee_records,
       (SELECT count(*) FROM program_sessions) AS program_sessions,
       (SELECT count(*) FROM program_sessions WHERE version = 1) AS session_version_1,
       (SELECT count(*) FROM migrations) AS applied_migrations,
       (SELECT count(*) FROM fee_records WHERE program_id = 5 AND period_start = '2022-01-01') AS restored_earliest_fee_fixture;
SELECT status, count(*) FROM tasks WHERE program_id = 5 GROUP BY status ORDER BY status;
COMMIT;
