# D04-12 — Program Overview (test)

**Kết quả:** Hoàn tất trên `tutorlink_test` (PostgreSQL 16.15). Acceptance Overview đạt **4 tests / 62 assertions**; regression hành vi/schema D04-07..12 đạt **63 tests / 663 assertions**. Pint, PHP syntax, `git diff --check` và `graphify update .` đạt.

## Đã triển khai

- Đăng ký `GET /api/v1/programs/{program}/overview`, chỉ nhận query rỗng và trả envelope `{data: ...}`.
- Response chỉ gồm `next_session`, `task_counts`, `latest_progress`, `latest_announcement`, `capabilities`; ba resource summary dùng đúng resource allow-list hiện có.
- `next_session` lọc `scheduled` và `planned_starts_at > server now`, sắp tăng dần `(planned_starts_at,id)`. Task counts luôn có đủ năm status kể cả 0.
- Latest Progress sắp giảm dần `(recorded_at,id)`, không dùng `updated_at`; latest Announcement lọc Published trước rồi sắp giảm dần `(published_at,id)`, kể cả khi owner đọc.
- Capabilities theo quyền hiện hành: owner Active được tạo Session/Task/Fee/Announcement; owner Active hoặc Paused được ghi Progress; Customer member của Program Completed chỉ được tạo Review nếu chưa có Review. Các role/state còn lại false.
- Toàn bộ dữ liệu summary, scope và capability đọc trong transaction `REPEATABLE READ READ ONLY`.

## Tiêu chí đã kiểm

- Response có dữ liệu và rỗng: tie-break Session/Progress/Announcement, Session đúng mốc tương lai, Draft không lọt vào latest Announcement, Submitted không bị đếm thành Completed, đủ 5 Task status.
- Capability cho owner/member và Program Active/Paused/Completed/Cancelled; Customer Completed chuyển từ đủ điều kiện sang false khi đã có Review.
- Guest, account inactive, outsider/admin và query lạ trả đúng status/envelope.
- Test dùng connection PostgreSQL thứ hai đổi Program Active→Paused và Task todo→completed sau khi snapshot Overview đã mở. Response vẫn nhất quán với Active và counts ban đầu; connection kia được phục hồi về dữ liệu fixture ban đầu.
- DB sau test giữ 29 Files, 4 Announcements, 1 Announcement file link, 55 Progress, 59 Fee và 3 Sessions; năm Task status vẫn mỗi loại 1; không còn Review tạm thời.

## Session schema dependency

Preflight cho thấy cột `program_sessions.version` còn thiếu vì migration hỗ trợ Session đang Pending; khi đó resource trả version không hợp lệ. Trên `tutorlink_test` đã chạy riêng `2026_11_01_014629_add_version_and_terminal_replay_to_program_sessions`, một lần. Ba Session hiện có giữ nguyên và đều có version 1. Năm migration khác vẫn Pending; không chạy migration nền khác.

## Regression preflight

Một lượt glob ban đầu gồm cả `BeD04MigrationPreflightTest`, vốn chỉ hợp lệ trước khi migration D04 đã áp dụng. Bảy case trong class này thất bại đúng ở precondition “migration phải Pending”; log được giữ riêng. Bộ regression cuối chạy các D04 API, schema, route, shared-request và SQL-constraint tests, loại đúng class setup một lần này: 63 passed / 663 assertions.

## Bằng chứng

- [Focused API transcript](overview-api-tests.txt) · [regression D04-07..12](regression-d04-07-12.txt)
- [JSON populated owner](overview-populated-owner.json) · [populated member](overview-populated-member.json) · [empty Program](overview-empty.json)
- [Review eligibility](overview-review-eligible.json) · [repeatable snapshot result](overview-repeatable-snapshot.json)
- [DB before](database-before.txt) · [DB after](database-after.txt) · [migration preflight](migration-preflight-before.txt) · [migration applied](migration-apply.txt) · [migration status](migration-status.txt)
- [Environment manifest](environment.json) · [source patch](source.patch) · [patch checksum](source.patch.sha256)
- [Broad D04 run including one-time migration preflight](all-d04-including-migration-preflight.txt)

Không kết nối hoặc thay đổi runtime database của dự án thật.
