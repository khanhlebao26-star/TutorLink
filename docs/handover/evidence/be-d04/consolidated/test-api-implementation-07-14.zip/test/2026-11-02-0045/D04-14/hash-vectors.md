# D04-14 canonical hash vectors

The test asserts each receipt hash against `SHA-256(METHOD + LF + canonical_path + LF + canonical_JSON)`. JSON keys use canonical sorted order; UUID and idempotency key are excluded from the payload hash.

| Operation | Canonical input | Expected lowercase SHA-256 |
|---|---|---|
| Fee create with omitted default currency | `POST\n/api/v1/programs/5/fee-records\n{"amount_minor":32100,"currency":"VND","period":"2022-01"}` | `4080993c0b3723afdea23ca2bdd882a7cac0ec1f301dd4e6c35655b995ab547a` |
| Announcement publish, test route ID 418 | `POST\n/api/v1/announcements/418/publish\n{"expected_version":1}` | `332719dfaa600a3062070499fbcf725ea04c87fedd3113a987be34f2353eaed0` |

The Fee vector is asserted against the persisted receipt in the API test. The publish test asserts its persisted hash using that request's numeric Announcement ID. Reordered Fee JSON plus explicit default `VND` returned the original 201 snapshot, while a changed amount returned `409 idempotency_conflict`.
