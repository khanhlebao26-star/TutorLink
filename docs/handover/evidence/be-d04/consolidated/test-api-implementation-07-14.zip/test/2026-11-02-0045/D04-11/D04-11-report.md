# D04-11 — 7 API Fee (test)

**Kết quả:** Hoàn tất trên `tutorlink_test` (PostgreSQL 16.15). Acceptance Fee đạt **2 tests / 143 assertions**, schema contract đạt **13 tests / 20 assertions**, regression D04-07 đến D04-11 đạt **27 tests / 492 assertions**. Pint và kiểm tra định dạng thay đổi đạt.

## Đã triển khai

- Đăng ký 7 API: list, create, detail, PATCH amount, mark-paid, mark-unpaid và void.
- List áp dụng filter kỳ/trạng thái/payment mark, phân trang contract và thứ tự ổn định `(period_start DESC, id DESC)`. DTO chỉ trả field được phép, có disclaimer.
- Create giới hạn Program Active, kỳ từ tháng activation đến tháng hiện tại theo timezone Program, VND và integer amount; unique Program/kỳ vẫn giữ cả Fee đã void.
- Writer khóa Program trước Fee resource, kiểm tra lại state/version, giữ quy tắc sửa amount khi `declared` và chưa `marked_paid`, chuyển trạng thái thanh toán có reason, void không xóa lịch sử mark/kỳ/payment metadata.
- Mọi lệnh ghi nhận UUID idempotency key, canonical request hash và receipt bền `expires_at=NULL`; replay trả response đã lưu. No-op giữ version/audit/outbox, nhưng lệnh no-op có key mới vẫn lưu receipt riêng.
- Thay đổi thực sự tăng version, ghi audit và `fee_record_changed` outbox trong cùng transaction; event chỉ chứa deep link và kỳ, recipient Customer active. Không tích hợp payment gateway.
- Migration phụ thêm PostgreSQL CHECK `currency = 'VND'`. Trước migration có 59/59 currency là VND và 0 row sai; migration chạy một lần trên test DB.

## Tiêu chí đã kiểm

- Toàn bộ 7 route: quyền owner/customer, list/filter, response allow-list, period, pagination, amount/currency, state transition, free amount, duplicate period, immutable/terminal behavior.
- Chuỗi create→edit→paid→unpaid→void xác nhận version, metadata, audit/outbox và receipt; replay và no-op không nhân side effect.
- Sai key/hash, expected_version, role, Program state, period và currency bị từ chối theo contract. Schema test xác nhận metadata, CHECK và currency constraint.
- Test transaction rollback toàn bộ dữ liệu. Trước/sau giữ 29 Files, 4 Announcements, 1 Announcement file link, 55 Progress, 59 Fee; Fee audit/outbox/receipt đều 0 ngoài transaction.

## Bằng chứng

- [Fee API cases](fee-api-tests.txt)
- [Schema contract](schema-contract-tests.txt) · [currency migration](migration-apply.txt)
- [Regression D04-07 đến D04-11](regression-d04-07-11.txt)
- [DB trước migration](database-before.txt) · [DB sau kiểm thử](database-after.txt)
- [Migration status](migration-status.txt) · [Môi trường](environment.json)

DB có 28 migration Ran, trong đó schema D04 và currency constraint mỗi migration một lần; 6 migration nền khác vẫn Pending. Không kết nối hoặc thay đổi runtime database của dự án thật.
