# D04-17 — Outbox delivery and receipt retention (test)

**Kết quả: PASS** · 8 test / 157 assertions · `tutorlink_test` · PostgreSQL 16.15.

## Kết quả kiểm chứng

- D04 focused tests: **3 passed, 58 assertions**. Khi hai outbox event còn `available_at` trong tương lai, worker không tạo notification. Sau khi đến hạn, worker tạo đúng một notification cho Announcement và một cho Fee; gọi lại worker không tạo bản trùng. Recipient, `type`, `event_key` và payload khớp event snapshot.
- Committed-event worker regression: **1 passed, 5 assertions**. Worker xử lý event đã commit; lần gọi tiếp theo không tạo notification trùng.
- Announcement publish regression: **3 passed, 75 assertions**. Terminal replay/current-owner regression: **1 passed, 19 assertions**; snapshot replay hiện tại vẫn qua kiểm quyền.
- Fee retention: hai Fee receipt có `expires_at = NULL`, `created_at` lùi 31 ngày. Sau khi Fee bị void, Program completed và `outbox:purge` xóa hai audit log đã đủ kỳ, Fee và receipt vẫn còn. Owner replay nhận lại nguyên response snapshot `201`; không tạo Fee, audit hay outbox event mới.
- Announcement expiry: kiểm tra `expires_at = created_at + 30 ngày`. Khi key đã hết hạn, publish lại trả `409 stale_version`; Announcement giữ version 2, audit/outbox không tăng và receipt hết hạn được xóa an toàn.
- Cleanup preview báo 2 audit log đủ điều kiện; execute xóa đúng 2. Không xóa notification/outbox hoặc durable Fee receipt.
- Pint PASS cho controller và test. DB test được khôi phục từ checkpoint sau worker regression; snapshot trước/sau restore trùng khớp.

## Bằng chứng

- [Focused API, worker và cleanup transcript](d04-17-tests.txt)
- [Committed-event worker test](committed-worker-test.txt) · [Announcement publish regression](announcement-publish-regression.txt) · [terminal replay/current-owner regression](terminal-replay-regression.txt)
- [Database before](database-before.txt) · [database after restore](database-after.txt) · [snapshot query](database-snapshot.sql)
- [Migration status](migration-status.txt) · [PostgreSQL identity](postgres-identity.txt) · [environment](environment.json)
- [Pint output](pint.txt) · [test source](source-harness.php) · [updated Announcement controller](announcement-controller.php) · [source hashes](source-hashes.sha256)
- [Checkpoint hash](test-db-checkpoint.sha256) · [restore record](database-restore.txt)
