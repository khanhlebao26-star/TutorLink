\pset pager off
\pset format aligned
SELECT 'progress' AS evidence, id, program_id, version, value, note, updated_at
FROM progress_records WHERE id IN (100, 101) ORDER BY id;
SELECT id, status, owner_tutor_profile_id, customer_id
FROM programs WHERE id BETWEEN 5 AND 8 ORDER BY id;
SELECT resource_type, resource_id, action, count(*) AS audit_count
FROM audit_logs
WHERE (resource_type = 'progress_record' AND resource_id = 100)
   OR (resource_type = 'announcement' AND resource_id = 445)
   OR (resource_type = 'fee_record' AND resource_id = 125)
GROUP BY resource_type, resource_id, action
ORDER BY resource_type, resource_id, action;
SELECT id, program_id, CASE WHEN published_at IS NULL THEN 'draft' ELSE 'published' END AS state, version, title, published_at
FROM announcements WHERE id = 445;
SELECT resource_type, resource_id, user_id, type, count(*) AS event_count,
       count(*) FILTER (WHERE processed_at IS NOT NULL) AS processed_count,
       count(*) FILTER (WHERE failed_at IS NOT NULL) AS failed_count
FROM notification_outbox
WHERE (resource_type = 'announcement' AND resource_id = 445)
   OR (resource_type = 'fee_record' AND resource_id = 125)
GROUP BY resource_type, resource_id, user_id, type
ORDER BY resource_type, resource_id, user_id, type;
SELECT canonical_path, method, response_status, count(*) AS receipt_count,
       count(*) FILTER (WHERE expires_at IS NULL) AS durable_receipts,
       count(*) FILTER (WHERE expires_at IS NOT NULL) AS expiring_receipts
FROM idempotency_receipts
WHERE actor_id = 61
  AND (canonical_path LIKE '%announcements/445/publish'
       OR canonical_path LIKE '%fee-records/125%'
       OR canonical_path LIKE '%programs/5/fee-records')
GROUP BY canonical_path, method, response_status
ORDER BY canonical_path, method, response_status;
SELECT f.id, f.owner_id, f.purpose, f.scan_status, f.object_key,
       l.resource_type, l.resource_id, l.purpose AS link_purpose
FROM files f LEFT JOIN file_links l ON l.file_id = f.id
WHERE f.id IN (167, 168)
ORDER BY f.id;
SELECT program_id, user_id, status
FROM program_members WHERE program_id = 5 AND user_id = 68;
