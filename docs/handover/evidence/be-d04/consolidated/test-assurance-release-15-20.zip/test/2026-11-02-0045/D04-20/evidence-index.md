# BE-D04 test evidence index

Run: `2026-11-02-0045` · Environment: isolated `tutorlink_test` / PostgreSQL 16.15.

The test checklist and per-step completion criteria are in [BE-D04-plan.md](../../../../../BE-D04-plan.md). D04-01 through D04-19 are marked complete there. Each link below opens the step report; the plan points to its logs, snapshots and source evidence.

| Step | Evidence |
|---|---|
| D04-01 Baseline | [D04-01 report](../../D04-01-report.md) |
| D04-02 Test DB isolation | [D04-02 report](../../2026-11-01-2234/D04-02/D04-02-report.md) |
| D04-03 Fixtures | [D04-03 report](../../2026-11-01-2252/D04-03/D04-03-report.md) |
| D04-04 Contract tests | [D04-04 report](../../2026-11-01-2316/D04-04/D04-04-report.md) |
| D04-05 Migration/backfill | [D04-05 report](../../2026-11-01-2330/D04-05/D04-05-report.md) |
| D04-06 Shared validation/transaction base | [D04-06 report](../../2026-11-02-000000/D04-06/D04-06-report.md) |
| D04-07 Progress | [D04-07 report](../../2026-11-02-0018/D04-07/D04-07-report.md) |
| D04-08 Draft Announcement | [D04-08 report](../../2026-11-02-0025/D04-08/D04-08-report.md) |
| D04-09 Announcement file flow | [D04-09 report](../../2026-11-02-0033/D04-09/D04-09-report.md) |
| D04-10 Publish | [D04-10 report](../D04-10/D04-10-report.md) |
| D04-11 Fee | [D04-11 report](../D04-11/D04-11-report.md) |
| D04-12 Overview | [D04-12 report](../D04-12/D04-12-report.md) |
| D04-13 Payload/route contract | [D04-13 report](../D04-13/D04-13-report.md) |
| D04-14 Idempotency/no-op | [D04-14 report](../D04-14/D04-14-report.md) |
| D04-15 PostgreSQL races | [D04-15 report](../D04-15/D04-15-report.md) |
| D04-16 Rollback/fault injection | [D04-16 report](../D04-16/D04-16-report.md) |
| D04-17 Outbox/retention | [D04-17 report](../D04-17/D04-17-report.md) |
| D04-18 Full regression/OpenAPI/docs | [D04-18 report](../D04-18/D04-18-report.md) |
| D04-19 Real HTTP evidence | [D04-19 report](../D04-19/D04-19-report.md), [HTTP route coverage](../D04-19/http-route-coverage.md), [96-case transcript](../D04-19/http-transcript.jsonl), [audit projections](../D04-19/audit-projections.txt), [post-restore snapshot](../D04-19/database-after-restored.txt) |

## Shared release identities

- [Release manifest](release-manifest.json)
- [Test summary](test-summary.md)
- [Apply/restore runbook](runbook.md)
- [Backend build context file hashes](backend-build-context.sha256) · [build context tree SHA-256](backend-build-context-tree.sha256)
- [Final graph update](graph-update.txt)
- [Contract](../../../../../BE-D04-contract.md) · generated [OpenAPI](../../../../../../api/openapi.json)

Only API evidence is claimed for D04-19. No UI screenshot is used to claim Workspace UI acceptance. Actual-environment evidence is not part of this test index.
