# D04-15 — PostgreSQL concurrency races (test)

**Result: PASS.** The real-connection race suite passed with 893 assertions. It exercised 111 races across 37 cases, with three repetitions per ordering. Each race observed the independent worker blocked on a PostgreSQL `Lock`; all 111 workers exited with code 0. No deadlock or retry exhaustion occurred.

The suite covered Fee create replay/unique-month/shared-key conflicts; same-key Announcement publish with one audit, outbox event, and receipt; Fee create versus pause/complete/cancel; Progress, Draft, publish, and existing Fee writers versus pause; Fee edit/mark-paid/void, Progress, and Announcement publish versus terminal transitions; competing same-version Fee mutations; Draft edit versus publish; and Announcement file replace/delete versus publish. The log records both HTTP results and final resource checks for each run.

Paused-state expectations follow BR-10 and M05-F06: Progress, Announcement Draft/publish, and edits to existing Fee records remain allowed while Paused; a new Fee is rejected. The two create-versus-pause orderings returned the contract outcomes (`201` then `200`, or `200` then `409 program_state_conflict`).

After the run, `tutorlink_test` was restored from its pre-run dump. The before/after SQL snapshots match exactly: 29 files, 4 announcements, 1 Announcement file link, 55 Progress records, 59 Fee records, 3 sessions, 29 applied migrations, and unchanged active-fixture task counts. The actual project database was not connected.

Evidence: [race transcript](concurrency-races.txt), [source harness](race-harness.php), [source checksum](source-harness.sha256), [formatter check](pint.txt), [test environment](environment.json), [database before](database-before.txt), [database after restore](database-after.txt), [migration status](migration-status.txt), [PostgreSQL identity](postgres-identity.txt), [restore record](database-restore.txt), and [backup checksum](test-database-backup.sha256).
