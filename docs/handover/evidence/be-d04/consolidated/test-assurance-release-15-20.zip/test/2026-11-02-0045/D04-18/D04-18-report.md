# D04-18 — Regression, OpenAPI và đồng bộ tài liệu

**Kết quả: PASS — test branch, 02/11/2026.** Mọi kiểm tra chạy với PostgreSQL service `test-db`; database đích là `tutorlink_test`. Không dùng database service `db` của dự án.

## Kiểm tra

- D04 feature regression: 77 tests / 1.077 assertions, PASS.
- PostgreSQL race probes: 1 test / 893 assertions, PASS; các race lặp lại với khóa thật và không để trạng thái test tồn tại sau restore.
- Migration preflight trên clone legacy `tutorlink_phase2_test`: 7 tests / 27 assertions, PASS; ambiguous Fee status, fractional/wrong-scope Progress, invalid Announcement và Fee period đều bị chặn trước thay đổi schema. Clone đã được xóa.
- Regression còn lại toàn backend trên `tutorlink_test`: 627 tests / 4.545 assertions, PASS.
- Tổng riêng các nhóm trên: 712 tests / 6.542 assertions; không có failure, error hoặc skipped.
- Restore: full suite làm sạch fixture test do RefreshDatabase. Test DB đã được drop/recreate và phục hồi từ checkpoint; snapshot sau phục hồi trùng baseline, gồm 29 migrations và hai D04 migrations ở batch 11/13. Xem [restore record](database-restore-final.txt), [baseline](database-final-before.txt), [sau phục hồi](database-after-full-restored.txt).

## OpenAPI

- Scramble export chứa 105 operations: baseline 89 + 16 D04; route-set diff có 16 additions, 0 removals. `verify-openapi-routes.php` PASS trên 105 operations.
- Tất cả 16 D04 method/path có success schema, error envelope, `X-Request-ID` cho từng response status; sáu write cần key có header `Idempotency-Key` required. Schema check có 0 lỗi.
- Redocly 2.60.0: baseline và generated đều exit 0; 59 warning mỗi bản, cùng fingerprint, 0 warning mới và 0 warning được giải quyết. Không có schema/reference error.
- `docs/api/openapi.json` được copy từ Scramble export (không sửa JSON thủ công), SHA-256 `c8cb008537c474ccd53c2ba234565957e7a93be89d28267b1939136099103cf2`.

## Đồng bộ tài liệu

Cập nhật API Route Catalog (16 route D04 chuyển sang “Đã đăng ký” theo quy ước xuất hiện trong OpenAPI), API README, docs README, Database Design (metadata/FK/CHECK/index Fee cuối cùng và receipt retention), M09-F05 (action/payload audit), M06-F01/M07-F04/M08-F01/M08-F02 và WF05. Các tài liệu ghi rõ test DB/branch không chứng nhận runtime thực tế. WF05/Announcement PRD nêu kiểm tra file complete, gắn/tháo FileLink nguyên tử, Published bất biến và kiểm quyền đọc/tải; không nhầm technical file check với antivirus. Pagination/filter/order áp dụng BR-26.

Graphify update hoàn tất (4.849 nodes, 11.053 edges, 340 communities); output ghi rõ SQL extractor chưa cài nên 6 file SQL không đóng góp symbol, còn migration behavior đã được kiểm bằng PostgreSQL tests. Xem [graph update](graph-update.txt).

## Evidence

- Tests: [D04](d04-focused-tests-clean.txt), [race](d04-concurrency-race.txt), [migration preflight](migration-preflight-tests.txt), [full backend](full-backend-regression.txt).
- OpenAPI: [generated spec](openapi.json), [route parity](openapi-route-parity-final.txt), [route counts](route-counts.txt), [added](routes-added.txt), [removed](routes-removed.txt), [operation matrix](openapi-d04-operation-matrix-final.tsv), [response headers](openapi-d04-response-headers.tsv), [schema validation](openapi-schema-validation.txt), [lint comparison](openapi-lint-comparison.md).
