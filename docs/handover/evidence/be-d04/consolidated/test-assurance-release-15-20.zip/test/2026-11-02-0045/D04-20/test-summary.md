# D04-20 — Test release summary

**Gate: PASS_TEST_RELEASE_CANDIDATE** · Run `2026-11-02-0045` · Actual environment was not changed.

## Acceptance

- D04-01 through D04-19 are complete in [BE-D04-plan.md](../../../../../BE-D04-plan.md); the complete links are in the [evidence index](evidence-index.md).
- D04-18: 712 backend tests / 6,542 assertions; zero failures, errors or skipped tests. PostgreSQL race, rollback/fault, outbox delivery and retention cases are linked from D04-15/16/17.
- OpenAPI: 105 operations, comprising 89 baseline plus all 16 D04 routes; no baseline route removed. Scramble route parity/schema checks passed; Redocly exited 0 with 59 unchanged warning fingerprints and no new/resolved warnings.
- Final `graphify update .` exited 0 and rebuilt 4,901 nodes / 11,162 edges / 337 communities. It recorded unavailable SQL extraction (`tree_sitter_sql` missing), unsupported file types and community labels not refreshed; see [graph update output](graph-update.txt).
- D04-19: 96/96 real HTTP cases matched expected status over Sanctum session/CSRF, including all 16 D04 operations, Active/Paused/Completed/Cancelled lifecycle, auth, no-op/stale/replay, file permissions and downloads, Fee transitions and Overview. Request/response bodies, `X-Request-ID`, actual Idempotency-Key UUIDs and file checksums are in the transcript; cookies, session/XSRF tokens and login passwords are not recorded.
- Audit before/after projections and scoped DB effects match the HTTP resources. Fee receipts have durable null expiry; the Announcement publish receipt has an expiry; outbox recipient/event counts are recorded. Worker exactly-once and retention behavior are separately evidenced by D04-17.

## Exact tested package

- Git base: branch `be-d04`, commit `135efcc8ec5c4c73cff8d58cabc62a17772234bf`. The worktree is dirty, so use the recorded 359-file backend build-context SHA-256 and local image ID in [release-manifest.json](release-manifest.json) to identify the exact tested source/image.
- Test backend image: `tutorlink-h01-backend-test:local`, image ID `sha256:95916de4c50255c4694cfd2dafa20878a2939f09fe46272101fe113f13a371ad`. A source file hash inside the image matches the current working tree. This is a local test image, not a registry push.
- Contract SHA-256: `1eff7f60414be02eabafdc4701409acd11e251e876dd3af513725fe45334e703`. OpenAPI SHA-256: `c8cb008537c474ccd53c2ba234565957e7a93be89d28267b1939136099103cf2`.

## Test database state and remaining actual preflight

- The HTTP runtime needed five supporting migrations that were pending on the test checkpoint. They were applied to `tutorlink_test` for the HTTP run. Both D04 migrations were already recorded as ran. After evidence capture, `tutorlink_test` was restored from the checkpoint; its aggregate snapshot matches D04-18 byte-for-byte, the five supporting migrations are pending again, and the test API container is stopped.
- D04-21 must read the target's migration status and compare the source/image identity before applying anything. The five test-pending migrations are evidence for comparison, not an instruction to apply them blindly to another database.
- Initial harness/config/fixture failures were corrected and retained in [D04-19 diagnostic notes](../D04-19/diagnostic-notes.md). The accepted result is the final lifecycle-complete 96/96 transcript.

## Handoff

The test release gate is complete. The exact source/build identity and apply/recovery steps are in the [release manifest](release-manifest.json) and [runbook](runbook.md). D04-21 through D04-25 remain unstarted. No UI screenshot is used to claim UI acceptance; D04-19 evidence is API-only as allowed by the plan.
