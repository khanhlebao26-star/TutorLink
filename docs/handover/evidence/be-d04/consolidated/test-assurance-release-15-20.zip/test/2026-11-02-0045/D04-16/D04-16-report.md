# D04-16 — Rollback fault injection (test)

**Kết quả: PASS** · `tutorlink_test` · 4 test / 137 assertions · 8 fault case.

Fault được chèn sau khi một phần ghi đã chạy: Announcement file link và unlink; Fee audit, outbox và receipt; Announcement publish audit, outbox và receipt. Cả 8 request lỗi trả HTTP 500. State của resource/version, file links, audit, outbox và receipt giữ nguyên như trước request; không phát notification từ transaction rollback.

Sau khi gỡ fault hook, cả 8 retry thành công. Các publish/mutation chỉ được ghi một lần. Hook được dọn trước retry; kiểm tra PostgreSQL sau lượt test còn **0 trigger và 0 function** mang tiền tố `d04_16_`.

Snapshot bảng/fixture và migration trước-sau trùng khớp; test chạy trên PostgreSQL 16.15, database `tutorlink_test`. Pint PASS. Không có thay đổi dữ liệu tồn tại sau lượt test.

## Bằng chứng

- [API failure/retry transcript](fault-injection-api-tests.txt)
- [Database before](database-before.txt) · [database after](database-after.txt) · [snapshot query](database-snapshot.sql)
- [Fault cleanup query](fault-cleanup-query.sql) · [cleanup result](fault-cleanup.txt)
- [Migration status](migration-status.txt) · [PostgreSQL identity](postgres-identity.txt)
- [Test source](source-harness.php) · [source SHA-256](source-harness.sha256) · [Pint result](pint.txt)
- [Environment](environment.json) · [DB isolation/restore record](database-restore.txt)
