BEGIN;
SELECT current_database() AS database, current_user AS database_user, version() AS postgresql;
SELECT 'files' AS table_name, count(*)::bigint AS rows FROM files
UNION ALL SELECT 'announcements', count(*) FROM announcements
UNION ALL SELECT 'announcement_file_links', count(*) FROM file_links WHERE resource_type = 'announcement'
UNION ALL SELECT 'progress_records', count(*) FROM progress_records
UNION ALL SELECT 'fee_records', count(*) FROM fee_records
UNION ALL SELECT 'program_sessions', count(*) FROM program_sessions
UNION ALL SELECT 'notification_outbox', count(*) FROM notification_outbox
UNION ALL SELECT 'notifications', count(*) FROM notifications
UNION ALL SELECT 'idempotency_receipts', count(*) FROM idempotency_receipts
UNION ALL SELECT 'audit_logs', count(*) FROM audit_logs
UNION ALL SELECT 'migrations', count(*) FROM migrations
ORDER BY table_name;
SELECT 'program_status' AS group_name, status AS label, count(*)::bigint AS rows
FROM programs GROUP BY status ORDER BY status;
SELECT 'outbox_state' AS group_name,
       CASE WHEN processed_at IS NOT NULL THEN 'processed'
            WHEN resolved_at IS NOT NULL THEN 'resolved'
            WHEN failed_at IS NOT NULL THEN 'failed'
            ELSE 'pending' END AS label,
       count(*)::bigint AS rows
FROM notification_outbox GROUP BY 2 ORDER BY 2;
SELECT 'fee_receipt_expiry' AS group_name,
       CASE WHEN expires_at IS NULL THEN 'durable_null_expiry' ELSE 'time_limited' END AS label,
       count(*)::bigint AS rows
FROM idempotency_receipts
WHERE canonical_path LIKE '%/fee-records%'
GROUP BY 2 ORDER BY 2;
SELECT migration, batch FROM migrations WHERE migration LIKE '%d04%' ORDER BY migration;
COMMIT;
