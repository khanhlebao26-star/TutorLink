BEGIN;
DELETE FROM fee_records
WHERE id = 59
  AND program_id = 5
  AND period_start = DATE '2026-11-01'
RETURNING id, program_id, period_start, status;
COMMIT;
