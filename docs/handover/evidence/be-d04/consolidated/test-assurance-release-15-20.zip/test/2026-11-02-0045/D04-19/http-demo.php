<?php

declare(strict_types=1);

use GuzzleHttp\Client;
use GuzzleHttp\Cookie\CookieJar;
use GuzzleHttp\Psr7\Utils;

require '/var/www/html/vendor/autoload.php';

final class D04Session
{
    public function __construct(
        public readonly string $label,
        public readonly CookieJar $cookies,
        public readonly Client $client,
    ) {}

    public function xsrf(): string
    {
        foreach ($this->cookies->toArray() as $cookie) {
            if ($cookie['Name'] === 'XSRF-TOKEN') {
                return rawurldecode($cookie['Value']);
            }
        }

        throw new RuntimeException("{$this->label}: no XSRF-TOKEN cookie");
    }
}

final class D04HttpEvidence
{
    private Client $client;
    private array $records = [];
    private array $sessions = [];
    private string $logPath = '/d04-evidence/http-transcript.jsonl';
    private string $summaryPath = '/d04-evidence/http-summary.json';

    public function __construct()
    {
        $this->client = new Client(['base_uri' => 'http://127.0.0.1:8084', 'timeout' => 45]);
        file_put_contents($this->logPath, '');
    }

    private function check(bool $condition, string $message): void
    {
        if (! $condition) {
            throw new RuntimeException($message);
        }
    }

    private function canonical(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (! array_is_list($value)) {
            ksort($value);
        }
        foreach ($value as $key => $child) {
            $value[$key] = $this->canonical($child);
        }
        return $value;
    }

    private function session(string $label, string $email, int $loginStatus = 200): ?D04Session
    {
        $jar = new CookieJar();
        $session = new D04Session($label, $jar, $this->client);
        $this->request($session, 'GET', '/sanctum/csrf-cookie', 'csrf-'.$label, 204);
        $login = $this->request($session, 'POST', '/api/v1/auth/login', 'login-'.$label, $loginStatus, [
            'email' => $email,
            'password' => 'password',
        ]);

        if ($loginStatus === 200) {
            $this->sessions[$label] = $session;
            return $session;
        }

        return null;
    }

    private function request(
        ?D04Session $session,
        string $method,
        string $path,
        string $case,
        int $expected,
        ?array $json = null,
        array $headers = [],
        ?array $multipart = null,
        bool $csrf = true,
        ?string $idempotencyLabel = null,
        bool $download = false,
    ): array {
        $requestHeaders = [
            'Accept' => 'application/json',
            'Origin' => 'http://localhost:3000',
            'Referer' => 'http://localhost:3000/',
            'X-Requested-With' => 'XMLHttpRequest',
        ] + $headers;
        if ($session !== null && $csrf && ! in_array(strtoupper($method), ['GET', 'HEAD', 'OPTIONS'], true)) {
            $requestHeaders['X-XSRF-TOKEN'] = $session->xsrf();
        }
        $multipartSummary = null;
        if ($multipart !== null) {
            $multipartSummary = array_map(static function (array $part): array {
                if (isset($part['contents']) && is_resource($part['contents'])) {
                    $position = ftell($part['contents']);
                    $bytes = stream_get_contents($part['contents']);
                    if ($position !== false) {
                        fseek($part['contents'], $position);
                    }
                    return [
                        'name' => $part['name'] ?? null,
                        'filename' => $part['filename'] ?? null,
                        'sha256' => hash('sha256', $bytes),
                        'bytes' => strlen($bytes),
                    ];
                }
                return ['name' => $part['name'] ?? null, 'value' => $part['contents'] ?? null];
            }, $multipart);
        }
        $options = [
            'headers' => $requestHeaders,
            'http_errors' => false,
        ];
        if ($session !== null) {
            $options['cookies'] = $session->cookies;
        }
        if ($json !== null) {
            $options['json'] = $json;
        }
        if ($multipart !== null) {
            $options['multipart'] = $multipart;
        }

        $response = $this->client->request($method, $path, $options);
        $status = $response->getStatusCode();
        $body = (string) $response->getBody();
        $contentType = $response->getHeaderLine('Content-Type');
        $decoded = str_contains($contentType, 'json') ? json_decode($body, true) : null;
        $entry = [
            'case' => $case,
            'method' => strtoupper($method),
            'path' => $path,
            'expected_status' => $expected,
            'status' => $status,
            'actor' => $session?->label ?? 'anonymous',
            'session_cookie_sent' => $session !== null,
            'csrf_header_sent' => isset($requestHeaders['X-XSRF-TOKEN']),
            'idempotency_key_label' => $idempotencyLabel,
            'idempotency_key' => $requestHeaders['Idempotency-Key'] ?? null,
            'response_headers' => array_filter([
                'x-request-id' => $response->getHeaderLine('X-Request-ID') ?: null,
                'content-type' => $contentType ?: null,
                'cache-control' => $response->getHeaderLine('Cache-Control') ?: null,
                'content-disposition' => $response->getHeaderLine('Content-Disposition') ?: null,
                'retry-after' => $response->getHeaderLine('Retry-After') ?: null,
            ]),
        ];
        if ($json !== null) {
            $requestJson = $json;
            if (str_starts_with($case, 'login-') && array_key_exists('password', $requestJson)) {
                $requestJson['password'] = '[REDACTED]';
            }
            $entry['request_json'] = $requestJson;
        }
        if ($multipart !== null) {
            $entry['request_multipart'] = $multipartSummary;
        }
        if ($download) {
            $entry['response_download'] = ['bytes' => strlen($body), 'sha256' => hash('sha256', $body)];
            $target = '/d04-evidence/download-'.$case.'.pdf';
            file_put_contents($target, $body);
            $entry['download_evidence_path'] = basename($target);
        } elseif ($decoded !== null) {
            $entry['response_json'] = $decoded;
        } elseif ($body !== '') {
            $entry['response_text_sha256'] = hash('sha256', $body);
            $entry['response_text_bytes'] = strlen($body);
        }

        file_put_contents($this->logPath, json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR)."\n", FILE_APPEND);
        $this->records[] = $entry;
        $this->check($status === $expected, "{$case}: expected HTTP {$expected}, got {$status}; see http-transcript.jsonl");

        return ['status' => $status, 'body' => $decoded, 'raw' => $body, 'entry' => $entry];
    }

    private function write(
        D04Session $session,
        string $method,
        string $path,
        string $case,
        int $expected,
        array $body,
        ?string $keyLabel = null,
        ?string $keyValue = null,
    ): array {
        $headers = [];
        if ($keyValue !== null) {
            $headers['Idempotency-Key'] = $keyValue;
        }
        $result = $this->request($session, $method, $path, $case, $expected, $body, $headers, idempotencyLabel: $keyLabel);
        return $result;
    }

    private function upload(D04Session $owner, string $case, string $filename): int
    {
        $path = '/d04-evidence/'.$filename;
        $part = ['name' => 'file', 'contents' => Utils::tryFopen($path, 'r'), 'filename' => $filename, 'headers' => ['Content-Type' => 'application/pdf']];
        $response = $this->request($owner, 'POST', '/api/v1/files', $case.'-upload', 201, multipart: [$part, ['name' => 'purpose', 'contents' => 'announcement_attachment']]);
        return (int) ($response['body']['data']['id'] ?? throw new RuntimeException("{$case}: upload id missing"));
    }

    private function data(array $response): array
    {
        return $response['body']['data'] ?? throw new RuntimeException('Expected response data envelope.');
    }

    public function run(): void
    {
        $ids = json_decode(file_get_contents('/d04-evidence/fixture-ids.json'), true, flags: JSON_THROW_ON_ERROR);
        $ownerId = (int) $ids['owner_id'];
        $memberId = (int) $ids['member_id'];
        $activeProgram = (int) $ids['active_program_id'];
        $pausedProgram = (int) $ids['paused_program_id'];
        $this->check(getenv('DB_HOST') === 'test-db' && getenv('DB_DATABASE') === 'tutorlink_test' && getenv('DB_PORT') === '5432', 'Refusing HTTP run outside the isolated test database.');

        $pdf = "%PDF-1.4\n1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n2 0 obj << /Type /Pages /Kids [] /Count 0 >> endobj\ntrailer << /Root 1 0 R >>\n%%EOF\n";
        foreach (['http-attachment-a.pdf', 'http-attachment-b.pdf'] as $filename) {
            file_put_contents('/d04-evidence/'.$filename, $pdf);
        }

        $this->request(null, 'GET', '/api/v1/programs/'.$activeProgram.'/overview', 'E08-anonymous-overview', 401);
        $owner = $this->session('owner', 'be-d04-owner@tutorlink.test');
        $member = $this->session('member', 'be-d04-late-member@tutorlink.test');
        $outsider = $this->session('outsider', 'be-d04-outsider@tutorlink.test');
        $otherTutor = $this->session('other-tutor', 'be-d04-other-tutor@tutorlink.test');
        $this->session('inactive', 'be-d04-inactive@tutorlink.test', 403);
        $this->check($owner !== null && $member !== null && $outsider !== null && $otherTutor !== null, 'Expected active seeded sessions.');

        $this->request($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/progress-records', 'E08-csrf-required', 419, ['metric_name' => 'progress_percent', 'value' => 10], csrf: false);
        $this->request($member, 'POST', '/api/v1/programs/'.$activeProgram.'/progress-records', 'E08-member-write-forbidden', 403, ['metric_name' => 'progress_percent', 'value' => 10]);
        $this->request($outsider, 'GET', '/api/v1/programs/'.$activeProgram.'/overview', 'E08-out-of-scope-404', 404);

        $this->request($owner, 'GET', '/api/v1/programs/'.$activeProgram.'/overview', 'E07-owner-overview-before', 200);
        $this->request($owner, 'GET', '/api/v1/programs/'.$activeProgram.'/progress-records', 'E01-progress-list-before', 200);
        $progress = $this->data($this->request($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/progress-records', 'E01-progress-create', 201, [
            'metric_name' => 'progress_percent', 'value' => 42, 'note' => 'D04-19 HTTP evidence',
        ]));
        $progressId = (int) $progress['id'];
        $this->check($progress['version'] === 1 && $progress['value'] === 42, 'Progress create fields/version mismatch.');
        $this->request($owner, 'GET', '/api/v1/programs/'.$activeProgram.'/progress-records', 'E01-progress-list-after-create', 200);
        $progress = $this->data($this->request($owner, 'PATCH', '/api/v1/progress-records/'.$progressId, 'E01-progress-patch-preserve-note', 200, ['expected_version' => 1, 'value' => 50]));
        $this->check($progress['note'] === 'D04-19 HTTP evidence' && $progress['version'] === 2, 'Progress PATCH omission did not preserve note or increment version.');
        $progress = $this->data($this->request($owner, 'PATCH', '/api/v1/progress-records/'.$progressId, 'E01-progress-patch-null-note', 200, ['expected_version' => 2, 'note' => null]));
        $this->check($progress['note'] === null && $progress['version'] === 3, 'Progress PATCH null did not clear note.');
        $noop = $this->data($this->request($owner, 'PATCH', '/api/v1/progress-records/'.$progressId, 'E09-progress-noop', 200, ['expected_version' => 3, 'value' => 50]));
        $this->check($noop['version'] === 3, 'Progress same-value PATCH changed version.');
        $this->request($owner, 'PATCH', '/api/v1/progress-records/'.$progressId, 'E09-progress-stale', 409, ['expected_version' => 2, 'value' => 51]);
        $this->request($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/progress-records', 'E01-progress-invalid-value', 422, ['metric_name' => 'progress_percent', 'value' => 101]);
        $this->request($owner, 'GET', '/api/v1/programs/'.$activeProgram.'/progress-records?per_page=51', 'E01-progress-page-limit', 422);

        $this->request($owner, 'GET', '/api/v1/programs/'.$activeProgram.'/announcements?state=draft', 'E02-owner-draft-list', 200);
        $this->request($owner, 'GET', '/api/v1/programs/'.$activeProgram.'/announcements?state=all', 'E02-owner-all-list', 200);
        $draft = $this->data($this->request($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/announcements', 'E02-draft-create', 201, ['title' => 'D04-19 HTTP announcement', 'body' => 'Initial draft body.']));
        $announcementId = (int) $draft['id'];
        $draft = $this->data($this->request($owner, 'GET', '/api/v1/announcements/'.$announcementId, 'E02-draft-detail-owner', 200));
        $draft = $this->data($this->request($owner, 'PATCH', '/api/v1/announcements/'.$announcementId, 'E02-draft-patch', 200, ['expected_version' => 1, 'body' => 'Updated draft body.']));
        $this->check($draft['title'] === 'D04-19 HTTP announcement' && $draft['version'] === 2, 'Announcement omission should preserve title.');
        $this->request($member, 'GET', '/api/v1/announcements/'.$announcementId, 'E02-member-draft-hidden', 404);
        $this->request($member, 'GET', '/api/v1/programs/'.$activeProgram.'/announcements?state=draft', 'E02-member-draft-filter-forbidden', 403);
        $this->request($member, 'GET', '/api/v1/programs/'.$activeProgram.'/announcements?state=all', 'E02-member-all-filter-forbidden', 403);

        $fileA = $this->upload($owner, 'E03-announcement-file-a', 'http-attachment-a.pdf');
        $fileAData = $this->data($this->request($owner, 'POST', '/api/v1/files/'.$fileA.'/complete', 'E03-file-a-complete', 200, []));
        $this->check($fileAData['complete'] === true && $fileAData['antivirus_scanned'] === false, 'Complete must be technical-only.');
        $this->request($owner, 'GET', '/api/v1/files/'.$fileA, 'E03-file-metadata-owner', 200);
        $this->request($owner, 'POST', '/api/v1/files/'.$fileA.'/links', 'E03-generic-announcement-link-rejected', 409, ['resource_type' => 'announcement', 'resource_id' => $announcementId]);
        foreach ([['wrong-owner', (int) $ids['file_ids']['d04-wrong_owner.pdf']], ['wrong-purpose', (int) $ids['file_ids']['d04-wrong_purpose.pdf']], ['pending', (int) $ids['file_ids']['d04-pending.pdf']]] as [$label, $badFile]) {
            $this->request($owner, 'PATCH', '/api/v1/announcements/'.$announcementId, 'E03-'.$label.'-attachment-rejected', 422, ['expected_version' => 2, 'file_ids' => [$badFile]]);
        }
        $draft = $this->data($this->request($owner, 'PATCH', '/api/v1/announcements/'.$announcementId, 'E03-attach-file-a', 200, ['expected_version' => 2, 'file_ids' => [$fileA]]));
        $this->check(count($draft['files']) === 1 && (int) $draft['files'][0]['id'] === $fileA, 'Draft attachment missing.');
        $this->request($owner, 'GET', '/api/v1/files/'.$fileA.'/download', 'E03-owner-download-draft-file', 200, download: true);
        $this->request($member, 'GET', '/api/v1/files/'.$fileA.'/download', 'E03-member-cannot-read-draft-file', 404);
        $this->request($owner, 'DELETE', '/api/v1/files/'.$fileA, 'E03-delete-linked-file-conflict', 409);
        $noopDraft = $this->data($this->request($owner, 'PATCH', '/api/v1/announcements/'.$announcementId, 'E09-draft-file-noop', 200, ['expected_version' => 3, 'file_ids' => [$fileA]]));
        $this->check($noopDraft['version'] === 3, 'Announcement file no-op incremented version.');
        $this->request($owner, 'PATCH', '/api/v1/announcements/'.$announcementId, 'E09-draft-stale', 409, ['expected_version' => 2, 'title' => 'Stale update']);
        $fileB = $this->upload($owner, 'E03-announcement-file-b', 'http-attachment-b.pdf');
        $this->request($owner, 'POST', '/api/v1/files/'.$fileB.'/complete', 'E03-file-b-complete', 200, []);
        $draft = $this->data($this->request($owner, 'PATCH', '/api/v1/announcements/'.$announcementId, 'E03-replace-file-b', 200, ['expected_version' => 3, 'file_ids' => [$fileB]]));
        $this->check((int) $draft['files'][0]['id'] === $fileB && $draft['version'] === 4, 'File replacement mismatch.');
        $draft = $this->data($this->request($owner, 'PATCH', '/api/v1/announcements/'.$announcementId, 'E03-detach-files', 200, ['expected_version' => 4, 'file_ids' => []]));
        $this->check($draft['files'] === [] && $draft['version'] === 5, 'File detach mismatch.');
        $this->request($owner, 'GET', '/api/v1/files/'.$fileA.'/download', 'E03-owner-download-detached-file', 200, download: true);
        $draft = $this->data($this->request($owner, 'PATCH', '/api/v1/announcements/'.$announcementId, 'E03-reattach-file-a', 200, ['expected_version' => 5, 'file_ids' => [$fileA]]));

        $publishKey = 'd04-19-publish-main';
        $publishUuid = 'a1489683-d780-4fa1-a862-644951c6e814';
        $published = $this->write($owner, 'POST', '/api/v1/announcements/'.$announcementId.'/publish', 'E04-publish', 200, ['expected_version' => 6], $publishKey, $publishUuid);
        $publishedData = $this->data($published);
        $this->check($publishedData['state'] === 'published' && $publishedData['version'] === 7, 'Publish did not transition/version.');
        $replay = $this->write($owner, 'POST', '/api/v1/announcements/'.$announcementId.'/publish', 'E09-publish-replay', 200, ['expected_version' => 6], $publishKey, $publishUuid);
        $this->check($this->canonical($published['body']) === $this->canonical($replay['body']), 'Publish replay snapshot differs.');
        $this->write($owner, 'POST', '/api/v1/announcements/'.$announcementId.'/publish', 'E09-publish-key-payload-conflict', 409, ['expected_version' => 99], 'd04-19-publish-main', $publishUuid);
        $this->write($owner, 'POST', '/api/v1/announcements/'.$announcementId.'/publish', 'E04-publish-second-key-conflict', 409, ['expected_version' => 7], 'd04-19-publish-again', 'd539d344-0e23-4a82-80da-21409fb745cb');
        $this->request($owner, 'PATCH', '/api/v1/announcements/'.$announcementId, 'E04-published-edit-conflict', 409, ['expected_version' => 7, 'title' => 'Must remain immutable']);
        $this->request($member, 'GET', '/api/v1/programs/'.$activeProgram.'/announcements', 'E04-member-published-list', 200);
        $this->request($member, 'GET', '/api/v1/announcements/'.$announcementId, 'E04-member-published-detail', 200);
        $this->request($member, 'GET', '/api/v1/files/'.$fileA, 'E03-member-published-file-metadata', 200);
        $downloadA = $this->request($member, 'GET', '/api/v1/files/'.$fileA.'/download', 'E03-member-published-file-download', 200, download: true);
        $this->check($downloadA['entry']['response_download']['sha256'] === hash('sha256', $pdf), 'Published file bytes checksum mismatch.');
        $this->request($owner, 'GET', '/api/v1/files/'.$fileA.'/download', 'E03-owner-published-file-download', 200, download: true);

        $newFeeKey = 'd04-19-fee-create';
        $newFeeUuid = 'a2489683-d780-4fa1-a862-644951c6e814';
        $fee = $this->data($this->write($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/fee-records', 'E05-fee-create', 201, ['period' => '2026-11', 'amount_minor' => 500000, 'currency' => 'VND'], $newFeeKey, $newFeeUuid));
        $feeId = (int) $fee['id'];
        $replayFee = $this->data($this->write($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/fee-records', 'E09-fee-create-replay', 201, ['period' => '2026-11', 'amount_minor' => 500000, 'currency' => 'VND'], $newFeeKey, $newFeeUuid));
        $this->check($this->canonical($fee) === $this->canonical($replayFee), 'Fee replay snapshot differs.');
        $this->write($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/fee-records', 'E09-fee-key-payload-conflict', 409, ['period' => '2026-11', 'amount_minor' => 500001, 'currency' => 'VND'], $newFeeKey, $newFeeUuid);
        $this->write($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/fee-records', 'E06-fee-duplicate-month-after-replay', 409, ['period' => '2026-11', 'amount_minor' => 500000, 'currency' => 'VND'], 'd04-19-fee-duplicate', 'b1489683-d780-4fa1-a862-644951c6e814');
        $this->write($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/fee-records', 'E06-fee-invalid-month', 422, ['period' => '2026-13', 'amount_minor' => 1, 'currency' => 'VND'], 'd04-19-fee-bad-month', 'c1489683-d780-4fa1-a862-644951c6e814');
        $this->write($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/fee-records', 'E06-fee-invalid-currency', 422, ['period' => '2026-10', 'amount_minor' => 1, 'currency' => 'USD'], 'd04-19-fee-bad-currency', 'd1489683-d780-4fa1-a862-644951c6e814');
        $this->write($owner, 'POST', '/api/v1/programs/'.$activeProgram.'/fee-records', 'E06-fee-invalid-amount', 422, ['period' => '2026-10', 'amount_minor' => 0.5, 'currency' => 'VND'], 'd04-19-fee-bad-amount', 'e1489683-d780-4fa1-a862-644951c6e814');
        $this->write($owner, 'POST', '/api/v1/programs/'.$pausedProgram.'/fee-records', 'E06-paused-program-fee-conflict', 409, ['period' => '2026-11', 'amount_minor' => 1, 'currency' => 'VND'], 'd04-19-paused-fee', 'f1489683-d780-4fa1-a862-644951c6e814');
        $this->request($owner, 'GET', '/api/v1/programs/'.$activeProgram.'/fee-records?period=2026-11&status=declared&tutor_payment_mark=unmarked', 'E05-fee-list-filters', 200);
        $this->request($owner, 'GET', '/api/v1/fee-records/'.$feeId, 'E05-fee-detail-owner', 200);
        $fee = $this->data($this->write($owner, 'PATCH', '/api/v1/fee-records/'.$feeId, 'E09-fee-same-value-noop', 200, ['expected_version' => 1, 'amount_minor' => 500000, 'reason' => 'no change'], 'd04-19-fee-noop', '01489683-d780-4fa1-a862-644951c6e814'));
        $this->check($fee['version'] === 1, 'Fee no-op changed version.');
        $fee = $this->data($this->write($owner, 'PATCH', '/api/v1/fee-records/'.$feeId, 'E05-fee-update', 200, ['expected_version' => 1, 'amount_minor' => 600000, 'reason' => 'HTTP evidence adjustment'], 'd04-19-fee-update', '11489683-d780-4fa1-a862-644951c6e814'));
        $fee = $this->data($this->write($owner, 'POST', '/api/v1/fee-records/'.$feeId.'/mark-paid', 'E05-fee-mark-paid', 200, ['expected_version' => 2], 'd04-19-fee-paid', '21489683-d780-4fa1-a862-644951c6e814'));
        $this->check($fee['version'] === 3 && $fee['tutor_payment_mark'] === 'marked_paid', 'Fee paid transition failed.');
        $noopPaid = $this->data($this->write($owner, 'POST', '/api/v1/fee-records/'.$feeId.'/mark-paid', 'E09-fee-mark-paid-noop', 200, ['expected_version' => 3], 'd04-19-fee-paid-noop', '31489683-d780-4fa1-a862-644951c6e814'));
        $this->check($noopPaid['version'] === 3, 'Fee mark-paid no-op changed version.');
        $fee = $this->data($this->write($owner, 'POST', '/api/v1/fee-records/'.$feeId.'/mark-unpaid', 'E05-fee-mark-unpaid', 200, ['expected_version' => 3, 'reason' => 'Correction for demo'], 'd04-19-fee-unpaid', '41489683-d780-4fa1-a862-644951c6e814'));
        $fee = $this->data($this->write($owner, 'POST', '/api/v1/fee-records/'.$feeId.'/void', 'E05-fee-void', 200, ['expected_version' => 4, 'reason' => 'Demo declared in error'], 'd04-19-fee-void', '51489683-d780-4fa1-a862-644951c6e814'));
        $this->check($fee['status'] === 'voided' && $fee['version'] === 5 && $fee['tutor_payment_mark'] === 'marked_unpaid', 'Fee void fields/version mismatch.');
        $this->write($owner, 'POST', '/api/v1/fee-records/'.$feeId.'/mark-paid', 'E06-void-fee-mark-conflict', 409, ['expected_version' => 5], 'd04-19-void-mark', '61489683-d780-4fa1-a862-644951c6e814');
        $this->request($owner, 'GET', '/api/v1/fee-records/'.$feeId, 'E05-fee-detail-voided-owner', 200);
        $memberFeeList = $this->request($member, 'GET', '/api/v1/programs/'.$activeProgram.'/fee-records?period=2026-11', 'E05-member-fee-list', 200);
        $memberFee = $this->request($member, 'GET', '/api/v1/fee-records/'.$feeId, 'E05-member-fee-detail', 200);
        $this->check(($memberFee['body']['data']['disclaimer'] ?? null) === 'Do Tutor khai báo, không phải bằng chứng thanh toán.', 'Customer Fee disclaimer missing.');

        $this->request($owner, 'POST', '/api/v1/fee-records/'.(int) $ids['zero_fee_id'].'/mark-paid', 'E06-zero-fee-mark-paid-conflict', 409, ['expected_version' => 1], ['Idempotency-Key' => '71489683-d780-4fa1-a862-644951c6e814'], csrf: true, idempotencyLabel: 'd04-19-zero-fee-paid');
        $this->request($owner, 'GET', '/api/v1/programs/'.$activeProgram.'/overview', 'E07-owner-overview-after', 200);
        $memberOverview = $this->request($member, 'GET', '/api/v1/programs/'.$activeProgram.'/overview', 'E07-member-overview-after', 200);
        $this->check(isset($memberOverview['body']['data']['task_counts']['todo'], $memberOverview['body']['data']['task_counts']['cancelled']), 'Overview is missing task status counts.');

        // Exercise lifecycle capabilities over HTTP for each Program status.
        $pausedOverview = $this->data($this->request($owner, 'GET', '/api/v1/programs/'.$pausedProgram.'/overview', 'E08-paused-overview-capabilities', 200));
        $this->check($pausedOverview['capabilities']['can_record_progress'] === true && $pausedOverview['capabilities']['can_create_fee_record'] === false && $pausedOverview['capabilities']['can_create_announcement'] === false, 'Paused Program capabilities mismatch.');
        $pausedProgress = $this->data($this->request($owner, 'POST', '/api/v1/programs/'.$pausedProgram.'/progress-records', 'E08-paused-progress-allowed', 201, ['metric_name' => 'progress_percent', 'value' => 11, 'note' => 'Paused lifecycle HTTP evidence']));
        $completedOverview = $this->data($this->request($otherTutor, 'GET', '/api/v1/programs/7/overview', 'E08-completed-overview-capabilities', 200));
        $this->check($completedOverview['capabilities']['can_record_progress'] === false && $completedOverview['capabilities']['can_create_fee_record'] === false && $completedOverview['capabilities']['can_create_announcement'] === false, 'Completed Program capabilities mismatch.');
        $this->request($otherTutor, 'POST', '/api/v1/programs/7/progress-records', 'E08-completed-progress-conflict', 409, ['metric_name' => 'progress_percent', 'value' => 12]);
        $this->request($otherTutor, 'POST', '/api/v1/programs/7/announcements', 'E08-completed-announcement-conflict', 409, ['title' => 'Terminal Program', 'body' => 'This request must not create a draft.']);
        $this->request($otherTutor, 'POST', '/api/v1/programs/7/fee-records', 'E08-completed-fee-conflict', 409, ['period' => '2026-11', 'amount_minor' => 1, 'currency' => 'VND'], ['Idempotency-Key' => '81489683-d780-4fa1-a862-644951c6e814'], csrf: true, idempotencyLabel: 'd04-19-completed-fee');
        $cancelledOverview = $this->data($this->request($otherTutor, 'GET', '/api/v1/programs/8/overview', 'E08-cancelled-overview-capabilities', 200));
        $this->check($cancelledOverview['capabilities']['can_record_progress'] === false && $cancelledOverview['capabilities']['can_create_fee_record'] === false && $cancelledOverview['capabilities']['can_create_announcement'] === false, 'Cancelled Program capabilities mismatch.');
        $this->request($otherTutor, 'POST', '/api/v1/programs/8/progress-records', 'E08-cancelled-progress-conflict', 409, ['metric_name' => 'progress_percent', 'value' => 13]);
        $this->request($otherTutor, 'POST', '/api/v1/programs/8/announcements', 'E08-cancelled-announcement-conflict', 409, ['title' => 'Cancelled Program', 'body' => 'This request must not create a draft.']);
        $this->request($otherTutor, 'POST', '/api/v1/programs/8/fee-records', 'E08-cancelled-fee-conflict', 409, ['period' => '2026-11', 'amount_minor' => 1, 'currency' => 'VND'], ['Idempotency-Key' => '91489683-d780-4fa1-a862-644951c6e814'], csrf: true, idempotencyLabel: 'd04-19-cancelled-fee');

        // Revoke only the synthetic member created for this isolated test after successful access was captured.
        $app = require '/var/www/html/bootstrap/app.php';
        $kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
        $kernel->bootstrap();
        $this->check(config('database.connections.pgsql.database') === 'tutorlink_test', 'Refusing membership revocation outside tutorlink_test.');
        $membership = Illuminate\Support\Facades\DB::table('program_members')->where('program_id', $activeProgram)->where('user_id', $memberId)->first();
        $this->check($membership !== null, 'Synthetic membership row not found.');
        Illuminate\Support\Facades\DB::table('program_members')->where('program_id', $activeProgram)->where('user_id', $memberId)->update(['status' => 'cancelled', 'updated_at' => now()]);
        file_put_contents('/d04-evidence/membership-revocation.json', json_encode(['database' => config('database.connections.pgsql.database'), 'program_id' => $activeProgram, 'user_id' => $memberId, 'previous_status' => $membership->status, 'new_status' => 'cancelled'], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
        $this->request($member, 'GET', '/api/v1/announcements/'.$announcementId, 'E03-member-after-membership-revoked', 404);
        $this->request($member, 'GET', '/api/v1/files/'.$fileA.'/download', 'E03-file-after-membership-revoked', 404);

        $summary = [
            'environment' => 'test only: tutorlink_test via backend-test HTTP session',
            'actor_ids' => ['owner' => $ownerId, 'other_tutor' => (int) $ids['other_tutor_id'], 'member' => $memberId, 'outsider' => (int) $ids['outsider_id']],
            'program_id' => $activeProgram,
            'progress_id' => $progressId,
            'paused_program_progress_id' => (int) $pausedProgress['id'],
            'announcement_id' => $announcementId,
            'announcement_file_ids' => [$fileA, $fileB],
            'fee_id' => $feeId,
            'cases' => count($this->records),
            'all_expected_statuses_met' => true,
            'publish_replay_snapshot_equal' => true,
            'fee_replay_snapshot_equal' => true,
            'download_sha256' => hash('sha256', $pdf),
            'records_by_status' => array_count_values(array_map(static fn (array $r): int => $r['status'], $this->records)),
        ];
        file_put_contents($this->summaryPath, json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
        echo json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)."\n";
    }
}

(new D04HttpEvidence())->run();
