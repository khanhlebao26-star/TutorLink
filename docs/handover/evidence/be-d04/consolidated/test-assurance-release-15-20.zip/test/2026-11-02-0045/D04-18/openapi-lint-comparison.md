# OpenAPI lint comparison

- Linter: Redocly CLI 2.60.0 with repository `.redocly.yaml`.
- Baseline: `openapi-baseline.json`, 89 operations, exit 0, 59 warnings.
- Generated: `docs/api/openapi.json`, 105 operations, exit 0, 59 warnings.
- Warning fingerprint comparison (rule + JSON pointer): 59 unchanged; 0 new; 0 resolved.
- No schema or `$ref` errors. All 16 D04 operations have a success response schema and the common error envelope for each declared error status; `X-Request-ID` is present on every declared response. Required `Idempotency-Key` appears on exactly six operations: Announcement publish and the five Fee writes.

Full logs: [baseline](openapi-lint-baseline.txt), [generated](openapi-lint-generated.txt), [schema/response check](openapi-schema-validation.txt), [route parity](openapi-route-parity-final.txt).
