# D04-19 — HTTP session evidence (test)

**Kết quả: PASS** · 96/96 HTTP cases đúng status mong đợi · `tutorlink_test` · PostgreSQL 16.15.

## Cách chạy

- Ma trận được gọi qua HTTP thật từ PHP client trong `backend-test` tới server nội bộ `127.0.0.1:8084`, có Sanctum session, cookie jar riêng từng actor và CSRF header cho mutation. Server nhận cấu hình test riêng (`DB_HOST=test-db`, `DB_DATABASE=tutorlink_test`, `APP_DEBUG=false`). Transcript giữ JSON, `X-Request-ID`, UUID Idempotency-Key và status; không lưu cookie/session/XSRF; password login được redacted.
- Dùng synthetic owner/member/outsider/inactive và Program 5/6. Resource HTTP: Progress 100, Announcement 445, Fee 125, files 167/168. Không dùng môi trường thực tế.
- Test DB checkpoint trước bước này: `/tmp/tutorlink_test_pre_d04_19.dump`, SHA-256 `27566c4473b61003ce3a6c105bc08696e2ed7988a3932ec0d4ff7e80e01bb0a4`.

## Kết quả ma trận

- Đủ **16/16 operation D04**; danh sách method/path và từng case ở [HTTP route coverage](http-route-coverage.md), body/status/header đầy đủ ở [HTTP transcript](http-transcript.jsonl).
- **E01 Progress:** create 201, list 200, PATCH giữ note khi bỏ field, PATCH `null` xóa note, same-value trả version hiện tại, stale 409, value ngoài miền và `per_page=51` trả 422. [Audit projection rows](audit-projections.txt) ghi `before`/`after` có value/version và note length/hash, không lưu nội dung note; có hai audit cho hai lần đổi dữ liệu, không có audit cho no-op.
- **E02 Announcement Draft:** owner list/detail/create/PATCH đạt; Customer đọc Draft 404 và lọc `draft`/`all` 403. PATCH bỏ `title` giữ nguyên title.
- **E03 File:** multipart upload 201 → complete 200 → metadata/download; gắn, thay, tháo và gắn lại file Announcement qua PATCH; tải file Draft chỉ owner được phép. Generic link trả 409; file sai owner/purpose hoặc chưa complete trả 422; xóa file đang gắn trả 409. Member đọc/tải được sau publish; khi membership bị thu hồi, detail và download đều 404. File tải 142 byte, SHA-256 `93e31154c364805a3ef8c904bc257f5ef77600c31b67d392704cd6e1e9cd0657`.
- **E04 Publish:** publish 200, state `published`, version 7; replay cùng UUID trả cùng JSON values, chỉ khác thứ tự key object; key/payload mismatch, publish lần nữa bằng key mới và sửa Published trả 409. DB có một `announcement.publish` audit, một receipt có TTL và đúng một outbox event gửi tới member 68.
- **E05 Fee:** đủ 7 operation list/create/detail/PATCH/mark-paid/mark-unpaid/void. Chuỗi trạng thái create 201 → update 200/version 2 → paid 200/version 3 → unpaid 200/version 4 → void 200/version 5; Customer response có disclaimer. Void giữ dấu `marked_unpaid`.
- **E06–E09:** duplicate kỳ, Program paused và đánh dấu Paid cho Fee zero trả 409; tháng/currency/amount sai trả 422. Fee replay giữ snapshot; same-value PATCH và mark-paid no-op trả 200 nhưng giữ version/timestamp, không thêm audit/outbox; mỗi write mới có receipt riêng. Stale update trả 409. Receipt Fee có `expires_at=NULL`; publish receipt có expiry.
- **E07–E08:** Overview owner/member 200 với đủ năm task counts. Active Program cho phép Progress; Paused Program giữ `can_record_progress=true` và Progress create 201 nhưng chặn Fee/Announcement; Completed và Cancelled đều trả Overview 200 với capability ghi false, đồng thời chặn Progress/Fee/Announcement write bằng 409. Anonymous 401; thiếu CSRF 419; member mutation 403; outsider sai scope 404; inactive login 403.
- **E10/E11:** Race, rollback/fault, worker exactly-once và cleanup/retention dùng bộ test chuyên biệt đã PASS tại [D04-15](../D04-15/D04-15-report.md), [D04-16](../D04-16/D04-16-report.md) và [D04-17](../D04-17/D04-17-report.md). HTTP pass này không thay các kiểm tra đó. Scoped DB có một Announcement và năm Fee outbox event cho recipient 68; worker chưa chạy trong HTTP demo.

## Evidence và khôi phục

- [Scoped audit/outbox/receipt/file/membership rows](scoped-db-checks.txt) và [audit before/after projections](audit-projections.txt) đối chiếu trực tiếp với ID synthetic ở trên; lần lượt dùng [scoped query](scoped-db-checks.sql) và [audit query](audit-projections.sql).
- [HTTP summary](http-summary.json), [route-to-case index](http-route-coverage.md), [harness](http-demo.php), [fixture IDs](fixture-ids.json), and downloaded PDFs: [Draft owner](download-E03-owner-download-draft-file.pdf), [detached owner](download-E03-owner-download-detached-file.pdf), [Published member](download-E03-member-published-file-download.pdf), [Published owner](download-E03-owner-published-file-download.pdf).
- Các lỗi runtime/fixture ban đầu và cách xử lý được giữ ở [diagnostic notes](diagnostic-notes.md), cùng các transcript chẩn đoán. Chỉ transcript cuối trong `http-transcript.jsonl` được tính là lượt nghiệm thu 96/96.
- Trước khi đóng D04-19, test DB được phục hồi từ checkpoint nói trên; [database-after-restored.txt](database-after-restored.txt) khớp byte-for-byte với D04-18, và [migration-status-after-restore.txt](migration-status-after-restore.txt) cùng [restore record](database-restore-record.txt) ghi trạng thái sau restore. Container HTTP test được dừng; PostgreSQL test service vẫn tách biệt. Không có lệnh nào nhắm tới service/database thực tế.
