# D04-19 HTTP route coverage

- Total HTTP cases: 96; all matched expected status.
- D04 API operations observed: 16/16. Supporting Auth/Sanctum/File calls are also in the transcript.
- Request cookies and XSRF values are not captured; login password is redacted; Idempotency-Key UUIDs and X-Request-ID response headers are retained.

| Operation | HTTP cases and actual statuses |
|---|---|
| `GET /api/v1/announcements/{announcement}` | E02-draft-detail-owner → 200, E02-member-draft-hidden → 404, E04-member-published-detail → 200, E03-member-after-membership-revoked → 404 |
| `GET /api/v1/fee-records/{feeRecord}` | E05-fee-detail-owner → 200, E05-fee-detail-voided-owner → 200, E05-member-fee-detail → 200 |
| `GET /api/v1/programs/{program}/announcements` | E02-owner-draft-list → 200, E02-owner-all-list → 200, E02-member-draft-filter-forbidden → 403, E02-member-all-filter-forbidden → 403, E04-member-published-list → 200 |
| `GET /api/v1/programs/{program}/fee-records` | E05-fee-list-filters → 200, E05-member-fee-list → 200 |
| `GET /api/v1/programs/{program}/overview` | E08-anonymous-overview → 401, E08-out-of-scope-404 → 404, E07-owner-overview-before → 200, E07-owner-overview-after → 200, E07-member-overview-after → 200, E08-paused-overview-capabilities → 200, E08-completed-overview-capabilities → 200, E08-cancelled-overview-capabilities → 200 |
| `GET /api/v1/programs/{program}/progress-records` | E01-progress-list-before → 200, E01-progress-list-after-create → 200, E01-progress-page-limit → 422 |
| `PATCH /api/v1/announcements/{announcement}` | E02-draft-patch → 200, E03-wrong-owner-attachment-rejected → 422, E03-wrong-purpose-attachment-rejected → 422, E03-pending-attachment-rejected → 422, E03-attach-file-a → 200, E09-draft-file-noop → 200, E09-draft-stale → 409, E03-replace-file-b → 200, E03-detach-files → 200, E03-reattach-file-a → 200, E04-published-edit-conflict → 409 |
| `PATCH /api/v1/fee-records/{feeRecord}` | E09-fee-same-value-noop → 200, E05-fee-update → 200 |
| `PATCH /api/v1/progress-records/{progressRecord}` | E01-progress-patch-preserve-note → 200, E01-progress-patch-null-note → 200, E09-progress-noop → 200, E09-progress-stale → 409 |
| `POST /api/v1/announcements/{announcement}/publish` | E04-publish → 200, E09-publish-replay → 200, E09-publish-key-payload-conflict → 409, E04-publish-second-key-conflict → 409 |
| `POST /api/v1/fee-records/{feeRecord}/mark-paid` | E05-fee-mark-paid → 200, E09-fee-mark-paid-noop → 200, E06-void-fee-mark-conflict → 409, E06-zero-fee-mark-paid-conflict → 409 |
| `POST /api/v1/fee-records/{feeRecord}/mark-unpaid` | E05-fee-mark-unpaid → 200 |
| `POST /api/v1/fee-records/{feeRecord}/void` | E05-fee-void → 200 |
| `POST /api/v1/programs/{program}/announcements` | E02-draft-create → 201, E08-completed-announcement-conflict → 409, E08-cancelled-announcement-conflict → 409 |
| `POST /api/v1/programs/{program}/fee-records` | E05-fee-create → 201, E09-fee-create-replay → 201, E09-fee-key-payload-conflict → 409, E06-fee-duplicate-month-after-replay → 409, E06-fee-invalid-month → 422, E06-fee-invalid-currency → 422, E06-fee-invalid-amount → 422, E06-paused-program-fee-conflict → 409, E08-completed-fee-conflict → 409, E08-cancelled-fee-conflict → 409 |
| `POST /api/v1/programs/{program}/progress-records` | E08-csrf-required → 419, E08-member-write-forbidden → 403, E01-progress-create → 201, E01-progress-invalid-value → 422, E08-paused-progress-allowed → 201, E08-completed-progress-conflict → 409, E08-cancelled-progress-conflict → 409 |

Full request/response JSONL: [`http-transcript.jsonl`](http-transcript.jsonl).
