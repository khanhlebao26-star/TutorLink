SELECT 'd04_16_triggers' AS hook_type, count(*) AS remaining
FROM pg_trigger
WHERE NOT tgisinternal AND tgname LIKE 'd04_16_%'
UNION ALL
SELECT 'd04_16_functions' AS hook_type, count(*) AS remaining
FROM pg_proc
WHERE proname LIKE 'd04_16_%';
