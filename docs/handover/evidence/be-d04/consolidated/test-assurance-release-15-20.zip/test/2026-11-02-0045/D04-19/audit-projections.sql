\pset pager off
SELECT resource_type, resource_id, action, before, after, reason, request_id
FROM audit_logs
WHERE (resource_type = 'progress_record' AND resource_id = 100)
   OR (resource_type = 'announcement' AND resource_id = 445)
   OR (resource_type = 'fee_record' AND resource_id = 125)
ORDER BY id;
