BEGIN;

ALTER TABLE fee_records
    DROP CONSTRAINT IF EXISTS fee_records_d04_amount_check,
    DROP CONSTRAINT IF EXISTS fee_records_d04_currency_check,
    DROP CONSTRAINT IF EXISTS fee_records_d04_last_change_reason_check,
    DROP CONSTRAINT IF EXISTS fee_records_d04_payment_mark_check,
    DROP CONSTRAINT IF EXISTS fee_records_d04_payment_metadata_check,
    DROP CONSTRAINT IF EXISTS fee_records_d04_period_check,
    DROP CONSTRAINT IF EXISTS fee_records_d04_status_check,
    DROP CONSTRAINT IF EXISTS fee_records_d04_version_check,
    DROP CONSTRAINT IF EXISTS fee_records_d04_void_metadata_check,
    DROP CONSTRAINT IF EXISTS fee_records_d04_zero_amount_check;

ALTER TABLE fee_records RENAME COLUMN status TO declared_status;
ALTER TABLE fee_records
    DROP COLUMN tutor_payment_mark,
    DROP COLUMN version,
    DROP COLUMN voided_at,
    DROP COLUMN voided_by,
    DROP COLUMN void_reason,
    DROP COLUMN payment_marked_at,
    DROP COLUMN payment_marked_by,
    DROP COLUMN payment_mark_reason,
    DROP COLUMN last_change_reason;

ALTER TABLE fee_records
    ADD CONSTRAINT fee_records_amount_check CHECK (amount_minor >= 0),
    ADD CONSTRAINT fee_records_period_check CHECK (period_end >= period_start),
    ADD CONSTRAINT fee_records_status_check
        CHECK (declared_status IN ('declared', 'confirmed', 'cancelled'));

ALTER TABLE progress_records
    DROP CONSTRAINT IF EXISTS progress_records_d04_metric_value_check,
    DROP CONSTRAINT IF EXISTS progress_records_d04_version_check;
DROP INDEX IF EXISTS progress_records_program_recorded_id_d04_index;
ALTER TABLE progress_records DROP COLUMN version;
ALTER TABLE progress_records ALTER COLUMN value TYPE numeric USING value::numeric;

ALTER TABLE announcements
    DROP CONSTRAINT IF EXISTS announcements_d04_version_check;
DROP INDEX IF EXISTS announcements_program_published_id_d04_index;
DROP INDEX IF EXISTS announcements_program_draft_created_id_d04_index;
ALTER TABLE announcements DROP COLUMN version;

DELETE FROM migrations
WHERE migration = '2026_11_01_233000_add_be_d04_workspace_schema';

COMMIT;
