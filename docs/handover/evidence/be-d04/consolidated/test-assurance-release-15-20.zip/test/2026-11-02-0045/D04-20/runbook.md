# BE-D04 apply and recovery runbook

This runbook is prepared from the isolated test rehearsal. D04-21 through D04-24 are the actual-environment steps and have **not** been run as part of this test package.

## 1. Verify the release candidate

1. Read [release-manifest.json](release-manifest.json) and [evidence-index.md](evidence-index.md).
2. Verify the source/build-context SHA-256 and tested image ID against the manifest. The image is local to the current Docker engine; do not substitute a different image or rebuild after this verification without issuing a new manifest and rerunning D04-18/19.
3. Confirm the working tree/source package being applied has the same backend context hash. The recorded Git commit alone is not sufficient because the tested tree contains uncommitted work.
4. Confirm the contract and generated OpenAPI checksums. Do not hand-edit `docs/api/openapi.json`.

## 2. D04-21 preflight and backup

1. Record the target URL, application/backend image ID, database identity/version, storage, worker, scheduler, queue and current health.
2. Read migration status and compare it with the target's actual schema. The test checkpoint had five supporting migrations pending while both D04 migrations were already recorded as ran. Those five were applied to `tutorlink_test` only to exercise the current session/file runtime, then the database was restored. This list is evidence for comparison; do not run it blindly on another database.
3. Inventory Fee periods/status/payment marks, Announcement state/file links, Progress versions, audit/outbox/receipt counts, file metadata, and constraints using read-only queries.
4. Produce a target-only database backup and checksum outside the repository. Verify it can be read before allowing writers or continuing to D04-22.
5. Stop if the target migration list, schema, or backend build identity differs from the reviewed deployment plan. Update the plan and test the difference first.

## 3. D04-22 apply

1. Deploy the exact source/image identity in the manifest with its separately managed production configuration and secrets.
2. Apply only migrations proven pending by D04-21, in repository order. Capture each command and exit code. Do not edit schema/data manually or use the test `.env`/Compose credentials.
3. Confirm the D04 tables, foreign keys, unique/check constraints, Fee void/payment metadata, and receipt retention policy. Confirm the 16 D04 routes and existing routes remain registered.
4. Start/restart the application, notification worker and scheduler on the same verified release. Confirm health before D04-23.

## 4. D04-23 smoke and D04-24 observation

1. Use dedicated synthetic acceptance actors/Program/Fee records. Capture real HTTP request/response evidence for the D04-19 matrix and the actual-only checks in plan section 5. Keep `X-Request-ID`; do not store session cookies or XSRF tokens.
2. Verify Announcement upload → complete → attach → publish → member read/download, all seven Fee routes, Progress, Overview, authorization, no-op/stale and idempotent replay. Use namespaced test resources; do not mutate users' records.
3. Verify worker processing for the synthetic Announcement/Fee events exactly once. Observe outbox, logs, health and file access for at least 10 minutes as D04-24 requires.
4. Keep actual evidence under `actual/<environment>/<run-id>/`; do not relabel test evidence as actual evidence.

## 5. Recovery

- **Before any D04 writes are accepted:** stop workers/writers, restore the verified target backup if the migration/deploy failed, check schema/data counts, then restore the previous application build. Record restore command, checksum, exit code and post-restore health.
- **After D04 writes have been accepted:** do not restore an older snapshot if it would erase newly written Progress, Fee history, receipts, published Announcements or audit/outbox events. Stop only the affected writer/worker, preserve evidence, and use a tested forward fix or an explicitly reviewed recovery plan that retains history.
- Never hard-delete a Fee or Published Announcement to clean up a smoke test. Reconcile synthetic records only through the API state transitions allowed by the contract.
- The test-only restore was verified by restoring `/tmp/tutorlink_test_pre_d04_19.dump`; the post-restore aggregate snapshot matched D04-18 byte-for-byte. This does not constitute a restore test on the actual database.
